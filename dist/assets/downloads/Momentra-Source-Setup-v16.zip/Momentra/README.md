# Momentra — fresh source setup for Windows

1. Extract the entire ZIP into a normal writable folder, for example Documents/Momentra. Do not run inside the ZIP, Program Files or a read-only folder.
2. Double-click Start Momentra.cmd. No Python installation or administrator access is required. First launch downloads private Python, verified dependencies, FFmpeg/FFprobe and the optional Instagram tunnel tool. Allow several minutes and at least 3 GB free, plus space for recordings. Internet is required for first setup.
3. Your browser opens http://127.0.0.1:8765/app. Set up your own AI key, creators and posting accounts in the UI. The local speech model downloads in the background on the first normal launch (about 480 MB). Wait for it to be ready before processing video.
4. Keep the console running. Closing a browser tab does not stop recordings or scheduled posts. Press Ctrl+C in the console to stop. Start the same .cmd again next time; installed dependencies and your settings are reused.

This ZIP contains Python source and UI assets, not a compiled Momentra EXE. It contains no .exe files at all. Python and video tools are still executable programs: the launcher downloads those dependencies locally on the first start. This is a Windows 10/11 x64 setup, not a completely offline bundle.

## Fresh and separate

The workspace folder beside this launcher holds this installation's keys, creators, projects and accounts. It never imports the older Momentra desktop/browser workspace or your current AI keys. Each recipient starts empty. Existing releases on the sender's computer are unchanged. Share the original ZIP, not your folder after using it: the latter contains private settings and recordings.

The .runtime folder holds the local Python environment and setup cache; models holds the speech weights; bin holds video tools. Keep the extracted folder in the same place after setup. Setup is resumable after a failed download: run the .cmd again. It does not reset the workspace. No global Python, PATH or Windows execution-policy settings are changed.

## Optional configuration

Settings > AI includes Numes, OpenRouter, Gemini, Groq and other profiles, Custom/OpenAI-compatible endpoints, backup keys and optional failover. Save a service's key/model first, then Use profile. Failover stays off until enabled. Free-model supply and provider quotas are external, not guaranteed by Momentra.

Connected apps supports YouTube, Instagram Unified login and TikTok. Register the exact callback shown in this installation's UI: this fresh bundle uses port 8765, separate from the desktop upgrade port. Instagram's secure-link tool is installed but no tunnel starts until you enable it. Free tunnel hostnames change after restart; update Meta callbacks.

Live AI refresh, everyday/strict clipping choices, combined chats and loading indicators are included. Automatic recording/posting stay off until you configure creators and destinations. The computer and engine must stay running for scheduled work.

Advanced: run `Start Momentra.cmd -Port 8766`, or add `-NoBrowser`. `-CheckOnly -NoBrowser -Port 0` checks a NEW empty installation without opening a tab or downloading speech weights; it deliberately fails if accounts, projects or keys are already present.

If startup fails, keep the console error and check your connection, free space and security software. Re-run the launcher to retry. Do not send API keys when asking for help.

## Components and licenses

Momentra is based on PeakCut (MIT), see LICENSE. UV (MIT/Apache-2.0) downloads managed Python from Astral's python-build-standalone distributions. Locked Python packages install from PyPI with hashes. FFmpeg 9.0.2 essentials (GPL) comes from Gyan; its LICENSE is extracted to bin. cloudflared 2026.11.1 (Apache-2.0) comes from Cloudflare's official GitHub release; see licenses. The speech engine is sherpa-onnx (Apache-2.0); the speech model is NVIDIA Parakeet TDT 0.6b v2, downloaded with its model materials. The included YuNet detector license is under studio/vision-assets. See THIRD-PARTY-NOTICES.txt for source links.
