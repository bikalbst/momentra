"""Window/tray policy kept separate from the backend and native WinForms runtime."""
import json
import os
from pathlib import Path
import threading

VERSION = "v10"
WORKSPACE_VERSION = "v9"
DEFAULT_PORT = 47832


def workspace_path(environ=None):
    env = os.environ if environ is None else environ
    base = Path(env.get("LOCALAPPDATA") or Path.home())
    data = Path(env.get("MOMENTRA_V9_DATA") or base / "Momentra-v9").resolve()
    if data == (base / "Momentra").resolve():
        raise ValueError("v9 cannot use the older Momentra workspace. Choose a new empty folder.")
    return data


def prepare_workspace(data):
    data = Path(data)
    marker = data / ".momentra-v9-workspace"
    if data.exists() and not marker.exists() and any(data.iterdir()):
        raise ValueError("v9 needs a new empty workspace. It does not import older data or credentials.")
    data.mkdir(parents=True, exist_ok=True)
    marker.write_text("Momentra v9 separate workspace\n", encoding="utf-8")


def prepare_environment(root, data, port, environ=None):
    """Do not inherit the older engine's data, database, model endpoint or credentials."""
    env = os.environ if environ is None else environ
    for key in list(env):
        if key.startswith(("PEAKCUT_", "GOOGLE_", "YOUTUBE_", "TIKTOK_", "INSTAGRAM_", "META_")):
            del env[key]
    for key in ("PEAKCUT_AI_KEY", "PEAKCUT_AI_KEY_FILE", "PEAKCUT_AI_BASE_URL", "PEAKCUT_AI_MODELS",
                "PEAKCUT_ASR_URL", "PEAKCUT_ASR_TOKEN", "PEAKCUT_SMTP_HOST", "PEAKCUT_SMTP_PASSWORD", "PEAKCUT_SMTP_PASSWORD_FILE",
                "GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "GOOGLE_CLIENT_FILE"):
        env[key] = ""
    env.update(DATABASE_URL="", PEAKCUT_DATA=str(data), PEAKCUT_MODELS=str(Path(root) / "models"),
               PEAKCUT_HOST="127.0.0.1", PEAKCUT_PORT=str(port), PEAKCUT_PUBLIC_URL=f"http://127.0.0.1:{port}",
               PEAKCUT_ACCOUNTS="0", PEAKCUT_UPDATE_CHECK="0", PEAKCUT_REPO_URL="", PEAKCUT_FOLLOW_URL="",
               PEAKCUT_ASR_COPIES="1", PEAKCUT_AUTO_RELOAD="0", MOMENTRA_INTERFACE="desktop", MOMENTRA_VERSION=VERSION)
    env["PATH"] = str(Path(root) / "bin") + os.pathsep + env.get("PATH", "")


class InstanceLock:
    """One lock per data folder; only this open handle is unlocked on exit."""
    def __init__(self, data):
        self.path = Path(data) / "desktop-instance.lock"
        self.handle = None

    def acquire(self):
        if self.handle is not None:
            return self
        handle = self.path.open("a+b")
        try:
            handle.seek(0, 2)
            if handle.tell() == 0:
                handle.write(b"\0")
                handle.flush()
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            handle.close()
            raise RuntimeError("Momentra v9 is already running in this workspace. Open it from its tray icon.") from exc
        self.handle = handle
        return self

    def release(self):
        handle, self.handle = self.handle, None
        if handle is None:
            return
        try:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()

    def __enter__(self):
        return self.acquire()

    def __exit__(self, *args):
        self.release()


class DesktopController:
    """Own one existing window and engine. All UI actions go through the native dispatcher."""
    def __init__(self, snapshot, describe, begin_shutdown, shutdown, stop_server, launch=None, log=None):
        self.snapshot = snapshot
        self.describe = describe
        self.begin_shutdown = begin_shutdown
        self.shutdown = shutdown
        self.stop_server = stop_server
        self.launch = launch or (lambda fn: threading.Thread(target=fn, name="desktop-quit", daemon=True).start())
        self.log = log or (lambda text: None)
        self.ui = None
        self.quitting = False
        self.confirming = False
        self.approved_close = False
        self.hidden = False
        self._guard = threading.RLock()
        self._shutdown_done = threading.Event()

    def attach(self, ui):
        self.ui = ui
        ui.dispatch(lambda: ui.install(self))

    def on_close(self):
        if self.approved_close:
            return True
        if not self.ui:
            return False
        if self.ui.tray_available and not self.quitting:
            self.hidden = True
            self.ui.dispatch(self.ui.hide)
        elif not self.quitting:
            self.request_quit()
        return False

    def open(self):
        if self.ui and not self.approved_close:
            self.hidden = False
            self.ui.dispatch(self.ui.restore)

    def status(self):
        if self.ui:
            self.ui.dispatch(lambda: self.ui.show_status(self.describe(self.snapshot())))

    def request_quit(self):
        with self._guard:
            if self.quitting or self.confirming or self.approved_close:
                return False
            self.confirming = True
        def confirm():
            try:
                # A fresh, local-only snapshot, not a stale tooltip or remote preflight.
                detail = self.describe(self.snapshot())
                if not self.ui.confirm_quit(detail):
                    return
                with self._guard:
                    self.quitting = True
                self.begin_shutdown()
                self.ui.set_stopping()
                self.launch(self._quit)
            except Exception as exc:
                self.log(str(exc))
                self.ui.show_status("Could not stop the studio. Keep it open and try Quit again.")
            finally:
                with self._guard:
                    self.confirming = False
        if self.ui:
            self.ui.dispatch(confirm)
        else:
            with self._guard:
                self.confirming = False
        return True

    def _quit(self):
        try:
            self.log("Shutdown: " + json.dumps(self.shutdown(timeout=12)))
        except Exception as exc:
            self.log("Shutdown error: " + str(exc))
        finally:
            # This order is deliberate: owned children are cleaned before uvicorn ends.
            self.stop_server()
            self.approved_close = True
            self._shutdown_done.set()
            if self.ui:
                self.ui.dispatch(self.ui.close_and_dispose)

    def finish(self):
        """Startup failures/OS window destruction also use the same engine cleanup."""
        if self.quitting:
            self._shutdown_done.wait(16)
            return
        if not self._shutdown_done.is_set():
            self.quitting = True
            self.begin_shutdown()
            self._quit()


def native_ui_checks(controller, window, result_path):
    """Internal isolated-process test: real form/tray, injected confirmation, no user window targets."""
    import time
    result = {"ok": False, "checks": [], "confirmation": "injected; no OS tray visual assertion"}
    def run_ui(fn):
        done, values = threading.Event(), []
        def run():
            try:
                values.append((True, fn()))
            except BaseException as exc:
                values.append((False, exc))
            finally:
                done.set()
        controller.ui.dispatch(run)
        if not done.wait(8):
            raise RuntimeError("The isolated native UI did not answer.")
        if not values[0][0]:
            raise values[0][1]
        return values[0][1]
    try:
        deadline = time.monotonic() + 15
        while controller.ui is None and time.monotonic() < deadline:
            time.sleep(0.05)
        if controller.ui is None:
            raise RuntimeError("The native window was not attached.")
        ui = controller.ui
        # Flush the pending install dispatch before using native controls.
        run_ui(lambda: None)
        if not ui.tray_available:
            raise RuntimeError("NotifyIcon could not be created in the isolated native test.")
        original = window.native
        for _ in range(3):
            run_ui(ui.form.Close)
            assert not run_ui(lambda: ui.form.Visible) and not ui.form.IsDisposed
            controller.open()
            assert run_ui(lambda: ui.form.Visible) and window.native is original
        result["checks"].append("three close/hide/restore cycles preserve one real form")
        old_snapshot, old_confirm = controller.snapshot, ui.confirm_quit
        prompts = []
        controller.snapshot = lambda: {"clips": 4, "wrapping": 1, "uploads": 1, "scheduled": 2, "watching": 3}
        ui.confirm_quit = lambda text: prompts.append(text) or False
        run_ui(controller.request_quit)
        assert not controller.quitting and "4 clips" in prompts[-1] and "wrapping up" in prompts[-1]
        result["checks"].append("cancelled fresh guarded warning keeps engine running")
        run_ui(lambda: setattr(ui, "tray_available", False))
        run_ui(ui.form.Close)
        assert run_ui(lambda: ui.form.Visible) and not controller.quitting
        run_ui(lambda: setattr(ui, "tray_available", True))
        result["checks"].append("no-tray close stays accessible when quit cancelled")
        controller.snapshot = old_snapshot
        ui.confirm_quit = lambda text: True
        run_ui(controller.request_quit)
        if not controller._shutdown_done.wait(17):
            raise RuntimeError("The isolated native quit did not finish.")
        deadline = time.monotonic() + 5
        while not ui.disposed and time.monotonic() < deadline:
            time.sleep(0.05)
        assert ui.disposed and not ui.tray_available and ui.form.IsDisposed
        result["checks"].append("approved quit cleans engine then disposes tray and form")
        result["ok"] = True
    except BaseException as exc:
        result["error"] = str(exc)
        controller.finish()
    finally:
        Path(result_path).write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


class WinFormsTray:
    """Create and dispose native objects only on the existing form's UI thread."""
    def __init__(self, window, icon_path):
        self.window = window
        self.form = window.native
        self.icon_path = str(icon_path)
        self.tray_available = False
        self.controller = None
        self._refs = []
        self._handlers = []
        self.icon = self.menu = self.tray = self.timer = None
        self.disposed = False
        from System import Action
        import System.Drawing as Drawing
        import System.Windows.Forms as Forms
        self.Action, self.Drawing, self.Forms = Action, Drawing, Forms

    def dispatch(self, callback):
        if self.disposed or self.form.IsDisposed:
            return
        if self.form.InvokeRequired:
            action = self.Action(callback)
            # BeginInvoke avoids blocking the worker on the UI (and the UI on that worker).
            self.form.BeginInvoke(action)
        else:
            callback()

    def _handler(self, callback):
        def handler(sender, args):
            callback()
        self._handlers.append(handler)
        return handler

    def install(self, controller):
        self.controller = controller
        try:
            self.icon = self.Drawing.Icon(self.icon_path)
            self.menu = self.Forms.ContextMenuStrip()
            for text, callback in (("Open Momentra", controller.open), ("Status", controller.status), ("Quit Momentra", controller.request_quit)):
                item = self.Forms.ToolStripMenuItem(text)
                item.Click += self._handler(callback)
                self.menu.Items.Add(item)
                self._refs.append(item)
            self.tray = self.Forms.NotifyIcon()
            self.tray.Icon = self.icon
            self.tray.Text = "Momentra v9 — running"
            self.tray.ContextMenuStrip = self.menu
            self.tray.DoubleClick += self._handler(controller.open)
            self.tray.Visible = True
            self.tray_available = bool(self.tray.Visible)
            self.form.Icon = self.icon
            self.timer = self.Forms.Timer()
            self.timer.Interval = 10000
            self.timer.Tick += self._handler(self.refresh)
            self.timer.Start()
            self.refresh()
        except Exception as exc:
            controller.log("Tray unavailable: " + str(exc))
            self.dispose_tray()
            self.form.Text = "Momentra v9 — no tray; closing asks to quit"
            self.restore()
            self.show_status("The tray icon could not be created. This window will stay accessible. Closing it asks whether to stop the studio; Keep running is the default.")

    def refresh(self):
        if self.tray_available and self.tray:
            try:
                counts = self.controller.snapshot()
                self.tray.Text = ("Momentra v9 — stopping" if self.controller.quitting else
                                  f"Momentra v9: {counts.get('recordings', 0)} live, {counts.get('clips', 0)} clips, {counts.get('uploads', 0)} uploads")[:63]
            except Exception:
                self.tray.Text = "Momentra v9 — running; Open for details"

    def hide(self):
        if self.tray_available:
            self.form.Hide()
        else:
            self.restore()

    def restore(self):
        self.form.Show()
        if self.form.WindowState == self.Forms.FormWindowState.Minimized:
            self.form.WindowState = self.Forms.FormWindowState.Normal
        self.form.Activate()
        self.form.BringToFront()

    def show_status(self, detail):
        self.Forms.MessageBox.Show(self.form, str(detail), "Momentra v9 background status",
                                   self.Forms.MessageBoxButtons.OK, self.Forms.MessageBoxIcon.Information)

    def confirm_quit(self, detail):
        result = self.Forms.MessageBox.Show(self.form,
            str(detail) + "\n\nQuit and stop the local engine? Recordings stop and creator watches/scheduled posts wait until you open v9 again.\n\n"
            "The studio allows up to 12 seconds to save/finish local work, then stops its own tools. An interrupted upload may have reached the provider: check the account before retrying.\n\n"
            "Yes = Quit. No = Keep running.", "Quit Momentra v9?", self.Forms.MessageBoxButtons.YesNo,
            self.Forms.MessageBoxIcon.Warning, self.Forms.MessageBoxDefaultButton.Button2)
        return result == self.Forms.DialogResult.Yes

    def set_stopping(self):
        self.form.Text = "Momentra v9 — stopping and saving…"
        self.refresh()

    def dispose_tray(self):
        self.tray_available = False
        if self.timer is not None:
            self.timer.Stop()
            self.timer.Dispose()
            self.timer = None
        if self.tray is not None:
            self.tray.Visible = False
            self.tray.Dispose()
            self.tray = None
        if self.menu is not None:
            self.menu.Dispose()
            self.menu = None
        if self.icon is not None:
            self.icon.Dispose()
            self.icon = None
        self._refs.clear()
        self._handlers.clear()

    def close_and_dispose(self):
        if self.disposed:
            return
        self.dispose_tray()
        self.form.Close()
        self.disposed = True
