param(
    [ValidateRange(0,65535)][int]$Port = 8765,
    [switch]$NoBrowser,
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'
$bundleRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$runtimeRoot = Join-Path $bundleRoot '.runtime'
$setupLock = $null
$exitCode = 1

function File-Hash([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose(); $stream.Dispose() }
}

function Download-Checked([string]$Url, [string]$Destination, [string]$Sha256) {
    if (Test-Path -LiteralPath $Destination) {
        if ((File-Hash $Destination) -eq $Sha256) { return }
        throw "A cached download failed its checksum: $Destination. Move that file aside and start again."
    }
    $partial = $Destination + '.partial'
    Write-Host "Downloading $([IO.Path]::GetFileName($Destination)) ..."
    $client = New-Object Net.WebClient
    try { $client.DownloadFile($Url, $partial) } finally { $client.Dispose() }
    if ((File-Hash $partial) -ne $Sha256) {
        throw 'The download checksum did not match. Nothing from that download was installed. Start again to retry.'
    }
    Move-Item -LiteralPath $partial -Destination $Destination
}

function Extract-One([string]$Archive, [string]$Name, [string]$Destination) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [IO.Compression.ZipFile]::OpenRead($Archive)
    try {
        $entries = @($zip.Entries | Where-Object { $_.Name -ceq $Name })
        if ($entries.Count -ne 1) { throw "The archive did not contain exactly one $Name." }
        $parent = Split-Path -Parent $Destination
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
        $incoming = $Destination + '.incoming'
        [IO.Compression.ZipFileExtensions]::ExtractToFile($entries[0], $incoming, $true)
        Move-Item -LiteralPath $incoming -Destination $Destination -Force
    } finally { $zip.Dispose() }
}

try {
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'This setup bundle needs 64-bit Windows 10 or newer.' }
    New-Item -ItemType Directory -Force -Path $runtimeRoot | Out-Null
    try {
        $setupLock = [IO.File]::Open((Join-Path $runtimeRoot 'setup.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    } catch { throw 'Setup or Momentra is already running from this folder. Use its existing console and browser tab.' }
    Set-Location -LiteralPath $bundleRoot
    Write-Host ''
    Write-Host 'Momentra - source setup, no compiled Momentra executable' -ForegroundColor Cyan
    Write-Host 'Fresh settings live in the workspace folder beside this launcher.'
    Write-Host 'The first start needs internet and may take several minutes. Later starts reuse the setup.'
    $drive = New-Object IO.DriveInfo([IO.Path]::GetPathRoot($bundleRoot))
    if ($drive.AvailableFreeSpace -lt 3GB) { throw 'Make at least 3 GB of free space available before setup. Recordings need additional space.' }

    $downloads = Join-Path $runtimeRoot 'downloads'
    New-Item -ItemType Directory -Force -Path $downloads | Out-Null
    $uv = Join-Path $runtimeRoot 'uv.exe'
    if (-not (Test-Path -LiteralPath $uv)) {
        $archive = Join-Path $downloads 'uv-0.13.9-windows-x64.zip'
        Download-Checked 'https://github.com/astral-sh/uv/releases/download/0.13.9/uv-x86_64-pc-windows-msvc.zip' $archive 'edd61f7f5728a56cc62455386661860bdfc7bab65872f39b0c25bdcc1d8e1beb'
        Extract-One $archive 'uv.exe' $uv
    }
    $env:UV_PYTHON_INSTALL_DIR = Join-Path $runtimeRoot 'python'
    $env:UV_PYTHON_BIN_DIR = Join-Path $runtimeRoot 'python-bin'
    $env:UV_CACHE_DIR = Join-Path $runtimeRoot 'cache'
    $env:UV_LINK_MODE = 'copy'
    $env:UV_PYTHON_DOWNLOADS = 'automatic'
    $env:UV_DEFAULT_INDEX = 'https://pypi.org/simple'
    $env:UV_INDEX_URL = 'https://pypi.org/simple'
    foreach ($name in @('UV_EXTRA_INDEX_URL','UV_INDEX','UV_CONFIG_FILE','PYTHONHOME','PYTHONPATH','VIRTUAL_ENV')) {
        [Environment]::SetEnvironmentVariable($name, $null, 'Process')
    }
    $venv = Join-Path $runtimeRoot 'venv'
    $python = Join-Path $venv 'Scripts/python.exe'
    if (-not (Test-Path -LiteralPath $python)) {
        Write-Host 'Setting up private Python 3.12.13 ...'
        & $uv --no-config venv --python '3.12.13' --managed-python $venv
        if ($LASTEXITCODE -ne 0) { throw 'Python setup failed. Check your internet connection and start again.' }
    }
    $lockFile = Join-Path $bundleRoot 'requirements.lock'
    $lockHash = File-Hash $lockFile
    $stamp = Join-Path $runtimeRoot 'dependencies-ready.txt'
    $ready = (Test-Path -LiteralPath $stamp) -and ((Get-Content -LiteralPath $stamp -Raw).Trim() -eq $lockHash)
    if (-not $ready) {
        Write-Host 'Installing verified Python dependencies ...'
        & $uv --no-config pip sync --python $python --require-hashes --only-binary ':all:' $lockFile
        if ($LASTEXITCODE -ne 0) { throw 'Dependency setup failed. Check the message above and start again. Your workspace is kept.' }
        [IO.File]::WriteAllText($stamp, $lockHash)
    }

    $bin = Join-Path $bundleRoot 'bin'
    New-Item -ItemType Directory -Force -Path $bin | Out-Null
    if (-not ((Test-Path -LiteralPath (Join-Path $bin 'ffmpeg.exe')) -and (Test-Path -LiteralPath (Join-Path $bin 'ffprobe.exe')))) {
        $archive = Join-Path $downloads 'ffmpeg-9.0.2-essentials.zip'
        Download-Checked 'https://github.com/GyanD/codexffmpeg/releases/download/9.0.2/ffmpeg-9.0.2-essentials_build.zip' $archive '60f467265b1e312373dbcd92200c2618a74850f98d3d078e94296bb3fa2047ba'
        Extract-One $archive 'ffmpeg.exe' (Join-Path $bin 'ffmpeg.exe')
        Extract-One $archive 'ffprobe.exe' (Join-Path $bin 'ffprobe.exe')
        Extract-One $archive 'LICENSE' (Join-Path $bin 'LICENSE-FFmpeg.txt')
    }
    $tunnelDir = Join-Path $bundleRoot '.tools/cloudflared-2026.11.1'
    New-Item -ItemType Directory -Force -Path $tunnelDir | Out-Null
    Download-Checked 'https://github.com/cloudflare/cloudflared/releases/download/2026.11.1/cloudflared-windows-amd64.exe' (Join-Path $tunnelDir 'cloudflared.exe') '341deda3db5ec498a0482254d6c38c0b7cf01a30c37bb5dd95d2216d08955e35'

    Write-Host ''
    Write-Host 'Setup ready. Opening the local studio ...' -ForegroundColor Green
    Write-Host 'On a normal first start the speech model downloads in the background (about 480 MB).'
    Write-Host 'Keep this console open. Ctrl+C stops Momentra; closing the browser tab does not.'
    $arguments = @((Join-Path $bundleRoot 'setup/run_local.py'), '--port', [string]$Port)
    if ($NoBrowser) { $arguments += '--no-browser' }
    if ($CheckOnly) { $arguments += '--check-only' }
    & $python @arguments
    $exitCode = $LASTEXITCODE
} catch {
    Write-Host ''
    Write-Host ('Setup stopped: ' + $_.Exception.Message) -ForegroundColor Red
    $exitCode = 1
} finally {
    if ($setupLock) { $setupLock.Dispose() }
}
exit $exitCode
