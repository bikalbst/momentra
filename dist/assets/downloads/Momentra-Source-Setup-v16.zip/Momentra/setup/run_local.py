"""The source bundle always uses its own fresh workspace; never import desktop credentials."""
import argparse
import json
import os
from pathlib import Path
import socket
import sys
import threading
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from desktop_controller import InstanceLock, prepare_environment


def check(base):
    def get(path):
        with urllib.request.urlopen(base + path, timeout=15) as response:
            return json.load(response)
    assert get('/healthz')['ok']
    status = get('/api/sync')
    assert not status['jobs'] and not status['creators'] and not status['accounts'], 'Fresh workspace must be empty'
    assert all(not p['has_key'] for p in get('/api/ai')['profiles'].values()), 'A recipient must enter their own keys'
    assert not get('/api/ai/failover')['enabled']
    checks = {item['id']: item for item in get('/api/setup')['checks']}
    assert all(checks[k]['ready'] for k in ('python', 'ffmpeg', 'ffprobe', 'speech', 'downloader'))
    assert 'not required' in checks['webview']['detail'].lower()
    from studio import framing, instagram_gateway
    import sherpa_onnx
    assert callable(sherpa_onnx.OfflineRecognizer.from_transducer)
    assert framing.available()
    assert instagram_gateway.binary().is_file()
    with urllib.request.urlopen(base + '/app', timeout=10) as response:
        assert '<title>Momentra</title>' in response.read().decode()
    print('PASS fresh source bundle: localhost UI, empty workspace, no saved keys, video tools, speech engine, local face detector and secure-link tool', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    data = ROOT / 'workspace'
    data.mkdir(exist_ok=True)
    with InstanceLock(data), socket.socket() as listener:
        listener.bind(('127.0.0.1', args.port))
        port = listener.getsockname()[1]
        base = f'http://127.0.0.1:{port}'
        prepare_environment(ROOT, data, port)
        os.environ.update(MOMENTRA_INTERFACE='browser', MOMENTRA_VERSION='v16-source',
                          PEAKCUT_FETCH_MODEL='0' if args.check_only else '1')
        import uvicorn
        from studio.server import app
        server = uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=port, log_level='warning', log_config=None))
        def ready():
            for _ in range(180):
                try:
                    with urllib.request.urlopen(base + '/healthz', timeout=1) as response:
                        if json.load(response).get('ok'):
                            return
                except (OSError, ValueError):
                    time.sleep(.25)
            raise RuntimeError('The local studio did not start in time.')
        print(f'\nMomentra source edition\nOpen: {base}/app\nFresh workspace: {data}\n', flush=True)
        worker = None
        try:
            if args.check_only:
                worker = threading.Thread(target=server.run, kwargs={'sockets': [listener]}, daemon=True)
                worker.start()
                ready()
                check(base)
            else:
                if not args.no_browser:
                    def open_ready():
                        ready()
                        webbrowser.open(base + '/app')
                    threading.Thread(target=open_ready, daemon=True).start()
                server.run(sockets=[listener])
        finally:
            server.should_exit = True
            if worker:
                worker.join(timeout=15)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        pass
