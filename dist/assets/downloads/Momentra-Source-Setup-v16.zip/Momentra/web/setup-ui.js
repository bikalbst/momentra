/* Setup diagnostics and a connection notice that never reloads the workspace. */
async function momentraDrawSetup(body){
  body.innerHTML='<section class="set-sec"><h2>Setup</h2><p class="help" role="status">Checking components…</p></section>';
  try{
    const result=await api('/api/setup');if(!body.isConnected)return;
    body.innerHTML=`<section class="set-sec"><div class="row"><h2 class="grow">Setup</h2><button type="button" class="btn sm" id="setupRefresh">Check again ↻</button></div><p class="help">${result.bundled?'Your portable app includes its own engine, video tools and speech model. Bundled components need no install commands.':'These checks describe the engine running this workspace. Run any install commands in the project folder, then check again.'} Optional services do not prevent local editing and export.</p><div class="setup-checks">${result.checks.map(c=>`<article class="setup-check"><div class="row"><b class="grow">${esc(c.label)}</b><span class="pill ${c.ready?'ok':c.optional?'':'warn'}">${c.ready?'✓ ':''}${esc(c.status)}</span></div><p class="help">${esc(c.detail)}</p>${c.command?`<div class="setup-command"><code>${esc(c.command)}</code><button class="btn sm" type="button" data-setup-copy="${esc(c.command)}">Copy command</button></div>`:''}${!c.ready&&!c.command&&!c.optional?'<p class="help">Free space if storage is low. For a missing bundled component, download a fresh Momentra build.</p>':''}${c.action?`<button type="button" class="btn sm" data-act="settab" data-k="${esc(c.action)}">Open ${c.action==='ai'?'AI settings':'Connected apps'}</button>`:''}</article>`).join('')}</div><p class="help">AI configuration and saved posting accounts are checked locally. No AI calls or uploads are made.</p></section>`;
  }catch(error){if(body.isConnected)body.innerHTML=`<section class="set-sec"><h2>Setup</h2><p class="help" role="alert">${esc(error.message)}</p><button type="button" class="btn sm" id="setupRefresh">Try again</button></section>`;}
}
const momentraConnection={busy:false,timer:null,generation:0};
function momentraConnectionNotice(label,detail=''){
  const box=document.getElementById('connectionNotice');if(!box)return;
  box.hidden=!label;document.getElementById('connectionLabel').textContent=label;box.title=detail;
}
async function momentraCheckConnection(refresh=false){
  if(momentraConnection.busy)return;
  momentraConnection.busy=true;const generation=momentraConnection.generation;
  const retry=document.getElementById('connectionRetry');if(retry)retry.disabled=true;
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),10000);
  try{
    const result=await api('/api/connection',{method:refresh?'POST':'GET',signal:controller.signal});
    if(generation===momentraConnection.generation)momentraConnectionNotice(result.online?'':'No internet detected',result.message+' Local editing and export remain available.');
  }catch(error){if(generation===momentraConnection.generation)momentraConnectionNotice('Engine disconnected','The local app engine did not respond. Retry without losing your edits.');}
  finally{clearTimeout(timeout);momentraConnection.busy=false;if(retry)retry.disabled=false;}
}
document.addEventListener('click',async e=>{
  if(e.target.closest('#connectionRetry'))return momentraCheckConnection(true);
  if(e.target.closest('#setupRefresh')){const body=document.getElementById('setbody');if(body)return momentraDrawSetup(body);}
  const copy=e.target.closest('[data-setup-copy]');if(copy){try{await navigator.clipboard.writeText(copy.dataset.setupCopy);copy.textContent='Copied';}catch{toast('Select the command and copy it manually.','bad');}}
});
window.addEventListener('offline',()=>{momentraConnection.generation++;momentraConnectionNotice('No internet','Local editing and export are available.');});
window.addEventListener('online',()=>{momentraConnection.generation++;momentraCheckConnection(true);});
document.addEventListener('DOMContentLoaded',()=>{momentraCheckConnection();momentraConnection.timer=setInterval(()=>{if(!document.hidden)momentraCheckConnection();},30000);});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)momentraCheckConnection();});
const setupStyle=document.createElement('style');setupStyle.textContent=`
#connectionNotice{display:flex;align-items:center;gap:8px;border:1px solid var(--line);border-radius:10px;padding:4px 8px;color:var(--brand-ink);background:var(--selection);font-size:12px}#connectionNotice[hidden]{display:none}#connectionNotice .btn{height:28px;padding:0 7px}.setup-checks{display:grid;gap:12px;margin:20px 0}.setup-check{padding:16px;border:1px solid var(--line);border-radius:12px;background:var(--surface)}.setup-check .help{margin:8px 0}.setup-command{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px;background:var(--bg);border-radius:8px}.setup-command code{flex:1;overflow-wrap:anywhere;user-select:text;font-size:12px}@media(max-width:760px){#connectionNotice{order:4}}
`;document.head.append(setupStyle);
