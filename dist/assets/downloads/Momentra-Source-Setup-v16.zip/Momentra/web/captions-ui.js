/* Draggable positions for the caption line, saved as output-frame percentages. */
const TEXT_DEFAULTS={caption_x:50,caption_y:null,caption_size:100,caption_letter_spacing:0,caption_word_spacing:0,hook_x:50,hook_y:null,hook_size:100};
function captionControls(prefix,values,editor){
 const input=(key,label,min,max)=>`<label class="f">${label}<input type="number" min="${min}" max="${max}" step="any" placeholder="Auto" id="${prefix}_${key}" ${editor?`data-f="${key}"`:''} value="${values[key]??TEXT_DEFAULTS[key]??''}"></label>`;
 return `<section class="caption-position-controls"><div class="row"><b class="grow">Text size & position</b><button type="button" class="btn sm" data-caption-reset="${prefix}">Reset text</button></div><p class="help">${editor?'Drag the actual captions or opening hook directly on Draft, or focus them and use arrow keys. Save and re-make to apply your edits.':'Drag captions or the hook on the right-hand preview. These settings apply when you make clips.'}</p>${editor&&typeof window.momentraDraftOpen!=='function'?'<div class="row"><button type="button" class="btn sm" data-caption-mode="move">Move text</button><button type="button" class="btn sm" data-caption-mode="watch">Watch rendered clip</button></div>':''}<div class="caption-coordinates">${input('caption_size','Caption size %',50,200)}${input('caption_letter_spacing','Letter spacing',0,20)}${input('caption_word_spacing','Word spacing',0,40)}${input('caption_x','Caption horizontal %',0,100)}${input('caption_y','Caption vertical %',0,100)}</div><details><summary>Opening hook</summary><div class="caption-coordinates">${input('hook_size','Hook size %',50,200)}${input('hook_x','Hook horizontal %',0,100)}${input('hook_y','Hook vertical %',0,100)}</div></details><p class="help">Spacing uses pixels at 1080p and scales with the output. ${editor?'Draft uses your actual timed words; fonts and motion may differ slightly from the final export.':'Preview text is illustrative.'} The hook uses Big text; an empty Big text field exports without a hook.</p></section>`;
}
function captionValues(prefix){return Object.fromEntries(Object.entries(TEXT_DEFAULTS).map(([key,value])=>{const field=document.getElementById(prefix+'_'+key);return [key,!field||field.value===''?value:Number(field.value)];}));}
function captionDefaultY(prefix){
 const layout=frameLayout(prefix),source=framingSource(prefix),w=source?.w||1920,h=source?.h||1080;
 if(layout==='facecam_top')return 1450/1920*100;if(layout==='facecam_bottom')return 1040/1920*100;
 if(layout==='crop'||h>=w)return 1380/1920*100;
 const fg=layout==='zoom'?1000:Math.min(1920,Math.round(1080*h/w/2)*2);
 return Math.min(1640,(1920-fg)/2+fg+180)/1920*100;
}
function textDefaultY(prefix,kind){if(kind!=='hook')return captionDefaultY(prefix);const layout=frameLayout(prefix),source=framingSource(prefix),w=source?.w||1920,h=source?.h||1080;if(layout.startsWith('facecam_'))return 110/1920*100;if(layout==='crop'||h>=w)return 300/1920*100;const fg=layout==='zoom'?1000:Math.min(1920,Math.round(1080*h/w/2)*2);return Math.max(230,(1920-fg)/2-190)/1920*100;}
function captionPosition(node,prefix){
 const values=captionValues(prefix),kind=node.dataset.textKind||'caption';node.style.left=values[kind+'_x']+'%';node.style.top=(values[kind+'_y']??textDefaultY(prefix,kind))+'%';node.style.bottom='auto';node.style.transform='translate(-50%,-50%)';
}
function captionWrite(prefix,x,y,kind='caption'){
 document.getElementById(prefix+'_'+kind+'_x').value=Math.max(0,Math.min(100,x)).toFixed(3);
 document.getElementById(prefix+'_'+kind+'_y').value=Math.max(0,Math.min(100,y)).toFixed(3);
 momentraCaptionRefresh();
}
function momentraEditorPreviewReset(){
 const stage=document.getElementById('stage');
 stage?.classList.remove('show-caption-position','show-framing');
 document.querySelector('.framing-edit-note')?.remove();
 captionDrag=null;
}
function captionEditorPreview(){
 if(window.momentraDraftSource?.()){window.momentraDraftMode?.('draft');window.momentraDraftChanged?.();return;}
 const stage=document.getElementById('stage');if(!stage)return;
 if(!framingSource('edit')){toast('The source frame is still loading. Try Move captions again when it is ready.','bad');return;}
 let surface=document.getElementById('captionPositionStage');
 if(!surface){surface=document.createElement('div');surface.id='captionPositionStage';surface.className='caption-position-stage';surface.innerHTML='<canvas width="360" height="640" aria-label="Uncaptioned source framing preview"></canvas><div id="captionDragEdit" class="caption-drag-target" data-text-kind="caption" data-caption-prefix="edit" tabindex="0" role="group" aria-label="Caption position. Drag to move, or use arrow keys."></div>';stage.append(surface);const hook=document.createElement('div');hook.id='hookDragEdit';hook.className='caption-drag-target hook-drag-target';hook.dataset.captionPrefix='edit';hook.dataset.textKind='hook';hook.tabIndex=0;hook.setAttribute('role','group');hook.setAttribute('aria-label','Opening hook position. Drag or use arrow keys.');surface.append(hook);}
 stage.querySelector('video')?.pause();
 stage.classList.remove('show-framing');stage.classList.add('show-caption-position');
 document.querySelector('.framing-edit-note')?.remove();
 drawOutput(surface.querySelector('canvas'),'edit');momentraCaptionRefresh();
}
function momentraCaptionRefresh(){
 window.momentraDraftChanged?.();
 const home=document.getElementById('demoCaption');if(home){home.dataset.captionPrefix='o';home.dataset.textKind='caption';home.classList.add('caption-drag-target');home.tabIndex=0;home.setAttribute('role','group');home.setAttribute('aria-label','Sample captions. Drag or use arrow keys.');captionPosition(home,'o');}
 const parent=document.getElementById('demoCanvas');if(parent&&!document.getElementById('demoHook')){const hook=document.createElement('div');hook.id='demoHook';hook.className='caption-drag-target hook-drag-target';hook.dataset.captionPrefix='o';hook.dataset.textKind='hook';hook.tabIndex=0;hook.setAttribute('role','group');hook.setAttribute('aria-label','Sample opening hook. Drag or use arrow keys.');hook.textContent='YOUR OPENING HOOK';parent.append(hook);}
 const editor=document.getElementById('captionDragEdit');if(editor){editor.innerHTML=capPrev(document.getElementById('edit_style')?.value||'bounce');captionPosition(editor,'edit');}
 const editHook=document.getElementById('hookDragEdit');if(editHook)editHook.textContent=document.querySelector('#clipdlg [data-f=hook]')?.value||'YOUR OPENING HOOK';
 document.querySelectorAll('[data-caption-prefix]').forEach(node=>{
  const prefix=node.dataset.captionPrefix,kind=node.dataset.textKind||'caption',values=captionValues(prefix),surface=node.parentElement;
  captionPosition(node,prefix);const scale=surface.clientWidth/1080||1/3;
  const base=kind==='hook'?110:({bounce:132,hype:152,clean:100,karaoke:122,neon:122,outline:132,typewriter:94,subtitle:70}[document.getElementById(prefix==='edit'?'edit_style':'o_style')?.value]||132);
  const text=node.querySelector('.cap-prev')||node;text.style.fontSize=Math.max(9,base*.65*scale*values[kind+'_size']/100)+'px';
  text.style.letterSpacing=kind==='caption'?values.caption_letter_spacing*scale+'px':'normal';text.style.wordSpacing=kind==='caption'?values.caption_word_spacing*scale+'px':'normal';
  if(prefix==='o')node.hidden=!framingState.ready;
 });
}
let captionDrag=null;
document.addEventListener('pointerdown',e=>{
 const node=e.target.closest('[data-caption-prefix]');if(!node)return;
 const prefix=node.dataset.captionPrefix;if(prefix==='o'&&!framingState.ready){toast('Load a video preview first, then drag the captions.','bad');return;}
 const box=node.parentElement.getBoundingClientRect(),text=node.getBoundingClientRect();if(!box.width||!box.height)return;
 e.preventDefault();node.focus();node.setPointerCapture?.(e.pointerId);
 captionDrag={id:e.pointerId,node,prefix,kind:node.dataset.textKind||'caption',box,text,x:e.clientX,y:e.clientY,values:captionValues(prefix)};
});
document.addEventListener('pointermove',e=>{
 const drag=captionDrag;if(!drag||drag.id!==e.pointerId)return;e.preventDefault();
 const halfW=Math.min(49,drag.text.width/drag.box.width*50),halfH=Math.min(49,drag.text.height/drag.box.height*50);
 const x=drag.values[drag.kind+'_x']+(e.clientX-drag.x)/drag.box.width*100,y=(drag.values[drag.kind+'_y']??textDefaultY(drag.prefix,drag.kind))+(e.clientY-drag.y)/drag.box.height*100;
 captionWrite(drag.prefix,Math.max(halfW,Math.min(100-halfW,x)),Math.max(halfH,Math.min(100-halfH,y)),drag.kind);
},{passive:false});
for(const name of ['pointerup','pointercancel','lostpointercapture'])document.addEventListener(name,e=>{if(captionDrag?.id===e.pointerId)captionDrag=null;});
document.addEventListener('keydown',e=>{
 const node=e.target.closest('[data-caption-prefix]');if(!node||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;
 e.preventDefault();const prefix=node.dataset.captionPrefix,kind=node.dataset.textKind||'caption',v=captionValues(prefix),step=e.shiftKey?5:1;
 captionWrite(prefix,v[kind+'_x']+(e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0),(v[kind+'_y']??textDefaultY(prefix,kind))+(e.key==='ArrowUp'?-step:e.key==='ArrowDown'?step:0),kind);
});
document.addEventListener('input',e=>{if(/^(o|edit)_(caption|hook)_/.test(e.target.id)||e.target.dataset.f==='hook')momentraCaptionRefresh();});
document.addEventListener('click',e=>{
 const reset=e.target.closest('[data-caption-reset]');if(reset){const p=reset.dataset.captionReset;for(const[key,value]of Object.entries(TEXT_DEFAULTS)){const field=document.getElementById(p+'_'+key);if(field)field.value=value??'';}momentraCaptionRefresh();return;}
 const mode=e.target.closest('[data-caption-mode]');if(mode){if(mode.dataset.captionMode==='move')captionEditorPreview();else momentraEditorPreviewReset();return;}
 if(e.target.closest('[data-seg]'))momentraCaptionRefresh();
});
const captionStyles=document.createElement('style');captionStyles.textContent=`
.hook-drag-target{background:#fff;color:#251b11;font-weight:800;text-shadow:none!important}.caption-position-controls{padding:12px 0}.caption-position-controls b{font-size:12px}.caption-position-controls .help{font-size:11px;margin:8px 0;line-height:1.6}.caption-coordinates{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}.caption-coordinates .f{font-size:11px}.caption-drag-target{position:absolute!important;width:max-content!important;max-width:90%;height:auto!important;cursor:grab;touch-action:none;user-select:none;z-index:7;text-align:center;border:1px dashed #ffffff95;border-radius:6px;padding:5px 8px!important;line-height:1.2!important}.caption-drag-target:active{cursor:grabbing}.caption-drag-target:focus-visible{outline:2px solid var(--brand);outline-offset:3px}.caption-drag-target .cap-prev{min-height:0;background:transparent;width:auto;white-space:normal;font-size:clamp(14px,1.5vw,24px);line-height:1.2;padding:0;color:#fff;text-shadow:1px 1px 2px #000}.caption-drag-target .style-neon{color:#40f0ff;text-shadow:0 0 5px #40b3ff}.caption-position-stage{display:none;position:relative;height:100%;aspect-ratio:9/16;max-width:100%;max-height:calc(100vh - 210px);width:auto}.caption-position-stage canvas{display:block;width:100%;height:100%;object-fit:contain}.stage.show-caption-position>video,.stage.show-caption-position>img,.stage.show-caption-position>.editor-framing-canvas{display:none!important}.stage.show-caption-position .caption-position-stage{display:block}.caption-position-stage .caption-drag-target{font-weight:800;font-size:22px;color:#fff}.caption-position-stage [data-style=subtitle] .cap-prev{font-size:14px}.caption-position-stage [data-style=typewriter] .cap-prev{font-size:17px}
`;document.head.append(captionStyles);

const captionFit=document.createElement('style');captionFit.textContent='.caption-position-stage{width:min(100%,calc((100vh - 240px)*.5625));height:auto}.caption-position-stage canvas{height:auto}.hook-drag-target .cap-prev{background:transparent}';document.head.append(captionFit);
