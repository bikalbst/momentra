/* Backup credentials are sent once; only counts and numbered slots return. */
(() => {
  let policy=null,owner=null;
  const label=p=>S.ai?.providers?.find(x=>x.id===p)?.label||p;
  window.momentraDrawBackupKeys=()=>{
    const mount=document.getElementById('aiBackupKeys');if(!mount||!policy)return;
    const p=document.getElementById('ai_provider')?.value,count=policy.key_counts[p]||0;
    mount.innerHTML=`<h3>Backup keys for ${esc(label(p))}</h3><p class="help">The saved profile key is tried first, followed by these numbered keys when automatic failover is enabled. They use this service's saved models and address. Keys and key fragments are never displayed.</p>${Array.from({length:count},(_,slot)=>`<div class="row"><span>Backup key ${slot+1}</span><button class="btn sm" type="button" data-backup-remove="${slot}" data-provider="${esc(p)}">Remove</button></div>`).join('')}<label class="f">Add another key<input id="aiBackupKey" type="password" autocomplete="new-password" spellcheck="false"></label><button class="btn" type="button" data-backup-add ${S.ai?.profiles?.[p]?.ready?'':'disabled'}>Save backup key</button>`;
  };
  function draw(){
    const mount=document.getElementById('aiFailover');if(!mount||owner!==document.getElementById('ai_settings'))return;
    const ready=(S.ai?.providers||[]).filter(p=>S.ai?.profiles?.[p.id]?.ready);
    mount.innerHTML=`<h3>Automatic key failover</h3><label class="ck"><input type="checkbox" id="aiFailoverEnabled" ${policy.enabled?'checked':''}>Automatically try the next usable saved key or service when an AI request fails</label><p class="help">Your selected profile stays primary. Failed keys pause briefly; rate-limited services wait for their retry time. Recording continues. This can send transcript text to the backup services you select.</p><div id="aiBackupOrder">${policy.order.map((p,i)=>`<div class="row" data-backup-provider="${esc(p)}"><b>${i+1}. ${esc(label(p))}</b><button class="btn sm" type="button" data-backup-up="${i}" ${i?'':'disabled'}>Move up</button><button class="btn sm" type="button" data-backup-drop="${i}">Remove service</button></div>`).join('')}</div><div class="row"><select id="aiBackupProvider" aria-label="Backup service">${ready.map(p=>`<option value="${esc(p.id)}">${esc(p.label)}</option>`).join('')}</select><button class="btn" type="button" data-backup-service ${ready.length?'':'disabled'}>Add backup service</button></div><label class="ck"><input id="aiAllowPaidBackup" type="checkbox" ${policy.allow_paid?'checked':''}>Allow paid models in backup services</label><p class="help">By default, other services may use only :free models on Numes/OpenRouter, or local Ollama. A Numes/OpenRouter request starting with :free stays on free models unless you allow paid backups. Your primary profile's existing paid models remain usable. No model id is silently changed.</p><button class="btn primary" type="button" data-failover-save>Save failover options</button>${policy.last_used?.label?`<p class="help">Last successful service: ${esc(policy.last_used.label)} · ${esc(policy.last_used.model)}</p>`:''}<div id="aiBackupKeys" style="margin-top:24px"></div><p class="help" id="aiFailoverStatus" role="status"></p>`;
    window.momentraDrawBackupKeys();
  }
  window.momentraDrawFailover=async section=>{
    if(!section)return;owner=section;
    const mount=document.createElement('section');mount.id='aiFailover';mount.style.marginTop='28px';mount.innerHTML=window.momentraLoading?.('Loading failover settings…')||'Loading failover settings…';section.append(mount);
    try{const result=await api('/api/ai/failover');if(owner!==section||!section.isConnected)return;policy=result;draw();}
    catch(error){if(mount.isConnected)mount.textContent=error.message;}
  };
  function capture(){
    policy.enabled=document.getElementById('aiFailoverEnabled').checked;
    policy.allow_paid=document.getElementById('aiAllowPaidBackup').checked;
  }
  document.addEventListener('click',async event=>{
    const button=event.target.closest('[data-failover-save],[data-backup-add],[data-backup-remove],[data-backup-service],[data-backup-up],[data-backup-drop]');
    if(!button||!policy||!document.getElementById('ai_settings'))return;
    capture();
    if(button.hasAttribute('data-backup-service')){const p=document.getElementById('aiBackupProvider').value;if(p&&!policy.order.includes(p))policy.order.push(p);draw();return;}
    if(button.hasAttribute('data-backup-up')){const i=Number(button.dataset.backupUp);if(i>0)[policy.order[i-1],policy.order[i]]=[policy.order[i],policy.order[i-1]];draw();return;}
    if(button.hasAttribute('data-backup-drop')){policy.order.splice(Number(button.dataset.backupDrop),1);draw();return;}
    const section=owner;
    button.disabled=true;
    try{
      if(button.hasAttribute('data-failover-save'))policy=await send('/api/ai/failover',{enabled:policy.enabled,order:policy.order,allow_paid:policy.allow_paid},'PUT');
      else if(button.hasAttribute('data-backup-add')){
        const input=document.getElementById('aiBackupKey');
        const result=await send('/api/ai/failover/keys',{provider:document.getElementById('ai_provider').value,key:input.value});input.value='';policy.key_counts=result.key_counts;
      }else{
        const result=await api('/api/ai/failover/keys/'+encodeURIComponent(button.dataset.provider)+'/'+button.dataset.backupRemove,{method:'DELETE'});policy.key_counts=result.key_counts;
      }
      if(owner!==section||!section.isConnected)return;
      draw();document.getElementById('aiFailoverStatus').textContent='Saved locally. Primary profile and other saved settings were kept.';
    }catch(error){const status=document.getElementById('aiFailoverStatus');if(status)status.textContent=error.message;toast(error.message,'bad');}
    finally{if(button.isConnected)button.disabled=false;}
  });
})();
