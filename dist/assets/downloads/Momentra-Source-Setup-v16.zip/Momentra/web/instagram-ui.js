/* Meta setup is local. Only the separate callback/media gateway is public. */
let instagramSetupTimer=null;
function instagramSetupPanel(setup){
  const u=setup?.unified||{},link=u.link||{},urls=link.urls||{};
  clearTimeout(instagramSetupTimer);
  instagramSetupTimer=setTimeout(refreshInstagramLink,2000);
  const copy=(label,value)=>`<label class="f">${label}<div class="copyrow"><code style="overflow-wrap:anywhere">${esc(value||'Start the secure link first')}</code>${value?`<button class="btn sm" data-act="copytext" data-t="${esc(value)}">Copy</button>`:''}</div></label>`;
  return `<div class="appsetup" id="instagramSetupPanel">
    <p>Connect through <b>Meta Unified login</b>. Your Instagram must be a Creator or Business account.</p>
    <ol><li>In <a href="https://developers.facebook.com/apps" target="_blank" rel="noopener">Meta for Developers</a>, open your app → Instagram → API setup with Unified login.</li>
    <li>Connect a business portfolio using your Facebook account. Add the Instagram account to it.</li>
    <li>Start the secure link below. Copy its callback into Meta's allowed OAuth redirect URIs.</li>
    <li>Create an <b>Instagram Login Compatible</b> configuration. Keep Meta's required basic and messaging permissions, enable content publishing, and copy the Configuration ID. Momentra uses it to identify your account and publish Reels; it does not read your DMs or use ads.</li>
    <li>Paste your <b>Meta App ID</b>, <b>Meta App Secret</b> and Configuration ID here, save, then Connect.</li></ol>
    <div class="row"><button class="btn primary" type="button" data-instagram-link="start">Start secure link</button><button class="btn" type="button" data-instagram-link="stop">Stop link</button></div>
    <p id="instagramLinkStatus" role="status">${esc(link.message||'The secure link is stopped.')}</p>
    <p class="help">Free temporary Cloudflare link. The address changes when restarted: update the callback in Meta before connecting again. It starts with Momentra after you enable it and stops when you quit. Keep Momentra open for automatic posts. Only Instagram callbacks and signed approved-video links are exposed.</p>
    <div id="instagramLinkUrls">${Object.entries({redirect:'OAuth redirect URI',webhook:'Webhook callback URL',deauthorization:'Deauthorization callback URL',deletion:'Data deletion request URL',privacy:'Privacy policy URL'}).map(([k,v])=>copy(v,urls[k])).join('')}</div>
    <div class="row"><button class="btn sm" type="button" data-instagram-verify>Show webhook verify token</button><code id="instagramVerifyToken" style="overflow-wrap:anywhere"></code></div>
    <p class="help">No chat webhook subscriptions are needed for posting. Meta can verify this callback. This personal test setup does not replace Meta's business verification or App Review for other users.</p>
    <div class="fields"><label class="f">Meta App ID<input id="instagramAppId" value="${esc(u.app_id||'')}" autocomplete="off" spellcheck="false"></label>
    <label class="f">Meta App Secret<input id="instagramAppSecret" type="password" autocomplete="off" placeholder="${u.has_secret?'Saved. Leave blank to keep it.':''}"></label>
    <label class="f">Configuration ID<input id="instagramConfigId" value="${esc(u.config_id||'')}" autocomplete="off" spellcheck="false"></label></div>
    <p class="help">Use the Meta app credentials from App settings → Basic. Existing AI profiles, social connections and older Instagram app credentials are retained.</p>
    <div class="row"><button class="btn primary" type="button" data-instagram-save>Save Instagram setup</button><button class="btn" data-act="appsetup" data-p="">Close</button></div></div>`;
}
async function refreshInstagramLink(){
  if(!document.getElementById('instagramSetupPanel'))return;
  try{
    const result=await api('/api/instagram/setup'),link=result.link;
    document.getElementById('instagramLinkStatus').textContent=link.message;
    const labels={redirect:'OAuth redirect URI',webhook:'Webhook callback URL',deauthorization:'Deauthorization callback URL',deletion:'Data deletion request URL',privacy:'Privacy policy URL'};
    document.getElementById('instagramLinkUrls').innerHTML=Object.entries(labels).map(([k,label])=>`<label class="f">${label}<div class="copyrow"><code style="overflow-wrap:anywhere">${esc(link.urls[k]||'Start the secure link first')}</code>${link.urls[k]?`<button class="btn sm" data-act="copytext" data-t="${esc(link.urls[k])}">Copy</button>`:''}</div></label>`).join('');
  }catch(error){const el=document.getElementById('instagramLinkStatus');if(el)el.textContent=error.message;}
  instagramSetupTimer=setTimeout(refreshInstagramLink,2000);
}
document.addEventListener('click',async e=>{
  const link=e.target.closest('[data-instagram-link]'),save=e.target.closest('[data-instagram-save]'),verify=e.target.closest('[data-instagram-verify]');
  if(!link&&!save&&!verify)return;
  const button=link||save||verify;button.disabled=true;
  try{
    if(link){await send('/api/instagram/link/'+link.dataset.instagramLink,{});clearTimeout(instagramSetupTimer);await refreshInstagramLink();}
    if(verify){const result=await send('/api/instagram/link/verify-token',{});document.getElementById('instagramVerifyToken').textContent=result.verify_token;}
    if(save){await send('/api/instagram/setup',{client_id:document.getElementById('instagramAppId').value,client_secret:document.getElementById('instagramAppSecret').value,config_id:document.getElementById('instagramConfigId').value},'PUT');document.getElementById('instagramAppSecret').value='';S.status=await api('/api/status');toast('Instagram setup saved. You can connect now.','ok');await drawSettings();}
  }catch(error){toast(error.message,'bad');}finally{button.disabled=false;}
});
