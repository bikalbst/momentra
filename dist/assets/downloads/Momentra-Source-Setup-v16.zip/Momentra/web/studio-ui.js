/* Momentra's desktop workspace. User media and secrets stay outside the UI bundle. */
function studioHome() {
  return `<section class="studio-home" aria-labelledby="studioHomeTitle"><div class="studio-intro"><span class="eyebrow">YOUR EDITING DESK</span><h2 id="studioHomeTitle">Find the moment.<br>Make it yours<span>.</span></h2><p>Start with a long video. Shape the framing, make the words clear, and leave with clips ready to share.</p><div id="add"></div><ol class="studio-workflow" aria-label="Your workflow"><li><b>1</b> Add a video</li><li><b>2</b> Edit your clips</li><li><b>3</b> Export or publish</li></ol><div id="recentHome"></div></div><aside class="studio-demo" aria-label="Video layout preview"><div class="demo-heading"><span id="demoLabel">Layout preview</span><span class="pill">9:16</span></div><div id="demoCanvas" class="demo-canvas facecam_top"><div class="demo-face"></div><div class="demo-game"></div><div id="demoCaption" class="demo-caption"></div></div><div class="demo-footer"><span>Illustrative sample</span><button type="button" class="btn sm ghost" data-act="toggleopts">Customize layout</button></div></aside></section>`;
}
function studioEmptyHome() {
  return `<div class="studio-start"><div><span class="eyebrow">A STUDIO THAT FITS YOUR CONTENT</span><h2>One source. More ways to tell it.</h2><p>Keep the original look, or put your facecam and gameplay in their own frame.</p></div><div class="studio-features"><div><b>5 video layouts</b><span>Original fills + facecam top and bottom</span></div><div><b>8 caption styles</b><span>Bounce, Hype, Clean and five new looks</span></div><div><b>Works on your PC</b><span>Local transcription and rendering</span></div></div></div>`;
}
function studioCreatorPreview() {
  return `<aside class="studio-demo creator-preview"><div class="demo-heading"><span id="demoLabel">Creator framing</span><span class="pill">9:16</span></div><div id="demoCanvas" class="demo-canvas"><div id="demoCaption" class="demo-caption"></div></div><div class="demo-footer"><span>Captured live sample</span></div><button class="btn primary" type="button" id="saveCreatorFraming">Save framing for this creator</button><p id="creatorFramingSaveStatus" class="preview-help">Saved framing applies to new live clips, including automatic recordings.</p></aside>`;
}
function layoutPrev(key) {
  if (key === "two_person") return `<span class="layout-thumb two-person-thumb"><span class="mini-face">PERSON 1</span><span class="mini-game">PERSON 2</span></span>`;
  if (key === "portrait") return `<span class="lay-prev crop"><span class="ph"><i></i></span></span>`;
  if (key.startsWith("facecam_")) return `<span class="layout-thumb ${key}"><span class="mini-face">CAM</span><span class="mini-game">PLAY</span></span>`;
  return `<span class="lay-prev ${key}"><span class="ph"><i></i></span></span>`;
}
const SPLIT_DEFAULTS = {facecam_height:30,face_x:0,face_y:0,face_w:25,face_h:35,game_x:0,game_y:0,game_w:100,game_h:100};
function splitControls(prefix, values, editor) {
  const v={...SPLIT_DEFAULTS,...values};
  const input=(key,label,min,max) => `<label class="f">${label}<span class="percent-field"><input id="${prefix}_${key}" ${editor?`data-f="${key}"`:""} type="number" min="${min}" max="${max}" step="any" value="${v[key]}"><span>%</span></span></label>`;
  return `<div class="ot" data-framing-heading>Facecam + gameplay</div><p class="help" data-framing-help>Select the two source regions manually, or use Auto frame in the clip editor for a local suggestion. Always review the proposed crops.</p>
    ${!editor && typeof creatorCropPresets==='function'?creatorCropPresets():''}
    <div class="split-height">${input("facecam_height","Facecam height in the finished clip",20,45)}<span class="sub">20–45% of the vertical frame</span></div>
    <div class="crop-presets"><span class="sub">Camera location:</span>${["Top left","Top right","Bottom left","Bottom right"].map((s,i)=>`<button type="button" class="btn sm" data-crop-preset="${i}" data-prefix="${prefix}">${s}</button>`).join("")}</div>
    <div class="row frame-region-tabs"><button class="btn sm" type="button" data-frame-region="face" data-frame-prefix="${prefix}" aria-pressed="true">Facecam</button><button class="btn sm" type="button" data-frame-region="game" data-frame-prefix="${prefix}" aria-pressed="false">Gameplay</button></div>
    ${!editor ? `<div class="visual-framing" data-frame-prefix="${prefix}"><p class="help">Drag the rectangle to move it. Use the corner handles to resize. The frame matches its output panel.</p><div class="source-crop" data-crop-prefix="${prefix}"><canvas width="960" height="540"></canvas><div class="crop-box face-crop" data-region="face"><span>Facecam</span></div><div class="crop-box game-crop" data-region="game"><span>Gameplay</span></div></div><p class="framing-source-note">Add a video to frame the actual source.</p></div>` : `<p class="help">Drag a rectangle on the source frame below to move it, or resize it with the corner handles.</p>`}
    <details class="game-crop-settings"><summary>Advanced crop values</summary><div class="crop-region"><b>Facecam crop</b><div class="crop-fields">${input("face_x","Left",0,95)}${input("face_y","Top",0,95)}${input("face_w","Width",5,100)}${input("face_h","Height",5,100)}</div></div><div class="crop-region"><b>Gameplay crop</b><div class="crop-fields">${input("game_x","Left",0,95)}${input("game_y","Top",0,95)}${input("game_w","Width",5,100)}${input("game_h","Height",5,100)}</div></div></details>`;
}
function readSplit(prefix) {
  const out={};Object.keys(SPLIT_DEFAULTS).forEach(key=>{const field=document.getElementById(prefix+"_"+key);if(field)out[key]=Number(field.value);});return out;
}
function studioSplitVisibility() {
  document.querySelectorAll("[data-split-for]").forEach(box=>{
    const layout=document.getElementById(box.dataset.splitFor)?.value||'',pair=layout==='two_person',portrait=layout==='portrait';
    box.hidden=!(layout.startsWith('facecam_')||pair||portrait);
    box.querySelectorAll('.split-height,.crop-presets').forEach(row=>row.hidden=pair||portrait);
    const title=box.querySelector('[data-framing-heading]');if(title)title.textContent=pair?'Two people · equal 50:50':portrait?'Selected person crop':'Facecam + gameplay';
    const first=box.querySelector('[data-frame-region=face]'),second=box.querySelector('[data-frame-region=game]');
    if(first)first.textContent=pair?'Top person':portrait?'Person':'Facecam';if(second)second.textContent=pair?'Bottom person':'Gameplay';
    box.querySelectorAll('.face-crop.crop-box>span').forEach(el=>el.textContent=pair?'Top person':portrait?'Person':'Facecam');
    box.querySelectorAll('.game-crop.crop-box>span').forEach(el=>el.textContent=pair?'Bottom person':'Gameplay');
    box.querySelectorAll('[data-frame-region=game],.game-crop.crop-box').forEach(el=>el.hidden=portrait);
    box.querySelectorAll('.crop-region').forEach(region=>{if(region.querySelector('[id$="_game_x"]'))region.hidden=portrait;});
  });
}
function studioCropOverlay() {
  if (window.momentraCropOverlay) { momentraCropOverlay(); return; }
  const values={...SPLIT_DEFAULTS,...readSplit("edit")};
  ["face","game"].forEach(kind=>{
    const box=document.querySelector("."+kind+"-crop.crop-box");if(!box)return;
    const w=Math.min(100,Math.max(5,values[kind+"_w"])),h=Math.min(100,Math.max(5,values[kind+"_h"]));
    const x=Math.min(100-w,Math.max(0,values[kind+"_x"])),y=Math.min(100-h,Math.max(0,values[kind+"_y"]));
    Object.assign(box.style,{left:x+"%",top:y+"%",width:w+"%",height:h+"%"});
  });
}
function studioPreview() {
  const preview=document.getElementById("demoCanvas");if(!preview){if(window.momentraRefresh)momentraRefresh();return;}
  const layout=document.getElementById("o_layout")?.value||"blur",style=document.getElementById("o_style")?.value||"bounce";
  preview.className="demo-canvas "+layout;
  preview.style.setProperty("--face-height",(readSplit("o").facecam_height||30)+"%");
  document.getElementById("demoLabel").textContent=LAYOUT_SHORT[layout]||"Layout preview";
  document.getElementById("demoCaption").innerHTML=capPrev(style);
  const recent=document.getElementById("recentHome");
  if(recent)recent.innerHTML=`<div class="recent-heading"><h3>Recent videos</h3><button class="btn sm ghost" data-act="go" data-v="library">View all videos</button></div>`+(S.jobs.length?S.jobs.slice().sort((a,b)=>b.created-a.created).slice(0,3).map(j=>`<button class="recent-project" data-act="go" data-v="library">${j.thumb?`<img src="/media/${esc(j.id)}/thumb.jpg" alt="">`:`<span class="recent-icon" aria-hidden="true">▷</span>`}<span><b>${esc(j.title||"Untitled video")}</b><small>${j.clips.filter(c=>c.status==="done").length} clips · ${esc(j.status)}</small></span><span aria-hidden="true">↗</span></button>`).join(""):`<div class="recent-empty">Your videos will appear here. Paste a link or upload your first video above.</div>`);
  if(window.momentraRefresh)momentraRefresh();
  if(window.momentraCaptionRefresh)momentraCaptionRefresh();
}

/* Keep the last local choice until the server accepts it. Writes run in order. */
const studioThemeState={version:0,pending:null,saving:false};
try { const pending=localStorage.getItem("momentra-theme-pending");if(["light","dark"].includes(pending))studioThemeState.pending=pending; } catch {}
function studioTheme() {
  const button=document.getElementById("themeToggle"),dark=document.documentElement.dataset.theme==="dark";
  if(button){button.textContent=dark?"Light mode":"Dark mode";button.setAttribute("aria-label",dark?"Switch to light mode":"Switch to dark mode");button.setAttribute("aria-pressed",String(dark));}
}
function studioThemeApply(theme) {
  if(!["dark","light"].includes(theme))return;
  document.documentElement.dataset.theme=theme;
  try{localStorage.setItem("momentra-theme",theme);}catch{}
  studioTheme();
}
async function studioThemeSave() {
  if(studioThemeState.saving||!studioThemeState.pending)return;
  studioThemeState.saving=true;
  try {
    while(studioThemeState.pending){
      const theme=studioThemeState.pending,version=studioThemeState.version;
      try { await send("/api/settings",{theme},"PUT"); }
      catch {
        if(version!==studioThemeState.version)continue;
        const status=document.getElementById("themeSaveStatus");if(status)status.textContent="Theme saved on this device. Server save will retry when connected.";
        if(typeof toast==='function')toast("Theme changed on this device. The server save will retry when connected.","bad");
        break;
      }
      if(version!==studioThemeState.version)continue;
      studioThemeState.version++;
      studioThemeState.pending=null;
      try{if(localStorage.getItem("momentra-theme-pending")===theme)localStorage.removeItem("momentra-theme-pending");}catch{}
      const status=document.getElementById("themeSaveStatus");if(status)status.textContent="Color theme saved.";
    }
  } finally {studioThemeState.saving=false;}
}
function studioThemeChoose(theme) {
  studioThemeState.version++;studioThemeState.pending=theme;studioThemeApply(theme);
  try{localStorage.setItem("momentra-theme-pending",theme);}catch{}
  studioThemeSave();
}
function studioThemeSync(theme,version=studioThemeState.version) {
  if(version!==studioThemeState.version)return;
  if(studioThemeState.pending){studioThemeApply(studioThemeState.pending);studioThemeSave();return;}
  studioThemeApply(theme);
}
async function studioStatus() {
  const version=studioThemeState.version,status=await api("/api/status");
  studioThemeSync(status.theme,version);
  return {...status,theme:document.documentElement.dataset.theme};
}
window.addEventListener("online",()=>studioThemeSave());
window.addEventListener("storage",e=>{
  if(e.key!=="momentra-theme"&&e.key!=="momentra-theme-pending")return;
  let theme,pending;try{theme=localStorage.getItem("momentra-theme");pending=localStorage.getItem("momentra-theme-pending");}catch{return;}
  if(!["dark","light"].includes(theme))return;
  studioThemeState.version++;studioThemeState.pending=["dark","light"].includes(pending)?pending:null;studioThemeApply(theme);
  if(studioThemeState.pending)studioThemeSave();
});
document.addEventListener("click",e=>{
  if(e.target.closest("#themeToggle"))studioThemeChoose(document.documentElement.dataset.theme==="dark"?"light":"dark");
  const preset=e.target.closest("[data-crop-preset]");if(preset){
    const prefix=preset.dataset.prefix,index=Number(preset.dataset.cropPreset),v=readSplit(prefix);
    document.getElementById(prefix+"_face_x").value=index%2?100-v.face_w:0;
    document.getElementById(prefix+"_face_y").value=index>=2?100-v.face_h:0;studioCropOverlay();
  }
});
document.addEventListener("input",e=>{if(e.target.closest(".split-controls")){studioCropOverlay();studioPreview();}});
document.addEventListener("keydown",e=>{
  if(!["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(e.key))return;
  const tile=e.target.closest(".tile-o");if(!tile)return;
  const tiles=[...tile.parentElement.querySelectorAll(".tile-o")],i=tiles.indexOf(tile),next=tiles[(i+(["ArrowLeft","ArrowUp"].includes(e.key)?-1:1)+tiles.length)%tiles.length];
  e.preventDefault();next.focus();next.click();
});
studioTheme();
