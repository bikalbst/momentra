/* The checklist is tied to an export, not a promise of platform approval. */
(() => {
  let current = null, serial = 0, report = null, repairing = null, checking = false;
  const labels = {pass:'Pass',warning:'Review',blocked:'Blocked',unknown:'Could not check'};
  const escape = text => typeof esc === 'function' ? esc(String(text)) : String(text).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const selected = () => [...document.querySelectorAll('#clipdlg [data-pacc]:checked')].map(i => i.value);
  function draw() {
    const mount = document.getElementById('clipPreflight');
    if (!mount || !current) return;
    const dirty = window.momentraClipHasDraft?.();
    const rendering = ['queued','rendering'].includes(current.status);
    const loading = text => window.momentraLoading?.(text) || `<span role="status"><span class="spinner" aria-hidden="true"></span>${escape(text)}</span>`;
    const repairAction = report?.timing_blocked && report?.can_repair ? `<button type="button" class="btn primary" data-repair-timing ${dirty || repairing || current.status !== 'done' ? 'disabled' : ''}>${repairing ? 'Repair queued…' : 'Repair export timing'}</button><p class="help">Re-renders the saved cut and captions locally. Keeps the previous export. Does not upload or schedule posts.</p>` : '';
    mount.innerHTML = `<div class="preflight-heading"><div><h3>Before you post</h3><p class="help">Checks the saved export. Review the video yourself too.</p></div><button type="button" class="btn sm" data-check-clip ${rendering||checking?'disabled':''}>${checking?'Checking…':'Check again'}</button></div>` +
      (report?.posting_paused ? '<p class="preflight-draft" role="status">Posting is paused. Open Home and choose Resume posting to upload. Resuming also releases other due queued posts. Add to queue keeps this clip waiting.</p>' : '') +
      repairAction +
      (dirty ? '<p class="preflight-draft" role="status">You have unsaved edits. Save and re-make before posting.</p>' : '') +
      (rendering ? `<div class="preflight-result" aria-busy="true">${loading(current.status==='queued'?'Your clip is waiting to render…':'Rendering your clip…')}<p class="help">Publishing will be available when the saved export is ready and its checks finish.</p></div>` : checking || !report ? `<div class="help" aria-busy="true">${loading('Checking the export…')}</div>` :
        `<p class="preflight-result ${report.status}" role="status">${report.can_post ? 'Export checked' : 'Needs correction'} · version ${escape(report.version)}</p><ul class="preflight-list">${report.checks.map(c => `<li class="preflight-check ${c.status}"><span class="preflight-state">${labels[c.status] || 'Review'}</span><span>${escape(c.message)}</span></li>`).join('')}</ul>`)+
      (report?.timing_blocked && !report?.can_repair ? '<p class="preflight-draft" role="status">Timing repair is unavailable while video work or uploads are active, or if the saved source or captions are missing. Wait for work to finish and check again. If it remains unavailable, save and re-make the clip.</p>' : '') +
      (current.repair?.message ? `<p class="help" role="status">${escape(current.repair.message)}</p>` : '') +
      '<label class="ck safe-guide-toggle"><input type="checkbox" data-safe-guide>Show approximate platform safe zones</label><p class="help safe-guide-note">Dashed guides mark areas often covered by platform controls. They are not exact or automatic caption validation.</p>';
    const guide = document.getElementById('momentraSafeGuide');
    const toggle = mount.querySelector('[data-safe-guide]');
    if (guide && toggle) toggle.checked = !guide.hidden;
  }
  async function check() {
    if (!current) return null;
    const stamp = ++serial, pair = current;
    if (['queued','rendering'].includes(pair.status)) { checking=false;report=null;draw();return null; }
    checking=true;draw();
    const ids = selected();
    try {
      const result = await api(`/api/jobs/${encodeURIComponent(pair.jid)}/clips/${encodeURIComponent(pair.cid)}/preflight` + (ids.length ? `?accounts=${encodeURIComponent(ids.join(','))}` : ''));
      if (stamp !== serial || current !== pair) return null;
      report = result; checking=false;draw(); return result;
    } catch (error) {
      if (stamp !== serial || current !== pair) return null;
      report = {status:'blocked',can_post:false,version:pair.version,checks:[{status:'unknown',message:error.message || 'The export could not be checked. Try again before posting.'}]};
      checking=false;draw(); return report;
    }
  }
  async function repairTiming() {
    if (!current || repairing || !report?.timing_blocked || !report?.can_repair || current.status !== 'done') return;
    if (window.momentraClipHasDraft?.()) { toast('Save and re-make your edits before repairing this export.','bad'); return; }
    const pair = current, checked = report;
    repairing = pair; draw();
    let accepted = false;
    try {
      const message = 'Re-render the saved cut and saved captions locally to repair export timing? The previous export is kept. This does not upload, schedule posts or use AI.';
      const confirmed = typeof ask === 'function' ? await ask('Repair export timing?', message, 'Repair timing') : window.confirm(message);
      if (!confirmed || current !== pair) return;
      if (window.momentraClipHasDraft?.()) { toast('Save and re-make your edits before repairing this export.','bad'); return; }
      const result = await api(`/api/jobs/${encodeURIComponent(pair.jid)}/clips/${encodeURIComponent(pair.cid)}/repair-timing`, {
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({expected_version:checked.version,editor_revision:checked.editor_revision,confirm:true})
      });
      if (!result?.accepted) throw new Error('The timing repair was not accepted. Check the export and try again.');
      accepted = true;
      toast('Local timing repair queued. The previous export is kept.','ok');
      if (typeof tick === 'function') await tick();
    } catch (error) { toast(error.message || 'Timing repair could not be queued. The saved export is unchanged.','bad'); }
    finally {
      if (repairing === pair && (!accepted || current !== pair)) repairing = null;
      if (current === pair) draw();
    }
  }
  window.momentraPreflightOpen = (job, clip) => {
    current = {jid:job.id,cid:clip.id,version:clip.version,status:clip.status,revision:clip.editor_revision,repair:clip.timing_repair}; report = null;
    repairing = clip.timing_repair && ['queued','rendering'].includes(clip.timing_repair.status) ? current : null;
    document.getElementById('momentraSafeGuide')?.remove();
    draw(); check();
  };
  window.momentraPreflightRefresh = (job, clip) => {
    if (!current || current.jid !== job.id || current.cid !== clip.id) return;
    if (current.version !== clip.version || current.status !== clip.status || current.revision !== clip.editor_revision || current.repair?.status !== clip.timing_repair?.status) {
      current = {...current,version:clip.version,status:clip.status,revision:clip.editor_revision,repair:clip.timing_repair};
      repairing = clip.timing_repair && ['queued','rendering'].includes(clip.timing_repair.status) ? current : null;
      report = null; draw(); check();
    }
  };
  window.momentraPreflightBeforePost = async () => {
    if (window.momentraClipHasDraft?.()) {
      toast('Save and re-make your edits before posting this clip.','bad'); return null;
    }
    const result = await check();
    if (!result?.can_post) {
      toast('This export needs attention. Open Publish and review the checks.','bad'); return null;
    }
    return result;
  };
  document.addEventListener('click', event => {
    if (event.target.closest('[data-check-clip]')) check();
    if (event.target.closest('[data-repair-timing]')) repairTiming();
  });
  document.addEventListener('change', event => {
    if (event.target.matches('#clipdlg [data-pacc]')) check();
    if (event.target.matches('[data-safe-guide]')) {
      const stage = document.getElementById('stage');
      if (!stage) return;
      let guide = document.getElementById('momentraSafeGuide');
      if (!guide) { guide = document.createElement('div'); guide.id = 'momentraSafeGuide'; guide.className = 'safe-zone-guide'; guide.setAttribute('aria-hidden','true'); guide.innerHTML='<span>Approximate safe zone</span>'; stage.append(guide); }
      guide.hidden = !event.target.checked;
    }
  });
  document.addEventListener('momentra:editor-dirty', () => { if (current && report) draw(); });
  window.addEventListener('momentra:clip-dirty', () => { if (current && report) draw(); });
  document.getElementById('clipdlg')?.addEventListener('close', () => { current = null; report = null; repairing = null; serial++; });
  const styles = document.createElement('style'); styles.textContent = `
    .preflight-heading{display:flex;justify-content:space-between;align-items:start;gap:12px}.preflight-heading h3{margin:0 0 6px}.preflight-list{padding:0;list-style:none;display:grid;gap:0;margin:10px 0 16px}.preflight-check{display:grid;grid-template-columns:92px minmax(0,1fr);gap:10px;padding:10px 0;border-bottom:1px solid var(--line);font-size:12px;line-height:1.5}.preflight-state{font-size:10px;font-weight:700;align-self:start;border-radius:5px;padding:3px 6px;background:var(--muted);color:var(--dim);text-align:center}.preflight-check.pass .preflight-state{color:var(--good);background:var(--good-soft)}.preflight-check.blocked .preflight-state{color:var(--bad);background:var(--bad-soft)}.preflight-check.warning .preflight-state{color:var(--brand-deep);background:var(--brand-soft)}.preflight-result,.preflight-draft{padding:10px;border:1px solid var(--line);border-radius:8px;font-size:12px;line-height:1.5}.preflight-result.blocked,.preflight-draft{color:var(--bad);background:var(--bad-soft)}.safe-guide-note{font-size:11px}.safe-zone-guide{pointer-events:none;position:absolute;z-index:5;inset:10% 17% 23% 7%;border:1px dashed #ffd089;display:block}.safe-zone-guide[hidden]{display:none}.safe-zone-guide span{position:absolute;top:4px;left:4px;color:#ffd089;background:#211710;font-size:9px;padding:2px 5px}.editor .stage{position:relative}
  `; document.head.append(styles);
})();
