/* Candidate review is loaded separately and creates its own modal. No discovery data lives in sync. */
(() => {
  'use strict';
  let modal, jobId, offset = 0, filter = '', pending = false, generation = 0;
  const make = (tag, text, className) => {
    const el = document.createElement(tag);
    if (text !== undefined) el.textContent = text;
    if (className) el.className = className;
    return el;
  };
  const stamp = value => {
    const seconds = Math.max(0, Number(value) || 0);
    return `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
  };
  async function request(path, options) {
    const response = await fetch(path, {credentials: 'same-origin', ...options});
    const body = await response.json();
    if (!response.ok) throw new Error(body.detail || 'Candidate review could not load.');
    return body;
  }
  function mount() {
    if (modal) return;
    const style = make('style');
    style.textContent = '.momentra-candidates{position:fixed;inset:0;z-index:1800;background:transparent;border:0;width:100vw;height:100vh;max-width:none;max-height:none;padding:16px;box-sizing:border-box;margin:0}.momentra-candidates::backdrop{background:rgba(0,0,0,.65)}.momentra-candidates[open]{display:grid;place-items:center}.momentra-candidates:not([open]){display:none}.momentra-candidates-panel{background:var(--surface,#201c19);color:var(--text,#f5eee9);border:1px solid var(--line,#51463e);border-radius:12px;width:min(900px,100%);max-height:90vh;overflow:auto;padding:24px}.momentra-candidates-header,.momentra-candidates-tools{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.momentra-candidates-card{border-top:1px solid var(--line,#51463e);padding:18px 0}.momentra-candidates-meta{font-size:13px;opacity:.8}.momentra-candidates-evidence{white-space:pre-wrap;font-size:14px}.momentra-candidates button,.momentra-candidates select{font:inherit;background:var(--surface,#302720);color:inherit;border:1px solid var(--line,#675344);border-radius:6px;padding:8px 12px}.momentra-candidates button:hover{background:var(--brand-soft,#9b5b37)}.momentra-candidates button:disabled{opacity:.5}.momentra-candidates-status{padding:12px 0}';
    document.head.appendChild(style);
    modal = make('dialog', undefined, 'momentra-candidates');
    modal.setAttribute('role', 'dialog'); modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-labelledby', 'momentra-candidates-title');
    const panel = make('section', undefined, 'momentra-candidates-panel');
    const header = make('div', undefined, 'momentra-candidates-header');
    const title = make('h2', 'Candidate review'); title.id = 'momentra-candidates-title';
    const close = make('button', 'Close'); close.addEventListener('click', () => modal.close());
    header.append(title, close);
    const note = make('p', 'Candidates are scouting evidence, not ready clips. Discovery finishes before global selection. Promote explicitly to render a locally available source; provisional candidates cannot post.');
    const tools = make('div', undefined, 'momentra-candidates-tools');
    const select = make('select'); select.setAttribute('aria-label', 'Candidate verdict');
    for (const [value, label] of [['','All candidates'],['selected','Selected'],['rejected','Rejected'],['review','Review suggestions'],['provisional','Still scouting'],['promoted','Promoted']]) {
      const option = make('option', label); option.value = value; select.appendChild(option);
    }
    select.addEventListener('change', () => {filter = select.value; offset = 0; load();});
    const refresh = make('button', 'Refresh'); refresh.addEventListener('click', () => load());
    tools.append(select, refresh);
    const status = make('div', '', 'momentra-candidates-status'); status.id = 'momentra-candidates-status'; status.setAttribute('role','status');
    const rows = make('div'); rows.id = 'momentra-candidates-rows';
    const pages = make('div', undefined, 'momentra-candidates-tools'); pages.id = 'momentra-candidates-pages';
    panel.append(header, note, tools, status, rows, pages); modal.appendChild(panel); document.body.appendChild(modal);
    modal.addEventListener('click', event => {if (event.target === modal) modal.close();});
    modal.addEventListener('close', () => {generation++;});
  }
  async function promote(candidate, button) {
    if (pending || !candidate.can_promote) return;
    if (!window.confirm('Promote and render this candidate from the saved source? This is an explicit manual selection.')) return;
    pending = true; button.disabled = true;
    try {
      await request(`/api/jobs/${encodeURIComponent(jobId)}/candidates/${encodeURIComponent(candidate.id)}/promote`, {
        method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({confirm:true})
      });
      await load();
    } catch (error) {
      document.getElementById('momentra-candidates-status').textContent = error.message;
      button.disabled = false;
    } finally {pending = false;}
  }
  async function load() {
    const current = ++generation;
    const status = document.getElementById('momentra-candidates-status'); status.textContent = 'Loading candidates…';
    try {
      const data = await request(`/api/jobs/${encodeURIComponent(jobId)}/candidates?offset=${offset}&limit=25&verdict=${encodeURIComponent(filter)}`);
      if (current !== generation || !modal.open) return;
      const rows = document.getElementById('momentra-candidates-rows'); rows.replaceChildren();
      const summary = data.summary;
      status.textContent = summary ? `${summary.phase}: ${summary.selected} selected, ${summary.rejected} rejected, ${summary.review} review suggestions. ${summary.windows_done}/${summary.windows_total} scouting windows; ${summary.attempts}/${summary.budget} request attempts. ${summary.note || ''}` : 'This video has no saved candidate discovery yet.';
      for (const candidate of data.items) {
        const card = make('article', undefined, 'momentra-candidates-card');
        card.appendChild(make('h3', candidate.title || candidate.hook || 'Moment suggestion'));
        card.appendChild(make('p', `${stamp(candidate.start)} – ${stamp(candidate.end)} · score ${candidate.score} · ${candidate.verdict}${candidate.reject_code ? ' · ' + candidate.reject_code : ''}`, 'momentra-candidates-meta'));
        card.appendChild(make('p', candidate.verdict_reason || candidate.reason || ''));
        if (candidate.global_evidence) card.appendChild(make('p', `Setup: ${candidate.global_evidence.setup ? 'verified' : 'not verified'} · Payoff: ${candidate.global_evidence.payoff ? 'verified' : 'not verified'}. ${candidate.global_evidence.reason || ''}`, 'momentra-candidates-meta'));
        card.appendChild(make('p', `${candidate.provenance.method}${candidate.selection_fallback ? ' · ' + candidate.selection_fallback : ''} · source seconds · ${candidate.source_available ? 'source saved locally' : 'source not available locally'}`, 'momentra-candidates-meta'));
        if (candidate.related_id) card.appendChild(make('p', 'Compared with ' + candidate.related_id, 'momentra-candidates-meta'));
        const details = make('details'); details.appendChild(make('summary', 'Spoken evidence'));
        details.appendChild(make('p', candidate.evidence || 'No speech evidence; this suggestion is not a verified highlight.', 'momentra-candidates-evidence')); card.appendChild(details);
        if (candidate.verdict === 'review' || candidate.verdict === 'rejected') {
          const button = make('button', 'Promote and render'); button.disabled = !candidate.can_promote || pending;
          button.addEventListener('click', () => promote(candidate, button)); card.appendChild(button);
        }
        rows.appendChild(card);
      }
      const pages = document.getElementById('momentra-candidates-pages'); pages.replaceChildren();
      const back = make('button','Previous'); back.disabled = offset === 0;
      back.addEventListener('click', () => {offset = Math.max(0, offset - 25); load();});
      const next = make('button','Next'); next.disabled = data.next_offset === null;
      next.addEventListener('click', () => {offset = data.next_offset; load();});
      pages.append(back, make('span', `${data.total ? offset + 1 : 0}–${Math.min(offset + data.items.length, data.total)} of ${data.total}`), next);
    } catch (error) {if (current === generation) status.textContent = error.message;}
  }
  window.momentraCandidatesOpen = jid => {
    if (typeof jid !== 'string' || !/^[\w-]{8,60}$/.test(jid)) return;
    mount(); jobId = jid; offset = 0; if (!modal.open) modal.showModal(); load();
    modal.querySelector('button').focus();
  };
})();
