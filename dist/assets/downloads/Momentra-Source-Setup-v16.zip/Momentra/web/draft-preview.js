/* Playing local drafts. One source clock feeds the canvas, Timing and crop editors. */
(() => {
  'use strict';
  const W=1080,H=1920;
  const styles={
    bounce:{font:'Poppins ExtraBold',size:132,base:'FFFFFF',active:'00F0FF',strong:'FFFFFF',outline:7,pop:112,upper:true,per:3},
    hype:{font:'Anton',size:152,base:'FFFFFF',active:'3C3CFF',strong:'00D7FF',outline:7,pop:114,upper:true,per:2},
    clean:{font:'Poppins ExtraBold',size:100,base:'FFFFFF',active:'6BD7FF',strong:'FFFFFF',outline:5,pop:106,upper:false,per:4},
    karaoke:{font:'Poppins ExtraBold',size:122,base:'FFFFFF',active:'60EF79',strong:'FFFFFF',outline:6,pop:100,upper:true,per:3,mode:'steady'},
    neon:{font:'Archivo Black',size:122,base:'FFFFFF',active:'FFF040',strong:'FFFFFF',outline:4,pop:108,upper:true,per:3,glow:true},
    outline:{font:'Archivo Black',size:132,base:'FFFFFF',active:'FFFFFF',strong:'FFFFFF',outline:10,pop:100,upper:true,per:3,mode:'steady'},
    typewriter:{font:'Poppins ExtraBold',size:94,base:'FFFFFF',active:'FFFFFF',strong:'FFFFFF',outline:4,pop:100,upper:false,per:4,mode:'typewriter'},
    subtitle:{font:'Poppins ExtraBold',size:80,base:'FFFFFF',active:'FFFFFF',strong:'FFFFFF',outline:10,pop:100,upper:false,per:6,mode:'subtitle'}
  };
  const fonts={'Poppins ExtraBold':{em:1,shift:0},Anton:{em:1,shift:0},'Archivo Black':{em:1,shift:0}};
  const defaults={facecam_height:30,face_x:0,face_y:0,face_w:25,face_h:35,game_x:0,game_y:0,game_w:100,game_h:100,caption_x:50,caption_y:null,caption_size:100,caption_letter_spacing:0,caption_word_spacing:0,hook_x:50,hook_y:null,hook_size:100};
  let state=null, epoch=0, fontPromise=null;
  const $=s=>document.querySelector(s), clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), finite=(v,d=0)=>Number.isFinite(Number(v))&&v!==''&&v!=null?Number(v):d;
  const clean=t=>String(t??'').replace(/[{}\\]/g,'').replace(/[\x00-\x1f\x7f]+/g,' ').trim();
  const key=t=>t.toLowerCase().replace(/[^a-z0-9']/g,'');
  const colour=t=>'#'+t.slice(4,6)+t.slice(2,4)+t.slice(0,2);
  function geometry(w,h,layout) {
    if(['facecam_top','facecam_bottom','two_person'].includes(layout))return {layout,fg:H,hook:110,caption:layout==='facecam_bottom'?1040:1450};
    if(layout==='portrait')return {layout,fg:H,hook:300,caption:1380};
    if(h>=w&&layout!=='crop')layout='crop';
    const fg=layout==='blur'?Math.min(H,Math.round(W*h/w/2)*2):layout==='zoom'?1000:H,top=Math.floor((H-fg)/2);
    return {layout,fg,hook:layout==='crop'?300:Math.max(230,top-190),caption:layout==='crop'?1380:Math.min(1640,top+fg+180)};
  }
  function groups(words,per) {
    const result=[];let current=[];
    for(const word of words){if(current.length&&(current.length>=per||current.reduce((n,w)=>n+w.text.length,0)+word.text.length>16||word.start-current.at(-1).end>.45||/[.?!]$/.test(current.at(-1).text))){result.push(current);current=[];}current.push(word);}
    if(current.length)result.push(current);return result;
  }
  function snapshot() {
    const editor=window.momentraEditorSnapshot?.();if(!editor||state&&(editor.jid!==state.jid||editor.cid!==state.cid))return null;
    const fields={...defaults,...state?.clip};
    document.querySelectorAll('#clipdlg [data-f], .large-crop-dialog [data-f]').forEach(field=>{fields[field.dataset.f]=field.value;});
    for(const name of Object.keys(defaults)){const input=document.getElementById('edit_'+name);if(input)fields[name]=input.value===''?defaults[name]:finite(input.value,defaults[name]);}
    fields.style=$('#edit_style')?.value||fields.style||'bounce';fields.layout=$('#edit_layout')?.value||fields.layout||'blur';
    return Object.freeze({...editor,...fields,jid:editor.jid,cid:editor.cid,revision:editor.revision,editor_revision:editor.editor_revision,editor_rendered_revision:editor.editor_rendered_revision,rendered_cut:editor.rendered_cut,cut:editor.cut,words:editor.words,source:editor.source,highlight_words:state?.clip?.highlight_words||[],preview_mode:state?.mode||'draft'});
  }
  function font(ctx,name,size){ctx.font=`${size*(fonts[name]?.em||1)}px "${name}"`;}
  function width(ctx,text,size,name,tracking=0){font(ctx,name,size);return ctx.measureText(text).width+Math.max(0,[...text].length-1)*tracking;}
  function compile(ctx,s,w,h) {
    const g=geometry(w,h,s.layout),st={...(styles[s.style]||styles.bounce)};
    st.size=Math.trunc(st.size*clamp(finite(s.caption_size,100),50,200)/100);st.outline=Math.max(1,st.outline*finite(s.caption_size,100)/100);
    const tracking=clamp(finite(s.caption_letter_spacing),0,20),wordSpace=clamp(finite(s.caption_word_spacing),0,40);
    const cy=clamp(s.caption_y==null?g.caption:H*finite(s.caption_y)/100,st.size,H-st.size),cx=W*finite(s.caption_x,50)/100;
    const centre=total=>clamp(cx,total/2+12,W-total/2-12);
    const words=s.words.filter(w=>Number.isFinite(Number(w.start))&&Number.isFinite(Number(w.end))&&w.start>=s.cut.start-.05&&w.start<s.cut.end).map(w=>({...w,start:Number(w.start),end:Number(w.end),text:clean(w.text)})).filter(w=>w.text).sort((a,b)=>a.start-b.start);
    words.slice(0,-1).forEach((w,i)=>{w.end=Math.max(w.start,Math.min(w.end,words[i+1].start));});
    const grouped=groups(words,st.per),strong=new Set(s.highlight_words.map(t=>key(String(t))));
    const lines=grouped.map((items,i)=>{
      const start=Math.max(s.cut.start,items[0].start),end=Math.min(items.at(-1).end+.25,grouped[i+1]?.[0].start??s.cut.end),texts=items.map(w=>{const t=w.text.replace(/[.,;:]+$/,'');return st.upper?t.toUpperCase():t;});
      let size=st.size,gap=0,total=0;
      if(st.mode==='subtitle'||st.mode==='typewriter'){
        const line=texts.join(' ');size=Math.min(size,Math.max(36,Math.trunc(size*960/Math.max(1,width(ctx,line,size,st.font,tracking)+wordSpace*(items.length-1)))));
        total=width(ctx,line,size,st.font,tracking)+wordSpace*(items.length-1);
        const events=[];let prefix='';
        items.forEach((item,wi)=>{const a=Math.max(start,item.start),b=Math.min(end,items[wi+1]?.start??end),letters=[...texts[wi]];
          letters.forEach((_,ci)=>{const t0=a+(b-a)*ci/Math.max(1,letters.length)*.7,t1=ci+1<letters.length?a+(b-a)*(ci+1)/letters.length*.7:b;if(t1-t0>=.01)events.push({start:t0,end:t1,text:prefix+letters.slice(0,ci+1).join('')});});prefix+=texts[wi]+' ';});
        return {start,end,size,total,x:centre(total),y:cy,text:line,events,items,texts};
      }
      const calc=()=>{gap=width(ctx,'n n',size,st.font)-2*width(ctx,'n',size,st.font)+(2*st.outline+6)*size/st.size+wordSpace+tracking;total=texts.reduce((n,t)=>n+width(ctx,t,size,st.font,tracking),0)+gap*(items.length-1);};
      calc();if(total>960){size=Math.max(36,Math.trunc(size*960/total));calc();}
      let x=centre(total)-total/2;const placed=items.map((item,wi)=>{const text=texts[wi],wd=width(ctx,text,size,st.font,tracking),pop=st.mode==='steady'?100:Math.max(104,Math.min(st.pop,100+Math.trunc(2200/Math.max(wd,1))));
        const part={...item,text,x:x+wd/2,width:wd,pop,base:strong.has(key(item.text))?st.strong:st.base,activeEnd:items[wi+1]?.start??end};x+=wd+gap;return part;});
      return {start,end,size,total,x:centre(total),y:cy-size*(fonts[st.font]?.shift||0),items:placed};
    }).filter(line=>line.end-line.start>=.02);
    const text=clean(s.hook),hookWords=text.split(/\s+/).filter(Boolean);let hookSize=Math.trunc(96*clamp(finite(s.hook_size,100),50,200)/100),hookLines=[hookWords.join(' ')];
    const hw=t=>width(ctx,t,hookSize,'Poppins ExtraBold');
    if(hw(text)>900&&hookWords.length>1){let cut=1,best=Infinity;for(let i=1;i<hookWords.length;i++){const v=Math.max(hw(hookWords.slice(0,i).join(' ')),hw(hookWords.slice(i).join(' ')));if(v<best){best=v;cut=i;}}hookLines=[hookWords.slice(0,cut).join(' '),hookWords.slice(cut).join(' ')];}
    let widest=Math.max(...hookLines.map(hw));if(widest>900){hookSize=Math.max(40,Math.trunc(hookSize*900/widest));widest=Math.max(...hookLines.map(hw));}
    const lineH=hookSize*(fonts['Poppins ExtraBold'].em||1)*1.16,bw=widest+72,bh=lineH*hookLines.length+44;
    const hook={text,lines:hookLines,size:hookSize,lineH,width:bw,height:bh,x:clamp(W*finite(s.hook_x,50)/100,bw/2,W-bw/2),y:clamp(s.hook_y==null?g.hook:H*finite(s.hook_y)/100,bh/2,H-bh/2)};
    return {geometry:g,style:st,lines,hook,tracking,wordSpace};
  }
  function cover(rect,aspect){const r={...rect};if(r.w/r.h>aspect){const w=r.h*aspect;r.x+=(r.w-w)/2;r.w=w;}else{const h=r.w/aspect;r.y+=(r.h-h)/2;r.h=h;}return r;}
  function drawLayout(ctx,source,s,g,w=W,h=H){
    const sw=source.videoWidth||source.naturalWidth||source.width,sh=source.videoHeight||source.naturalHeight||source.height;if(!sw||!sh)return;
    const draw=(region,x,y,dw,dh)=>{let r=region?{x:Math.floor(sw*clamp(finite(s[region+'_x']),0,100)/100/2)*2,y:Math.floor(sh*clamp(finite(s[region+'_y']),0,100)/100/2)*2,w:Math.max(2,Math.floor(sw*clamp(finite(s[region+'_w'],100),5,100)/100/2)*2),h:Math.max(2,Math.floor(sh*clamp(finite(s[region+'_h'],100),5,100)/100/2)*2)}:{x:0,y:0,w:sw,h:sh};r.x=Math.min(r.x,sw-r.w);r.y=Math.min(r.y,sh-r.h);r=cover(r,dw/dh);ctx.drawImage(source,r.x,r.y,r.w,r.h,x,y,dw,dh);};
    if(g.layout==='portrait'){draw('face',0,0,w,h);return;}
    if(['facecam_top','facecam_bottom','two_person'].includes(g.layout)){const fh=g.layout==='two_person'?H/2:Math.floor(H*clamp(finite(s.facecam_height,30),20,45)/100/2)*2,faceH=fh/H*h,gameH=h-faceH,top=g.layout!=='facecam_bottom';draw('face',0,top?0:gameH,w,faceH);draw('game',0,top?faceH:0,w,gameH);return;}
    if(g.layout==='crop'){draw(null,0,0,w,h);return;}
    ctx.save();ctx.filter=`blur(${24*w/W}px) brightness(.72) saturate(1.15)`;draw(null,-w*.02,-h*.02,w*1.04,h*1.04);ctx.restore();const fg=g.fg/H*h;draw(null,0,(h-fg)/2,w,fg);
  }
  function text(ctx,t,x,y,size,name,ink,outline,tracking=0,wordSpace=0){
    font(ctx,name,size);ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineJoin='round';ctx.lineWidth=outline*2;ctx.strokeStyle='#000';ctx.fillStyle=colour(ink);
    if(!tracking&&!wordSpace){if(outline)ctx.strokeText(t,x,y);ctx.fillText(t,x,y);return;}
    const chars=[...t],measure=c=>ctx.measureText(c).width,total=chars.reduce((n,c)=>n+measure(c)+(c===' '?wordSpace:0),0)+Math.max(0,chars.length-1)*tracking;let left=x-total/2;
    for(const c of chars){const cw=measure(c)+(c===' '?wordSpace:0);if(outline)ctx.strokeText(c,left+cw/2,y);ctx.fillText(c,left+cw/2,y);left+=cw+tracking;}
  }
  function target(node,box,visible){node.hidden=!visible;if(!visible)return;Object.assign(node.style,{left:box.x/W*100+'%',top:box.y/H*100+'%',width:box.width/W*100+'%',height:box.height/H*100+'%'});}
  function paint(){
    const a=state;if(!a||!a.model)return;const ctx=a.canvas.getContext('2d');if(!ctx)return;
    if(a.mode==='saved'){a.surface.hidden=true;a.saved.hidden=false;return;}
    ctx.setTransform(a.canvas.width/W,0,0,a.canvas.height/H,0,0);ctx.fillStyle='#111';ctx.fillRect(0,0,W,H);
    const ready=a.video.readyState>=2&&a.video.videoWidth>0;if(ready)drawLayout(ctx,a.video,a.snapshot,a.model.geometry);
    const stamp=a.video.currentTime+a.offset,s=a.snapshot,m=a.model,st=m.style,line=m.lines.find(l=>l.start<=stamp&&stamp<l.end);
    if(line){if(st.mode==='subtitle'||st.mode==='typewriter'){const content=st.mode==='subtitle'?line.text:line.events.find(e=>e.start<=stamp&&stamp<e.end)?.text||'';
      if(st.mode==='subtitle'){ctx.fillStyle='rgba(24,24,24,.5)';ctx.fillRect(line.x-line.total/2-10,line.y-line.size/2-10,line.total+20,line.size+20);}text(ctx,content,line.x,line.y,line.size,st.font,st.base,st.mode==='subtitle'?0:st.outline,m.tracking,m.wordSpace);
    }else for(const item of line.items){const active=stamp>=item.start&&stamp<item.activeEnd,elapsed=stamp-item.start;let pop=1;
      if(st.mode!=='steady'){if(active)pop=elapsed<.09?(.94+(item.pop/100-.94)*clamp(elapsed/.09,0,1)):elapsed<.2?(item.pop/100-.05*(elapsed-.09)/.11):(item.pop-5)/100;else if(stamp>=item.activeEnd)pop=(item.pop-5)/100+(1-(item.pop-5)/100)*clamp((stamp-item.activeEnd)/.09,0,1);}
      ctx.save();ctx.translate(item.x,line.y);ctx.scale(pop,pop);if(st.glow){ctx.shadowColor='#2060aa';ctx.shadowBlur=12;}text(ctx,item.text,0,0,line.size,st.font,active?st.active:item.base,st.glow?6:st.outline,m.tracking);ctx.restore();}
    }
    const hookVisible=!!m.hook.text&&stamp>=s.cut.start&&stamp<s.cut.end;
    if(hookVisible){const hk=m.hook;ctx.save();ctx.globalAlpha=clamp((stamp-s.cut.start)/.16,0,1);ctx.fillStyle='#fff';ctx.beginPath();if(ctx.roundRect)ctx.roundRect(hk.x-hk.width/2,hk.y-hk.height/2,hk.width,hk.height,26);else ctx.rect(hk.x-hk.width/2,hk.y-hk.height/2,hk.width,hk.height);ctx.fill();hk.lines.forEach((t,i)=>text(ctx,t,hk.x,hk.y-hk.lineH*(hk.lines.length-1)/2+i*hk.lineH-hk.size*fonts['Poppins ExtraBold'].shift,hk.size,'Poppins ExtraBold','14100E',0));ctx.restore();}
    target(a.caption,line?{x:line.x,y:line.y,width:Math.max(90,line.total+24),height:line.size*1.5}:{},!!line&&ready);target(a.hook,m.hook,hookVisible&&ready);
    a.caption.setAttribute('aria-label',line?'Timed captions: '+(line.text||line.items.map(w=>w.text).join(' '))+'. Drag or use arrow keys to move.':'Timed captions position');
    a.hook.setAttribute('aria-label','Opening hook: '+m.hook.text+'. Drag or use arrow keys to move.');
    a.scrub.min=s.cut.start;a.scrub.max=s.cut.end;a.scrub.value=clamp(stamp,s.cut.start,s.cut.end);a.clock.textContent=`${Math.max(0,stamp-s.cut.start).toFixed(2)} / ${(s.cut.end-s.cut.start).toFixed(2)}s`;
    a.play.textContent=a.video.paused?'Play draft':'Pause draft';a.surface.hidden=a.mode!=='draft';a.saved.hidden=a.mode!=='saved';
    window.momentraEditorPlayhead?.(stamp);window.momentraDrawEditorSource?.();
  }
  function loop(){if(!state)return;state.raf=0;paint();if(state.mode==='draft'&&!state.video.paused){const end=state.snapshot?.cut.end;if(Number.isFinite(end)&&state.video.currentTime+state.offset>=end){state.video.pause();state.video.currentTime=Math.max(0,end-state.offset);paint();}else state.raf=requestAnimationFrame(loop);}}
  function animate(){if(state&&!state.raf)state.raf=requestAnimationFrame(loop);}
  function switchMode(mode){if(!state)return;state.mode=mode;if(mode==='draft')state.saved.querySelector('video')?.pause();else state.video.pause();state.root.querySelectorAll('[data-draft-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.draftMode===mode)));state.controls.querySelectorAll('[data-draft-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.draftMode===mode)));paint();}
  function seek(stamp){if(!state?.snapshot||!Number.isFinite(stamp))return;const a=state,b=a.snapshot.bounds;stamp=clamp(stamp,b.start,b.end-.01);if(a.fallback)stamp=clamp(stamp,a.fallback.start,a.fallback.end-.01);try{a.video.currentTime=Math.max(0,stamp-a.offset);}catch{}paint();}
  function refresh(){
    if(!state)return;const s=snapshot();if(!s)return;const a=state;a.snapshot=s;
    if(s.source.available&&!a.video.getAttribute('src')){a.offset=s.source.offset;a.video.src=s.source.url;}
    // Polling may refresh clip metadata, but never overwrite local field edits.
    const modelKey=JSON.stringify([s.revision,s.style,s.layout,s.hook,s.highlight_words,...Object.keys(defaults).map(k=>s[k]),a.video.videoWidth,a.video.videoHeight]);
    if(a.modelKey!==modelKey){a.model=compile(a.canvas.getContext('2d'),s,a.video.videoWidth||1920,a.video.videoHeight||1080);a.modelKey=modelKey;}
    a.note.textContent=!s.source.available?'Original source is missing. Saved export is still available.':a.error||'Draft · playing original source with timed captions. Fonts, blur and motion are approximate; Saved export is the final FFmpeg result.';
    a.play.disabled=!s.source.available;a.scrub.disabled=!s.source.available;
    if(a.video.readyState>=1&&!a.video.paused&&(a.video.currentTime+a.offset<s.cut.start||a.video.currentTime+a.offset>=s.cut.end))seek(s.cut.start);
    window.momentraBindDraftSource?.(a.video);paint();
  }
  async function localFallback(){
    if(!state?.snapshot||state.fallbackLoading)return;const a=state,token=epoch;a.fallbackLoading=true;a.fallbackButton.disabled=true;a.note.textContent='Making one bounded local H.264/AAC source preview…';
    try{const s=a.snapshot,start=s.cut.start,end=Math.min(s.bounds.end,Math.max(s.cut.end,start+3)),response=await fetch(`/api/jobs/${encodeURIComponent(s.jid)}/clips/${encodeURIComponent(s.cid)}/editor/source-preview`,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({start,end,editor_revision:s.editor_revision}),signal:a.controller.signal});const data=await response.json();if(!response.ok)throw Error(data.detail||'The local source preview could not be made.');if(token!==epoch||state!==a)return;const stamp=a.video.currentTime+a.offset;a.fallback={start:data.start,end:data.end};a.offset=data.offset;a.error='Draft · bounded local H.264/AAC source preview. Fonts, blur and motion approximate; Saved export is final.';a.video.src=data.url;a.pendingSeek=clamp(stamp,data.start,data.end-.01);a.fallbackButton.hidden=true;}
    catch(error){if(error.name!=='AbortError'&&state===a){a.error=error.message;refresh();}}finally{a.fallbackLoading=false;a.fallbackButton.disabled=false;}
  }
  function loadFonts(){if(fontPromise)return;fontPromise=(async()=>{try{const response=await fetch('/api/editor-preview/styles',{credentials:'same-origin'});if(!response.ok)return;const meta=await response.json();Object.assign(styles,meta.styles);Object.assign(fonts,meta.fonts);if(document.fonts)await Promise.all(Object.keys(fonts).map(name=>document.fonts.load(`100px "${name}"`)));if(state)state.modelKey=null;refresh();}catch{}})();}
  function close(){if(!state)return;const a=state;a.video.pause();a.saved.querySelector('video')?.pause();a.video.removeAttribute('src');a.video.load();cancelAnimationFrame(a.raf);a.controller.abort();state=null;epoch++;drag=null;a.surface.remove();a.controls.remove();while(a.saved.firstChild)a.root.append(a.saved.firstChild);a.saved.remove();}
  window.momentraDraftOpen=(j,c)=>{
    close();const root=$('#stage');if(!root)return;const saved=document.createElement('div');saved.className='draft-saved-export';while(root.firstChild)saved.append(root.firstChild);
    saved.querySelectorAll('video').forEach(v=>{v.pause();v.autoplay=false;v.removeAttribute('autoplay');});root.append(saved);
    const surface=document.createElement('div');surface.className='draft-surface';surface.innerHTML='<canvas width="540" height="960" aria-label="Playing 9:16 draft with your actual captions"></canvas><button type="button" class="draft-text-target" data-draft-text="caption" aria-label="Move timed captions. Drag or use arrow keys."></button><button type="button" class="draft-text-target" data-draft-text="hook" aria-label="Move opening hook. Drag or use arrow keys."></button>';root.append(surface);
    const controls=document.createElement('div');controls.className='draft-controls';controls.innerHTML='<div class="row"><button type="button" class="btn sm" data-draft-mode="draft" aria-pressed="true">Draft</button><button type="button" class="btn sm" data-draft-mode="saved" aria-pressed="false">Saved export</button></div><div class="row"><button type="button" class="btn sm" data-draft-play>Play draft</button><input type="range" step="0.01" aria-label="Draft playhead in source seconds" data-draft-scrub><span data-draft-clock></span></div><p class="preview-help" data-draft-note role="status">Loading original source and timed captions…</p><button type="button" class="btn sm" data-draft-fallback hidden>Make compatible local source preview</button>';root.after(controls);
    const video=document.createElement('video');video.hidden=true;video.playsInline=true;video.preload='auto';video.dataset.draftSource='true';surface.append(video);
    state={jid:j.id||j,cid:c.id||c,clip:c,root,surface,saved,controls,video,canvas:surface.querySelector('canvas'),caption:surface.querySelector('[data-draft-text=caption]'),hook:surface.querySelector('[data-draft-text=hook]'),note:controls.querySelector('[data-draft-note]'),play:controls.querySelector('[data-draft-play]'),scrub:controls.querySelector('[data-draft-scrub]'),clock:controls.querySelector('[data-draft-clock]'),fallbackButton:controls.querySelector('[data-draft-fallback]'),mode:'draft',offset:0,raf:0,controller:new AbortController()};
    const a=state;controls.addEventListener('click',e=>{const mode=e.target.closest('[data-draft-mode]');if(mode)switchMode(mode.dataset.draftMode);if(e.target.closest('[data-draft-play]')){switchMode('draft');if(video.paused){if(a.snapshot&&video.currentTime+a.offset>=a.snapshot.cut.end-.01)seek(a.snapshot.cut.start);video.play().catch(()=>{});}else video.pause();}if(e.target.closest('[data-draft-fallback]'))localFallback();});a.scrub.oninput=()=>seek(Number(a.scrub.value));
    video.addEventListener('loadedmetadata',()=>{if(state!==a)return;seek(a.pendingSeek??a.snapshot?.cut.start??a.offset);a.pendingSeek=null;refresh();});video.addEventListener('loadeddata',refresh);video.addEventListener('seeked',paint);video.addEventListener('timeupdate',paint);video.addEventListener('play',()=>{if(state!==a)return;switchMode('draft');animate();});video.addEventListener('pause',paint);video.addEventListener('error',()=>{if(state!==a)return;a.error='This original format cannot play here. Make a compatible local source preview once; drag and style edits never encode video.';a.fallbackButton.hidden=false;refresh();});
    saved.addEventListener('play',()=>{switchMode('saved');},true);loadFonts();refresh();
  };
  window.momentraDraftRefresh=(j,c)=>{if(!state)return;if(state.jid!==(j.id||j)||state.cid!==(c.id||c))return;state.clip=c;refresh();};
  window.momentraDraftSavedExport=markup=>{if(!state)return false;const saved=state.saved,video=saved.querySelector('video');video?.pause();saved.innerHTML=markup;saved.querySelectorAll('video').forEach(v=>{v.autoplay=false;v.removeAttribute('autoplay');});paint();return true;};
  window.momentraDraftChanged=refresh;window.momentraDraftClose=close;
  window.momentraDraftSnapshot=()=>state?.snapshot||null;
  window.momentraDraftSource=()=>state?.video||null;
  window.momentraDraftSeek=seek;window.momentraDraftMode=switchMode;
  window.momentraDraftDrawLayout=(canvas,source,s)=>{const ctx=canvas.getContext('2d');if(ctx)drawLayout(ctx,source,s,geometry(source.videoWidth||source.width||1920,source.videoHeight||source.height||1080,s.layout),canvas.width,canvas.height);};
  window.momentraDraftPreviewMath=Object.freeze({geometry,groups,compile,drawLayout});
  let drag=null;
  document.addEventListener('pointerdown',e=>{const node=e.target.closest('[data-draft-text]');if(!node||!state)return;const bounds=state.surface.getBoundingClientRect();if(!bounds.width||!bounds.height)return;e.preventDefault();node.focus();node.setPointerCapture?.(e.pointerId);const kind=node.dataset.draftText,box=state.model[kind==='hook'?'hook':'lines'];const x=finite(state.snapshot[kind+'_x'],50),y=state.snapshot[kind+'_y']??state.model.geometry[kind]/H*100;drag={id:e.pointerId,kind,x,y,sx:e.clientX,sy:e.clientY,bounds};});
  function writePosition(kind,x,y){for(const[k,v]of Object.entries({x,y})){const field=$('#edit_'+kind+'_'+k);if(field)field.value=clamp(v,0,100).toFixed(3);}refresh();window.momentraClipDraftChanged?.();}
  document.addEventListener('pointermove',e=>{if(!drag||e.pointerId!==drag.id)return;e.preventDefault();writePosition(drag.kind,drag.x+(e.clientX-drag.sx)/drag.bounds.width*100,drag.y+(e.clientY-drag.sy)/drag.bounds.height*100);},{passive:false});
  for(const name of ['pointerup','pointercancel','lostpointercapture'])document.addEventListener(name,e=>{if(drag?.id===e.pointerId)drag=null;});
  document.addEventListener('keydown',e=>{const node=e.target.closest('[data-draft-text]');if(!node||!state||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();const kind=node.dataset.draftText,s=state.snapshot,step=e.shiftKey?5:1;writePosition(kind,finite(s[kind+'_x'],50)+(e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0),(s[kind+'_y']??state.model.geometry[kind]/H*100)+(e.key==='ArrowUp'?-step:e.key==='ArrowDown'?step:0));});
  for(const name of ['input','change','click'])document.addEventListener(name,e=>{if(e.target.closest('#clipdlg,.large-crop-dialog'))queueMicrotask(refresh);});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)state?.video.pause();});
})();
