/* Visible progress for user actions; background sync never flashes a loader. */
(() => {
  let clicked=null,clickedAt=0,pending=0,timer=null;
  const counts=new WeakMap();
  const style=document.createElement('style');
  style.textContent=`.spinner,.request-busy::before{display:inline-block;width:16px;height:16px;flex:0 0 auto;box-sizing:border-box;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;animation:momentra-spin .8s linear infinite;vertical-align:middle}.spinner{margin-right:8px}.request-busy::before{content:'';margin-right:7px}.loading-line{display:flex;align-items:center;justify-content:center;gap:4px;line-height:1.6}.making{display:flex;align-items:center;justify-content:center;gap:4px}.making .spinner{width:24px;height:24px}.request-indicator{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:10020;padding:10px 16px;border:1px solid var(--line);border-radius:9px;background:var(--panel,var(--bg));color:var(--text);font-size:12px;pointer-events:none}.request-indicator[hidden]{display:none}.media-wait{position:absolute;inset:0;display:grid;place-content:center;z-index:8;pointer-events:none;background:#15121099;color:#fff}.media-wait[hidden]{display:none}.stage{position:relative}@keyframes momentra-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.spinner,.request-busy::before{animation-duration:2.5s}}`;
  document.head.append(style);
  window.momentraLoading=text=>`<span class="loading-line" role="status"><span class="spinner" aria-hidden="true"></span>${String(text).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}</span>`;
  document.addEventListener('click',event=>{clicked=event.target.closest?.('button');clickedAt=Date.now();},true);
  window.momentraRequestStarted=(path,options)=>{
    if(!options?.method||options.method==='GET')return()=>{};
    const button=Date.now()-clickedAt<1000&&clicked?.isConnected?clicked:null;
    if(button){counts.set(button,(counts.get(button)||0)+1);button.classList.add('request-busy');button.setAttribute('aria-busy','true');}
    pending++;
    if(!timer)timer=setTimeout(()=>{
      timer=null;if(!pending)return;
      let indicator=document.getElementById('requestIndicator');
      if(!indicator){indicator=document.createElement('div');indicator.id='requestIndicator';indicator.className='request-indicator';indicator.innerHTML=window.momentraLoading('Working…');document.body.append(indicator);}
      indicator.hidden=false;
    },180);
    let ended=false;
    return()=>{
      if(ended)return;ended=true;pending=Math.max(0,pending-1);
      if(button){const count=Math.max(0,(counts.get(button)||1)-1);counts.set(button,count);if(!count){button.classList.remove('request-busy');button.removeAttribute('aria-busy');}}
      if(!pending){clearTimeout(timer);timer=null;const indicator=document.getElementById('requestIndicator');if(indicator)indicator.hidden=true;}
    };
  };
  const bound=new WeakSet();
  function bind(){
    document.querySelectorAll('#stage video').forEach(video=>{
      if(bound.has(video))return;bound.add(video);
      const parent=video.parentElement;
      const hasSource=()=>Boolean(video.currentSrc||video.getAttribute('src')||video.querySelector('source[src]'));
      const wait=document.createElement('span');wait.className='media-wait';wait.innerHTML=window.momentraLoading('Loading video…');wait.hidden=video.readyState>=3||!hasSource();parent.append(wait);
      const show=()=>{if(video.isConnected&&hasSource())wait.hidden=false;},hide=()=>{wait.hidden=true;};
      for(const name of ['loadstart','waiting','stalled'])video.addEventListener(name,show);
      for(const name of ['canplay','playing','error','ended','pause','emptied'])video.addEventListener(name,hide);
    });
  }
  new MutationObserver(bind).observe(document.documentElement,{subtree:true,childList:true});bind();
})();
