/* Local suggestions only alter the draft after an explicit Apply. */
(() => {
  let state=null, pending=null, serial=0;
  const labels={facecam_top:'Facecam top',facecam_bottom:'Facecam bottom',two_person:'Two people · 50:50',portrait:'Single-person portrait'};
  const escText=value=>typeof esc==='function'?esc(String(value)):String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function mount() {
    const panel=document.getElementById('clipPanel-layout')||document.getElementById('clipSection-layout')||document.querySelector('#clipdlg [data-editor-section="layout"]');
    if(!panel)return null;
    let box=document.getElementById('autoFramingPanel');
    if(!box){box=document.createElement('section');box.id='autoFramingPanel';box.className='auto-framing-panel';panel.prepend(box);}
    return box;
  }
  function draw(message='Select a framing mode, then analyze the locally saved source. No video is sent to an AI service.') {
    const box=mount();if(!box)return;
    const layout=document.getElementById('edit_layout')?.value;
    const mode=pending?.mode||(layout in labels?layout:'facecam_top');
    box.innerHTML=`<h3>Auto frame</h3><div class="row"><label class="f">Framing mode<select data-auto-mode>${Object.entries(labels).map(([key,label])=>`<option value="${key}" ${key===mode?'selected':''}>${label}</option>`).join('')}</select></label><button class="btn" type="button" data-auto-analyze>Analyze source</button></div><p class="help" role="status">${escText(message)}</p>`+
      (pending?.suggestion?`<p class="help">Confidence: ${escText(pending.confidence)} · ${pending.sample_count||0} samples. Stable crop suggestion—not perfect tracking.</p><div class="row"><button class="btn primary" type="button" data-auto-apply>Apply to draft</button><button class="btn" type="button" data-auto-discard>Discard suggestion</button></div>`:'')+
      `<button class="btn sm" type="button" data-auto-swap ${layout!=='two_person'?'hidden':''}>Swap top / bottom people</button>`;
  }
  function dirty() {window.studioSplitVisibility?.();window.studioCropOverlay?.();window.momentraDraftChanged?.();window.momentraClipDraftChanged?.();document.dispatchEvent(new CustomEvent('momentra:framing-draft'));}
  window.momentraAutoFrameOpen=(job,clip)=>{state={jid:job.id,cid:clip.id,revision:clip.editor_revision||0,start:clip.start,end:clip.end};pending=null;serial++;draw();};
  window.momentraAutoFrameClose=()=>{state=null;pending=null;serial++;};
  async function analyze(button) {
    if(!state)return;
    const token=++serial,ids=state;
    const mode=document.querySelector('[data-auto-mode]')?.value||'facecam_top';
    let changes={};try{changes=window.momentraEditorChanges?.()||{};}catch(error){draw(error.message);return;}
    button.disabled=true;
    try {
      const report=await send(`/api/jobs/${encodeURIComponent(ids.jid)}/clips/${encodeURIComponent(ids.cid)}/framing`,{mode,start:changes.start??ids.start,end:changes.end??ids.end,editor_revision:changes.editor_revision??ids.revision});
      if(token!==serial||state!==ids)return;
      pending=report;draw(report.message||'Review the proposed source regions before applying.');
    }catch(error){if(token===serial&&state===ids){pending=null;draw(error.message||'Framing could not be checked. Use manual crops.');}}
    finally{if(button.isConnected)button.disabled=false;}
  }
  document.addEventListener('click',event=>{
    const b=event.target.closest('[data-auto-analyze],[data-auto-apply],[data-auto-discard],[data-auto-swap]');if(!b)return;
    if(b.hasAttribute('data-auto-analyze')){analyze(b);return;}
    if(b.hasAttribute('data-auto-discard')){pending=null;draw();return;}
    if(b.hasAttribute('data-auto-swap')){
      for(const key of ['x','y','w','h']){const a=document.getElementById('edit_face_'+key),z=document.getElementById('edit_game_'+key);if(a&&z){const old=a.value;a.value=z.value;z.value=old;}}dirty();return;
    }
    if(!pending?.suggestion)return;
    let changes;try{changes=window.momentraEditorChanges?.()||{};}catch(error){draw(error.message);return;}
    if(pending.editor_revision!==(changes.editor_revision??state.revision)||pending.start!==(changes.start??state.start)||pending.end!==(changes.end??state.end)){pending=null;draw('The cut changed after analysis. Analyze the new cut before applying.');return;}
    for(const [key,value]of Object.entries(pending.suggestion)){
      const input=document.getElementById(key==='layout'?'edit_layout':'edit_'+key);if(input){input.value=String(value);input.dispatchEvent(new Event('input',{bubbles:true}));}
    }
    const layout=pending.suggestion.layout;
    document.querySelectorAll('[data-seg="edit_layout"]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.v===layout)));
    dirty();pending=null;draw('Framing applied to your draft. Review the playing preview, then save and re-make.');
  });
  document.addEventListener('click',event=>{if(event.target.closest('[data-seg="edit_layout"]'))setTimeout(()=>draw(),0);});
  const observer=new MutationObserver(()=>{
    if(!document.getElementById('clipdlg')?.open){if(state)window.momentraAutoFrameClose();return;}
    if(document.getElementById('edit_layout')&&!document.getElementById('autoFramingPanel')&&typeof D!=='undefined'&&D.jid){const j=typeof jobOf==='function'?jobOf(D.jid):null,c=j?.clips.find(c=>c.id===D.cid);if(j&&c)window.momentraAutoFrameOpen(j,c);}
  });
  const dialog=document.getElementById('clipdlg');if(dialog)observer.observe(dialog,{childList:true,subtree:true,attributes:true,attributeFilter:['open']});
  const css=document.createElement('style');css.textContent='.auto-framing-panel{border:1px solid var(--line);background:var(--surface);padding:14px;border-radius:10px;margin-bottom:18px}.auto-framing-panel h3{margin:0 0 10px}.auto-framing-panel .row{align-items:end;flex-wrap:wrap}.auto-framing-panel .f{flex:1;min-width:180px}.auto-framing-panel .help{margin:10px 0}.two-person-thumb .mini-face,.two-person-thumb .mini-game{height:50%}';document.head.append(css);
})();
