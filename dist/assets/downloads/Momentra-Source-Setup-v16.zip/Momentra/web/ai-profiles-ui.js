/* Provider profiles contain only public metadata here. Passwords stay in the input until explicitly sent. */
let momentraAIGeneration = 0;
function momentraAIProfile() {
  const p = document.getElementById('ai_provider')?.value;
  return S.ai?.profiles?.[p] || {models: [], base_url: '', has_key: false, ready: false, saved_here: false};
}
function momentraAIHints() {
  const sel = document.getElementById('ai_provider'); if (!sel || !S.ai) return;
  const pv = S.ai.providers.find(x => x.id === sel.value); if (!pv) return;
  const row = momentraAIProfile();
  document.getElementById('ai_key').placeholder = row.has_key ? 'A key is saved. Leave blank to keep it.' : pv.needs_key ? 'Paste your key' : 'Optional for this service';
  document.getElementById('ai_keyhint').innerHTML = `${pv.key_url ? `Get ${pv.needs_key ? 'a key' : 'started'} at <a href="${esc(pv.key_url)}" target="_blank" rel="noopener">${esc(pv.key_url.replace('https://', ''))}</a>. ` : ''}Keys stay on this server. No key or part of a key is shown. A blank password keeps this service's saved key.`;
  document.getElementById('ai_model').placeholder = pv.example ? 'For example ' + pv.example : 'The exact model id';
  document.getElementById('ai_base').placeholder = pv.address || 'http://127.0.0.1:1234/v1';
  document.getElementById('ai_profile_state').textContent = `${sel.value === S.ai.active_provider ? 'Active service' : 'Not active'} · ${row.saved_here ? 'Profile saved here' : row.models.length ? 'Environment settings' : 'No saved profile'} · ${row.has_key ? 'Key saved' : pv.needs_key ? 'No key saved' : 'Key not required'}`;
  document.querySelector('[data-act="airemove"]').disabled = !row.saved_here || !row.has_key;
  document.querySelector('[data-act="aiuse"]').disabled = !row.models.length;
  document.querySelector('[data-act="aitest"]').disabled = !row.ready;
  const freeFilter=document.getElementById('aiFreeFilter');if(freeFilter)freeFilter.hidden=sel.value!=='numes';
  const providerNote=document.getElementById('aiProviderNote');if(providerNote)providerNote.textContent=sel.value==='numes'?'Choose a model ending in :free for free inference. Free models still have rate limits and may require a verified email. The encrypted :e2ee API is not supported here.':sel.value==='nocode'?'Enter a documented OpenAI-compatible API base address. No default NoCode endpoint has been verified; adding a key alone does not establish compatibility.':'';
  window.momentraDrawBackupKeys?.();
}
function momentraAISelect() {
  momentraAIGeneration++;
  const row = momentraAIProfile();
  document.getElementById('ai_key').value = '';
  document.getElementById('ai_model').value = row.models.join(', ');
  document.getElementById('ai_base').value = row.base_url || '';
  document.getElementById('ai_models').innerHTML = '';
  momentraAIHints();
}
async function momentraDrawAI(body, selected = '') {
  const generation = ++momentraAIGeneration;
  const k = await api('/api/ai');
  if (!body.isConnected || generation !== momentraAIGeneration) return;
  S.ai = k;
  const pick = k.providers.some(p => p.id === selected) ? selected : k.active_provider;
  body.innerHTML = `<section class="set-sec" id="ai_settings"><h2>AI profiles</h2><p class="help">Keep a separate model, address and key for each AI service. Selecting a service only restores its settings; it does not save, switch the active service or contact a provider. You pay the service directly. Local clipping still works without AI.</p>
    <div class="ai-state">${k.ready ? `<span class="pill ok">Ready</span>` : `<span class="pill warn">Not set up</span>`}<span class="sub">Active: ${esc(k.label || 'None')} ${k.models[0] ? '· ' + esc(k.models[0]) : ''}</span></div>
    <div class="ai-form">
      <label class="f">AI service<select id="ai_provider">${k.providers.map(p => `<option value="${esc(p.id)}" ${p.id === pick ? 'selected' : ''}>${esc(p.label)}</option>`).join('')}</select><span class="hint" id="ai_profile_state" role="status"></span></label>
      <label class="f">Key<input id="ai_key" type="password" autocomplete="new-password" spellcheck="false"><span class="hint" id="ai_keyhint"></span></label>
      <label class="f" id="ai_basewrap">Address override<input id="ai_base" spellcheck="false"><span class="hint">Leave blank for the service's normal address. Required for Custom. Do not put keys in the address.</span></label>
      <label class="f">Models<span class="with"><input id="ai_model" list="ai_models" spellcheck="false"><button class="btn" type="button" data-act="aimodels">Find models</button></span><datalist id="ai_models"></datalist><span class="hint">Up to five model ids, separated by commas, in fallback order. For NVIDIA through OpenRouter, choose OpenRouter and enter its NVIDIA model id. This remains an OpenRouter profile.</span></label>
      <label class="ck" id="aiFreeFilter" hidden><input id="aiFreeOnly" type="checkbox" checked>Show only free Numes models when finding models</label><p class="help" id="aiProviderNote"></p>
    </div>
    <p class="help">Save profile keeps the other profiles and does not test. Use profile switches to the saved settings, ignoring unsaved fields. Test profile contacts only the selected saved profile; save changes first. Find models is also an explicit network request.</p>
    <div class="row" style="margin-top:20px"><button class="btn primary" type="button" data-act="aisave">Save profile</button><button class="btn" type="button" data-act="aiuse">Use profile</button><button class="btn" type="button" data-act="aitest">Test profile</button><button class="btn danger" type="button" data-act="airemove">Remove saved key</button></div>
    <p class="help" id="ai_action_status" role="status" aria-live="polite"></p></section>`;
  momentraAISelect();
  window.momentraDrawFailover?.(body.querySelector('#ai_settings'));
}
async function momentraAIAction(action, button) {
  const section = document.getElementById('ai_settings'); if (!section) return;
  const provider = document.getElementById('ai_provider').value;
  const generation = momentraAIGeneration;
  const status = document.getElementById('ai_action_status');
  if (section.dataset.busy) return;
  if (action === 'airemove' && !await ask('Remove this service\'s saved key?', 'Only the selected service\'s key is removed. Its models and address and every other profile stay unchanged. Requests already in progress keep their captured settings.', 'Remove key')) return;
  if (!section.isConnected || generation !== momentraAIGeneration) return;
  const keyInput = document.getElementById('ai_key');
  const baseInput = document.getElementById('ai_base');
  const modelInput = document.getElementById('ai_model');
  section.dataset.busy = '1';
  section.querySelectorAll('button, input, select').forEach(el => el.disabled = true);
  status.textContent = action === 'aitest' || action === 'aimodels' ? 'Contacting the selected service…' : 'Saving locally…';
  if(window.momentraLoading)status.innerHTML=window.momentraLoading(status.textContent);
  try {
    if (action === 'aimodels') {
      const r = await send('/api/ai/models', {provider, base_url: document.getElementById('ai_base').value, key: document.getElementById('ai_key').value});
      if (!section.isConnected || generation !== momentraAIGeneration) return;
      const models=r.models.filter(m=>!m.split(':').includes('e2ee')).filter(m=>provider!=='numes'||!document.getElementById('aiFreeOnly')?.checked||m.split(':').includes('free'));
      document.getElementById('ai_models').innerHTML = models.map(m => `<option value="${esc(m)}"></option>`).join('');
      status.textContent = models.length ? `${models.length} models found. Pick one in the model box.` : 'No matching models were listed. Check availability or type the model id yourself.';
    } else if (action === 'aitest') {
      const r = await send('/api/ai/test', {provider});
      if (section.isConnected && generation === momentraAIGeneration) status.textContent = `${r.model} answered. The selected saved profile works. Nothing was saved or switched.`;
    } else {
      let r;
      if (action === 'aisave') r = await send('/api/ai', {provider, models: modelInput.value, base_url: baseInput.value, key: keyInput.value, activate: false}, 'PUT');
      else if (action === 'aiuse') r = await send('/api/ai/use', {provider});
      else if (action === 'airemove') r = await send('/api/ai', {provider, remove_key: true, confirm_remove_key: true, activate: false}, 'PUT');
      else return;
      keyInput.value = '';
      if (!section.isConnected || generation !== momentraAIGeneration) return;
      S.ai = r;
      S.status = await studioStatus(); drawShell();
      if (!section.isConnected || generation !== momentraAIGeneration) return;
      await momentraDrawAI(document.getElementById('setbody'), provider);
      const message = action === 'aisave' ? 'Profile saved locally. Other profiles were kept. No test was made.' : action === 'aiuse' ? 'Saved profile is now active. No test was made.' : 'Only this service\'s saved key was removed.';
      const next = document.getElementById('ai_action_status'); if (next) next.textContent = message;
      toast(message, 'ok');
    }
  } catch (error) {
    if (section.isConnected && generation === momentraAIGeneration) status.textContent = 'The action failed. ' + error.message;
    toast(error.message, 'bad');
  } finally {
    delete section.dataset.busy;
    if (section.isConnected) {
      section.querySelectorAll('button, input, select').forEach(el => el.disabled = false);
      momentraAIHints();
    }
  }
}
