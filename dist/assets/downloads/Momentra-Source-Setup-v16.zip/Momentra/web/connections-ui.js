/* OAuth stays separate from the application window. No tokens enter the page. */
let connectionTimer=null,connectionAttempt=null;
function connectionDialog() {
  let dialog=document.getElementById('connectionDialog');
  if(!dialog){dialog=document.createElement('dialog');dialog.id='connectionDialog';document.body.append(dialog);
    dialog.addEventListener('close',()=>{
      clearTimeout(connectionTimer);
      if(connectionAttempt){const attempt=connectionAttempt;connectionAttempt=null;api('/api/connections/'+encodeURIComponent(attempt),{method:'DELETE'}).catch(()=>{});}
    });
  }
  return dialog;
}
async function beginConnection(platform) {
  const dialog=connectionDialog(),names={youtube:'YouTube',instagram:'Instagram',tiktok:'TikTok'},name=names[platform];
  if(!name)return;
  if(dialog.open)dialog.close();
  dialog.innerHTML=`<div class="dlg" style="width:530px"><div class="row"><h2 style="flex:1">Connect ${name}</h2><button class="btn sm" type="button" data-connection-close>Close</button></div><p role="status">Preparing sign-in…</p></div>`;
  dialog.showModal();
  try{
    const attempt=await send('/api/connections/'+platform,{});
    if(!dialog.open)return api('/api/connections/'+encodeURIComponent(attempt.state),{method:'DELETE'});
    connectionAttempt=attempt.state;
    dialog.innerHTML=`<div class="dlg" style="width:530px"><div class="row"><h2 style="flex:1">Connect ${name}</h2><button class="btn sm" type="button" data-connection-close>Close</button></div>
      <p class="help">Sign in in your normal browser. Momentra stays open here. You can close the browser tab after sign-in finishes.</p>
      ${platform==='instagram'?'<p class="help">Momentra uses your Instagram account identity and publishing permission to post approved Reels. Choose the account you want to post to when Meta asks. This integration does not read your DMs or use ads.</p>':''}
      <div class="row"><button class="btn primary" type="button" id="openProviderSignIn">Open ${name} sign-in</button></div>
      <p id="connectionStatus" role="status">Ready to open your browser.</p>
      <details ${platform!=='youtube'?'hidden':''}><summary style="cursor:pointer">If Google shows redirect_uri_mismatch</summary><p class="help" style="margin:12px 0">The callback must match your OAuth client. For a Google Web application client, add this exact address under Authorized redirect URIs in Google Cloud, save it, then try again.</p>
      <div class="copyrow"><code style="overflow-wrap:anywhere">${esc(attempt.redirect)}</code><button class="btn sm" data-act="copytext" data-t="${esc(attempt.redirect)}">Copy</button></div><p class="help" style="margin-top:12px">Use your own OAuth client and enable YouTube Data API v3. This address stays the same in the desktop app.</p></details></div>`;
    document.getElementById('openProviderSignIn').addEventListener('click',async e=>{
      try{
        if(window.pywebview?.api?.open_connection){await window.pywebview.api.open_connection(attempt.url);}
        else{
          const popup=window.open(attempt.url,'_blank','popup,width=640,height=760,noopener,noreferrer');
          // Some browsers return null when noopener is requested, even when the tab opened.
        }
        document.getElementById('connectionStatus').textContent='Waiting for sign-in in your browser. If you cancel or see an error there, close this dialog to return to Settings.';
        e.target.textContent='Open sign-in again';
      }catch(error){document.getElementById('connectionStatus').textContent='Could not open the browser: '+error.message;}
    });
    const poll=async()=>{
      if(!dialog.open||connectionAttempt!==attempt.state)return;
      try{
        const result=await api('/api/connections/'+encodeURIComponent(attempt.state));
        if(result.status==='select_account'){
          document.getElementById('openProviderSignIn').hidden=true;
          document.getElementById('connectionStatus').textContent=result.message;
          let choices=document.getElementById('instagramAccountChoices');
          if(!choices){
            choices=document.createElement('div');choices.id='instagramAccountChoices';
            choices.innerHTML=`<label class="f">Instagram account<select id="instagramAccountChoice">${(result.accounts||[]).map(a=>`<option value="${esc(a.id)}">${esc(a.name)}</option>`).join('')}</select></label><button class="btn primary" type="button">Connect selected account</button>`;
            dialog.querySelector('.dlg').append(choices);
            choices.querySelector('button').addEventListener('click',async e=>{
              e.target.disabled=true;
              try{await send('/api/connections/'+encodeURIComponent(attempt.state)+'/select',{account:document.getElementById('instagramAccountChoice').value});await poll();}
              catch(error){document.getElementById('connectionStatus').textContent=error.message;e.target.disabled=false;}
            });
          }
          return;
        }
        if(result.status!=='pending'){
          connectionAttempt=null;
          document.getElementById('connectionStatus').textContent=result.status==='connected'?`${result.name||name} is connected. You can close this dialog.`:result.message||'Sign-in did not finish. Close this dialog and try again.';
          document.getElementById('openProviderSignIn').hidden=true;
          if(result.status==='connected'){await tick();S.status=await api('/api/status');if(S.view==='settings')drawSettings();}
          return;
        }
      }catch(error){document.getElementById('connectionStatus').textContent='Could not check sign-in: '+error.message;}
      connectionTimer=setTimeout(poll,2000);
    };
    connectionTimer=setTimeout(poll,1500);
  }catch(error){dialog.querySelector('[role=status]').textContent=error.message;}
}
document.addEventListener('click',e=>{
  const button=e.target.closest('[data-connect-platform]');if(button){e.preventDefault();beginConnection(button.dataset.connectPlatform);}
  if(e.target.closest('[data-connection-close]'))connectionDialog().close();
});
