/* Real source previews and output-matched, draggable crop frames. */
const framingState={key:'',epoch:0,item:null,video:null,ready:false,message:'Add a video to see its preview.',poll:null,raf:0,lastFrame:0,editImage:null,active:{o:'face',edit:'face'},drag:null};
const frameClamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0));
function framingSource(prefix){
  if(prefix==='edit') {const v=window.momentraDraftSource?.();if(v?.videoWidth&&v.readyState>=2)return {media:v,w:v.videoWidth,h:v.videoHeight};const img=framingState.editImage;return img?.isConnected&&img.naturalWidth?{media:img,w:img.naturalWidth,h:img.naturalHeight}:null;}
  const v=framingState.video;return framingState.ready&&v?.videoWidth?{media:v,w:v.videoWidth,h:v.videoHeight}:null;
}
function frameSettings(prefix){return {...SPLIT_DEFAULTS,...readSplit(prefix)};}
function frameLayout(prefix){return document.getElementById(prefix==='edit'?'edit_layout':'o_layout')?.value||'blur';}
function frameCover(rect,aspect){
  const out={...rect};if(out.w/out.h>aspect){const width=out.h*aspect;out.x+=(out.w-width)/2;out.w=width;}
  else{const height=out.w/aspect;out.y+=(out.h-height)/2;out.h=height;}return out;
}
function effectiveFrame(prefix,region){
  const s=frameSettings(prefix),source=framingSource(prefix);
  const w=frameClamp(s[region+'_w'],5,100),h=frameClamp(s[region+'_h'],5,100);
  const rect={x:frameClamp(s[region+'_x'],0,100-w),y:frameClamp(s[region+'_y'],0,100-h),w,h};
  if(!source)return rect;
  const layout=frameLayout(prefix),portion=layout==='two_person'?50:layout==='portrait'?100:region==='face'?frameClamp(s.facecam_height,20,45):100-frameClamp(s.facecam_height,20,45);
  return frameCover(rect,(9/16)/(portion/100)/(source.w/source.h));
}
function storeFraming(){if(framingState.item&&document.getElementById('o_face_x'))framingState.item.framing=readSplit('o');}
function writeFrame(prefix,region,rect){
  for(const k of ['x','y','w','h']){const field=document.getElementById(prefix+'_'+region+'_'+k);if(field)field.value=Number(rect[k].toFixed(3));}
  if(prefix==='o')storeFraming();
}
function addFrameHandles(surface){
  const prefix=surface.dataset.cropPrefix;
  if(!surface.querySelector('.adjust-crop')){
    const button=document.createElement('button');button.type='button';button.className='btn sm adjust-crop';button.dataset.adjustCrop=prefix;button.textContent='Adjust crop ⛶';surface.append(button);
  }
  for(const box of surface.querySelectorAll('.crop-box')){
    const region=box.dataset.region||(box.classList.contains('face-crop')?'face':'game');box.dataset.region=region;
    box.tabIndex=0;box.setAttribute('role','group');box.setAttribute('aria-label',(region==='face'?'Facecam':'Gameplay')+' crop. Drag to move; use corner handles to resize. Arrow keys move; Shift moves faster.');
    if(!box.querySelector('.resize-handle')) for(const handle of ['nw','ne','sw','se']){
      const el=document.createElement('span');el.className='resize-handle handle-'+handle;el.dataset.handle=handle;el.setAttribute('aria-hidden','true');box.append(el);
    }
    const r=effectiveFrame(prefix,region);Object.assign(box.style,{left:r.x+'%',top:r.y+'%',width:r.w+'%',height:r.h+'%'});
    box.classList.toggle('active-frame',framingState.active[prefix]===region);
  }
}
function momentraCropOverlay(){
  document.querySelectorAll('[data-crop-prefix]').forEach(addFrameHandles);
  document.querySelectorAll('[data-frame-region]').forEach(button=>button.setAttribute('aria-pressed',String(framingState.active[button.dataset.framePrefix]===button.dataset.frameRegion)));
}
function frameDrawImage(ctx,source,rect,x,y,w,h){
  const pixels={x:rect.x/100*source.w,y:rect.y/100*source.h,w:rect.w/100*source.w,h:rect.h/100*source.h};
  const crop=frameCover(pixels,w/h);ctx.drawImage(source.media,crop.x,crop.y,crop.w,crop.h,x,y,w,h);
}
function drawOutput(canvas,prefix){
  const source=framingSource(prefix);if(!source)return;
  const ctx2=canvas.getContext('2d');if(!ctx2)return;
  const w=canvas.width,h=canvas.height,s=frameSettings(prefix),layout=frameLayout(prefix);
  ctx2.fillStyle='#111';ctx2.fillRect(0,0,w,h);
  if(window.momentraDraftDrawLayout){window.momentraDraftDrawLayout(canvas,source.media,{...s,layout});return;}
  if(layout.startsWith('facecam_')||layout==='two_person'){
    const faceH=layout==='two_person'?h/2:Math.floor(1920*frameClamp(s.facecam_height,20,45)/100/2)*2/1920*h,gameH=h-faceH,top=layout!=='facecam_bottom';
    frameDrawImage(ctx2,source,effectiveFrame(prefix,'face'),0,top?0:gameH,w,faceH);
    frameDrawImage(ctx2,source,effectiveFrame(prefix,'game'),0,top?faceH:0,w,gameH);
  }else if(layout==='crop'||source.h>=source.w){frameDrawImage(ctx2,source,{x:0,y:0,w:100,h:100},0,0,w,h);}
  else{
    ctx2.save();ctx2.filter='blur(10px) brightness(.6)';frameDrawImage(ctx2,source,{x:0,y:0,w:100,h:100},-15,-15,w+30,h+30);ctx2.restore();
    const fh=layout==='zoom'?h*(1000/1920):Math.min(h,w*source.h/source.w);
    frameDrawImage(ctx2,source,{x:0,y:0,w:100,h:100},0,(h-fh)/2,w,fh);
  }
}
function drawFraming(){
  const source=framingSource('o');
  if(source){
    const output=document.getElementById('liveFramingCanvas');if(output)drawOutput(output,'o');
    document.querySelectorAll('[data-crop-prefix=o] canvas').forEach(canvas=>{
      if(canvas.width!==960||canvas.height!==Math.round(960*source.h/source.w)){canvas.width=960;canvas.height=Math.round(960*source.h/source.w);}
      const ctx2=canvas.getContext('2d');if(ctx2)ctx2.drawImage(source.media,0,0,canvas.width,canvas.height);
    });
    const slider=document.getElementById('previewScrub');if(slider&&document.activeElement!==slider){slider.max=String(framingState.video.duration||8);slider.value=String(framingState.video.currentTime||0);}
    const largeScrub=document.getElementById('largeCropScrub');if(largeScrub&&document.activeElement!==largeScrub){largeScrub.max=String(framingState.video.duration||8);largeScrub.value=String(framingState.video.currentTime||0);}
    const label=document.getElementById('previewTime');if(label)label.textContent=fmtLen((framingState.item?.url&&!framingState.item.live?Number(att().previewAt)||0:0)+(framingState.video.currentTime||0));
  }
  document.querySelectorAll('canvas[data-large-output]').forEach(canvas=>drawOutput(canvas,canvas.dataset.largeOutput));
}
function frameLoop(now){
  framingState.raf=0;if(!framingState.ready||!document.getElementById('demoCanvas')||document.hidden)return;
  if(now-framingState.lastFrame>=33){drawFraming();framingState.lastFrame=now;}
  if(!framingState.video.paused)framingState.raf=requestAnimationFrame(frameLoop);
}
function frameAnimate(){if(!framingState.raf)framingState.raf=requestAnimationFrame(frameLoop);}
function frameVideo(){
  if(framingState.video)return framingState.video;
  const video=document.createElement('video');video.muted=true;video.loop=true;video.playsInline=true;video.preload='auto';video.hidden=true;
  document.body.append(video);framingState.video=video;
  video.addEventListener('loadeddata',()=>{framingState.ready=true;framingState.message=framingState.item?.live?'Captured live sample · refresh for a newer moment · sample captions':'Live framing preview · caption text is illustrative';momentraRefresh();drawFraming();video.play().catch(()=>{});});
  video.addEventListener('playing',frameAnimate);video.addEventListener('seeked',()=>{drawFraming();momentraCropOverlay();});
  video.addEventListener('pause',drawFraming);
  video.addEventListener('error',()=>{framingState.ready=false;framingState.message='This video could not play in the preview. Try loading the excerpt again, or use an MP4 file.';momentraRefresh();});
  return video;
}
function previewList(){
  const a=att(),list=[...a.links.filter(l=>l.state==='ok').map(item=>({key:'link:'+item.id,item,label:item.info?.title||item.url})),...a.files.filter(f=>f.state!=='done').map(item=>({key:'file:'+item.id,item,label:item.file.name}))];
  const c=creator();
  if(c){
    const on=liveOn(c),picked=on.find(([key])=>key===S.spick?.[c.id])||on[0];
    const channel=picked?.[1]?.channel||(c.live_job?c.channel:'');
    if(channel){
      a.liveSamples ||= {};
      const item=a.liveSamples[channel] ||= {id:'live:'+c.id+':'+channel,url:channel,live:true,creator_id:c.id,info:{title:c.name+' live'},framing:Object.fromEntries(Object.entries(SPLIT_DEFAULTS).map(([key,value])=>[key,c[key]??value]))};
      list.push({key:item.id,item,label:c.name+' · Live sample'});
    }
  }
  return list;
}
function ensurePreviewUI(){
  const root=document.getElementById('demoCanvas');if(!root)return;
  if(!document.getElementById('liveFramingCanvas')){
    const c=document.createElement('canvas');c.id='liveFramingCanvas';c.width=360;c.height=640;c.setAttribute('aria-label','Preview of the selected layout using your video');root.prepend(c);
    const note=document.createElement('div');note.id='previewEmpty';root.append(note);
    const aside=root.closest('.studio-demo');aside.insertAdjacentHTML('beforeend',`<div class="real-preview-controls"><label class="f">Preview source<select id="previewSource"></select></label><div class="row preview-play-row"><button type="button" class="btn sm" id="previewPlay">Play / pause</button><input id="previewScrub" type="range" aria-label="Seek within preview" min="0" max="8" step="0.05" value="0"><span id="previewTime">0:00</span></div><div class="preview-excerpt"><label class="f">Preview from (seconds)<input type="number" min="0" step="1" id="previewAt" value="0"></label><button type="button" class="btn sm" id="loadPreviewExcerpt">Load 8-second preview</button></div><p id="realPreviewStatus" role="status"></p></div>`);
    document.getElementById('previewSource').addEventListener('change',e=>{storeFraming();att().previewKey=e.target.value;att().previewAt=0;framingState.key='';momentraSyncSource();});
    document.getElementById('previewPlay').addEventListener('click',()=>{const v=framingState.video;if(!framingState.ready||!v)return;if(v.paused)v.play().catch(()=>{});else v.pause();});
    document.getElementById('previewScrub').addEventListener('input',e=>{if(framingState.ready)framingState.video.currentTime=Number(e.target.value);});
    const jump=document.createElement('button');jump.type='button';jump.className='btn sm preview-jump';jump.id='previewSkipIntro';jump.textContent='Preview +5 minutes';jump.title='For recorded streams: inspect a later moment without changing the clipping range.';
    aside.querySelector('.preview-excerpt').after(jump);
    jump.addEventListener('click',()=>{
      const item=framingState.item;if(!item?.url||item.live)return;
      const duration=Number(item.info?.duration)||604800;
      att().previewAt=Math.min(Math.max(0,duration-8),(Number(att().previewAt)||0)+300);
      framingState.key='';momentraSyncSource(true);
    });
    document.getElementById('loadPreviewExcerpt').addEventListener('click',()=>{
      if(framingState.item?.live){att().liveSampleRequested=true;att().liveSampleGeneration=(att().liveSampleGeneration||0)+1;}
      else att().previewAt=frameClamp(document.getElementById('previewAt').value,0,604800);
      framingState.key='';momentraSyncSource(true);
    });
  }
}
function momentraRefresh(){
  ensurePreviewUI();
  const root=document.getElementById('demoCanvas');
  if(root){
    root.classList.add('real-source-preview');root.classList.toggle('has-source-video',framingState.ready);
    const empty=document.getElementById('previewEmpty');if(empty){empty.hidden=framingState.ready;empty.textContent=framingState.message;}
    const caption=document.getElementById('demoCaption');if(caption)caption.hidden=!framingState.ready;
    const status=document.getElementById('realPreviewStatus');if(status)status.textContent=framingState.message;
    const foot=root.closest('.studio-demo').querySelector('.demo-footer>span');if(foot)foot.textContent=framingState.item?.live?'Captured live sample':framingState.ready?'Your video · sample captions':'Source preview';
  }
  document.querySelectorAll('.framing-source-note').forEach(el=>{el.textContent=framingState.ready?'Original source · drag the active frame or resize its corners.':framingState.message;});
  momentraCropOverlay();drawFraming();
  if(window.momentraCaptionRefresh)momentraCaptionRefresh();
}
async function loadRemotePreview(item,epoch,retry){
  try{
    let result=item.live?await send('/api/creators/'+encodeURIComponent(item.creator_id)+'/preview-live',{channel:item.url,retry:!!retry}):await send('/api/video-previews',{url:item.url,start:Number(att().previewAt)||0,retry:!!retry});
    const poll=async()=>{
      if(epoch!==framingState.epoch)return;
      if(result.status==='ready'){framingState.message='Opening your video excerpt…';frameVideo().src='/api/video-previews/'+encodeURIComponent(result.id)+'/video';momentraRefresh();return;}
      if(result.status==='error'){framingState.message=result.message;momentraRefresh();return;}
      framingState.message=result.message||'Loading an 8-second excerpt…';momentraRefresh();
      framingState.poll=setTimeout(async()=>{try{result=await api('/api/video-previews/'+encodeURIComponent(result.id));await poll();}catch(error){if(epoch===framingState.epoch){framingState.message=error.message;momentraRefresh();}}},1200);
    };await poll();
  }catch(error){if(epoch===framingState.epoch){framingState.message=error.message;momentraRefresh();}}
}
function momentraSyncSource(retry=false){
  if(typeof att!=='function')return;
  ensurePreviewUI();
  const list=previewList(),a=att(),selected=list.find(x=>x.key===a.previewKey)||list[0];
  if(selected)a.previewKey=selected.key;
  const select=document.getElementById('previewSource');if(select){
    const markup=list.length?list.map(x=>`<option value="${esc(x.key)}">${esc(x.label)}</option>`).join(''):'<option value="">Add a video first</option>';
    if(select.innerHTML!==markup)select.innerHTML=markup;if(selected)select.value=selected.key;
  }
  const key=selected?draftKey()+':'+selected.key+':'+(selected.item.live?'live-'+(a.liveSampleGeneration||0):selected.item.url?Number(a.previewAt)||0:'local'):'';
  const jump=document.getElementById('previewSkipIntro');if(jump)jump.hidden=!selected?.item.url||!!selected.item.live;
  if(key===framingState.key){momentraRefresh();return;}
  clearTimeout(framingState.poll);framingState.epoch++;framingState.key=key;framingState.ready=false;
  if(framingState.video){framingState.video.pause();framingState.video.removeAttribute('src');framingState.video.load();}
  framingState.item=selected?.item||null;
  if(!selected){framingState.message='Add a video to see its preview.';momentraRefresh();return;}
  selected.item.framing ||= {...SPLIT_DEFAULTS,...readSplit('o')};
  const settings=selected.item.framing;
  for(const [k,v] of Object.entries(settings)){const field=document.getElementById('o_'+k);if(field)field.value=v;}
  const offset=document.getElementById('previewAt');if(offset)offset.value=String(a.previewAt||0);
  if(offset)offset.closest('label').hidden=!!selected.item.live;
  const loadButton=document.getElementById('loadPreviewExcerpt');if(loadButton)loadButton.textContent=selected.item.live?'Load / refresh live sample':'Load 8-second preview';
  document.querySelector('.preview-excerpt')?.classList.toggle('is-local',!selected.item.url);
  if(selected.item.live&&!a.liveSampleRequested){framingState.message='Load a short live sample to frame this creator. This does not start a recording or create clips.';momentraRefresh();return;}
  framingState.message=selected.item.url?'Loading an 8-second video excerpt…':'Opening your video file…';momentraRefresh();
  if(selected.item.url)loadRemotePreview(selected.item,framingState.epoch,retry);else frameVideo().src=selected.item.src;
}
function momentraBindEditorSource(img){if(!img?.isConnected)return;framingState.editImage=img;momentraCropOverlay();if(window.momentraCaptionRefresh)momentraCaptionRefresh();}
function momentraDrawEditorSource(){
  const source=framingSource('edit');if(!source)return;
  document.querySelectorAll('[data-crop-prefix=edit]').forEach(surface=>{surface.classList.toggle('has-draft-source',!!window.momentraDraftSource?.()?.videoWidth);});
  document.querySelectorAll('[data-crop-prefix=edit] canvas').forEach(canvas=>{
    const height=Math.round(960*source.h/source.w);if(canvas.width!==960||canvas.height!==height){canvas.width=960;canvas.height=height;}
    canvas.getContext('2d')?.drawImage(source.media,0,0,canvas.width,canvas.height);
  });
  document.querySelectorAll('canvas[data-large-output=edit]').forEach(canvas=>drawOutput(canvas,'edit'));
}
window.momentraDrawEditorSource=momentraDrawEditorSource;
window.momentraBindDraftSource=()=>{momentraCropOverlay();momentraDrawEditorSource();};
function editorFramingPreview(){
  if(window.momentraDraftSource?.()){window.momentraDraftChanged?.();momentraDrawEditorSource();return;}
  const stage=document.getElementById('stage');if(!stage||!framingSource('edit'))return;
  stage.querySelector('video')?.pause();
  stage.classList.remove('show-caption-position');
  let canvas=stage.querySelector('.editor-framing-canvas');if(!canvas){canvas=document.createElement('canvas');canvas.className='editor-framing-canvas';canvas.width=360;canvas.height=640;stage.append(canvas);}
  stage.classList.add('show-framing');drawOutput(canvas,'edit');
  let note=document.querySelector('.framing-edit-note');if(!note){note=document.createElement('div');note.className='framing-edit-note preview-help';note.innerHTML='Framing preview · source still frame. <button type="button" class="btn sm" id="watchRenderedClip">Watch rendered clip</button>';stage.parentElement.append(note);note.querySelector('button').onclick=()=>{stage.classList.remove('show-framing','show-caption-position');note.remove();};}
}
function frameResize(rect,handle,dx,dy){
  const ratio=rect.w/rect.h,left=handle.includes('w'),top=handle.includes('n'),ax=left?rect.x+rect.w:rect.x,ay=top?rect.y+rect.h:rect.y;
  let width=Math.abs(dx)>=Math.abs(dy*ratio)?rect.w+(left?-dx:dx):rect.w+(top?-dy:dy)*ratio;
  const maxW=Math.min(left?ax:100-ax,(top?ay:100-ay)*ratio),minW=Math.min(maxW,Math.max(5,5*ratio));
  width=frameClamp(width,minW,maxW);const height=width/ratio;
  return {x:left?ax-width:ax,y:top?ay-height:ay,w:width,h:height};
}
document.addEventListener('pointerdown',e=>{
  const box=e.target.closest('.crop-box[data-region]'),surface=box?.closest('[data-crop-prefix]');if(!surface)return;
  const prefix=surface.dataset.cropPrefix;if(!framingSource(prefix))return;
  const bounds=surface.getBoundingClientRect();if(!bounds.width||!bounds.height)return;
  e.preventDefault();framingState.active[prefix]=box.dataset.region;box.focus();box.setPointerCapture?.(e.pointerId);
  framingState.drag={id:e.pointerId,prefix,region:box.dataset.region,handle:e.target.dataset.handle||'',x:e.clientX,y:e.clientY,bounds,rect:effectiveFrame(prefix,box.dataset.region)};momentraCropOverlay();
});
document.addEventListener('pointermove',e=>{
  const d=framingState.drag;if(!d||d.id!==e.pointerId)return;e.preventDefault();
  const dx=(e.clientX-d.x)/d.bounds.width*100,dy=(e.clientY-d.y)/d.bounds.height*100;
  const r=d.handle?frameResize(d.rect,d.handle,dx,dy):{...d.rect,x:frameClamp(d.rect.x+dx,0,100-d.rect.w),y:frameClamp(d.rect.y+dy,0,100-d.rect.h)};
  writeFrame(d.prefix,d.region,r);momentraCropOverlay();drawFraming();if(d.prefix==='edit')editorFramingPreview();
},{passive:false});
for(const event of ['pointerup','pointercancel','lostpointercapture'])document.addEventListener(event,e=>{if(framingState.drag?.id===e.pointerId)framingState.drag=null;});
document.addEventListener('keydown',e=>{
  const box=e.target.closest('.crop-box[data-region]'),surface=box?.closest('[data-crop-prefix]');if(!surface||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;
  const prefix=surface.dataset.cropPrefix;if(!framingSource(prefix))return;e.preventDefault();
  const r=effectiveFrame(prefix,box.dataset.region),step=e.shiftKey?5:1;r.x=frameClamp(r.x+(e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0),0,100-r.w);r.y=frameClamp(r.y+(e.key==='ArrowUp'?-step:e.key==='ArrowDown'?step:0),0,100-r.h);
  writeFrame(prefix,box.dataset.region,r);momentraCropOverlay();drawFraming();if(prefix==='edit')editorFramingPreview();
});
document.addEventListener('click',e=>{const b=e.target.closest('[data-frame-region]');if(b){framingState.active[b.dataset.framePrefix]=b.dataset.frameRegion;b.parentElement.querySelectorAll('button').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));momentraCropOverlay();}});
document.addEventListener('click',async e=>{
  const button=e.target.closest('#saveCreatorFraming');if(!button)return;
  const c=creator();if(!c)return;button.disabled=true;
  try{
    storeFraming();
    const body={...readSplit('o'),style:document.getElementById('o_style').value,layout:document.getElementById('o_layout').value,quality:Number(document.getElementById('o_quality').value)};
    await send('/api/creators/'+encodeURIComponent(c.id),body,'PUT');await tick();
    const message=document.getElementById('creatorFramingSaveStatus');if(message)message.textContent='Saved. New clips and future recordings use this framing. Existing clips keep their settings.';
    toast('Creator framing saved','ok');
  }catch(error){toast(error.message,'bad');}finally{button.disabled=false;}
});
document.addEventListener('input',e=>{if(e.target.closest('.split-controls')){if(e.target.id.startsWith('o_'))storeFraming();if(e.target.id.startsWith('edit_'))editorFramingPreview();}});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)frameAnimate();});
const framingStyles=document.createElement('style');framingStyles.textContent=`
.real-source-preview .demo-face,.real-source-preview .demo-game{display:none!important}.real-source-preview{position:relative;display:block}.real-source-preview canvas{display:none;width:100%;height:100%;object-fit:contain}.real-source-preview.has-source-video canvas{display:block}#previewEmpty{position:absolute;inset:0;display:grid;place-items:center;text-align:center;padding:24px;color:#c9c0b9;font-size:13px}.real-preview-controls{border-top:1px solid var(--line);margin-top:10px;padding-top:12px;display:grid;gap:12px}.real-preview-controls label{font-size:11px}.preview-play-row{flex-wrap:nowrap;font-size:11px}.preview-play-row input{flex:1;min-width:30px}.preview-play-row .btn{padding:0 8px;font-size:10px}.preview-play-row>span{font-variant-numeric:tabular-nums}.preview-excerpt{display:flex;gap:7px;align-items:end}.preview-excerpt.is-local{display:none}.preview-excerpt label{flex:1;min-width:0}.preview-excerpt .btn{font-size:10px;padding:0 8px;height:40px}#realPreviewStatus{font-size:11px;line-height:1.6;color:var(--dim)}
.visual-framing{margin:12px 0}.visual-framing .source-crop{border-radius:8px;background:#151515}.visual-framing canvas{display:block;width:100%;height:auto}.framing-source-note{font-size:11px;color:var(--dim);margin-top:8px}.crop-box{pointer-events:auto;cursor:move;touch-action:none;outline:none;border-width:2px;min-width:1px;min-height:1px}.crop-box:focus-visible{outline:2px solid #fff;outline-offset:3px}.crop-box:not(.active-frame){opacity:.6}.crop-box.active-frame{z-index:4;opacity:1;background:#ff8b330d}.crop-box.game-crop.active-frame{background:#58c8b50d}.resize-handle{position:absolute;width:12px;height:12px;background:#fff;border:2px solid var(--brand);border-radius:2px;z-index:2}.game-crop .resize-handle{border-color:#58c8b5}.handle-nw{left:-6px;top:-6px;cursor:nwse-resize}.handle-ne{right:-6px;top:-6px;cursor:nesw-resize}.handle-sw{left:-6px;bottom:-6px;cursor:nesw-resize}.handle-se{right:-6px;bottom:-6px;cursor:nwse-resize}.frame-region-tabs .btn[aria-pressed=true]{border-color:var(--brand);background:var(--selection)}.editor-framing-canvas{display:none;max-width:100%;max-height:calc(100vh - 210px);height:100%;width:auto;object-fit:contain}.stage.show-framing>video,.stage.show-framing>img{display:none!important}.stage.show-framing .editor-framing-canvas{display:block}.framing-edit-note{padding-top:6px}.framing-edit-note .btn{font-size:10px;height:28px;margin-top:6px}.source-crop>img{user-select:none;-webkit-user-drag:none}
`;document.head.append(framingStyles);
const creatorFramingStyles=document.createElement('style');creatorFramingStyles.textContent=`
.creator-framing-workspace{display:grid;grid-template-columns:minmax(0,1fr) 290px;gap:22px;align-items:start;margin-bottom:24px}.creator-framing-workspace .composer.compact{margin-bottom:0}.creator-preview{top:80px}.creator-preview #saveCreatorFraming{width:100%;height:auto;min-height:40px;font-size:12px;padding:9px;margin:12px 0 0;white-space:normal}.creator-preview .preview-help{font-size:10px;line-height:1.6}.creator-framing-workspace .caption-choices{grid-template-columns:repeat(3,minmax(0,1fr))}.creator-framing-workspace .layout-choices{grid-template-columns:repeat(3,minmax(0,1fr))}.creator-framing-workspace .studio-demo{display:block}
@media(max-width:1100px){.creator-framing-workspace{grid-template-columns:minmax(0,1fr)}.creator-preview{position:static;max-width:330px;justify-self:center;width:100%}}
`;document.head.append(creatorFramingStyles);

/* Move the existing controls into a larger dialog, retaining values and source playback. */
let largeCrop=null;
function cropSnapshot(prefix){return {...readSplit(prefix)};}
function cropRestore(values){
  if(!largeCrop)return;
  for(const [key,value] of Object.entries(values)){const input=document.getElementById(largeCrop.prefix+'_'+key);if(input)input.value=value;}
  if(largeCrop.prefix==='o')storeFraming();
  momentraCropOverlay();drawFraming();if(largeCrop.prefix==='edit')editorFramingPreview();
}
function cropRemember(){
  if(!largeCrop)return;const value=cropSnapshot(largeCrop.prefix),last=largeCrop.history.at(-1);
  if(JSON.stringify(last)!==JSON.stringify(value))largeCrop.history.push(value);
  if(largeCrop.history.length>50)largeCrop.history.shift();
  const undo=document.getElementById('largeCropUndo');if(undo)undo.disabled=!largeCrop.history.length;
}
function cropFinish(apply=false){
  if(!largeCrop)return;const state=largeCrop;
  if(!apply){
    const layout=document.querySelector('[data-seg='+state.prefix+'_layout][data-v="'+state.beforeLayout+'"]');
    if(frameLayout(state.prefix)!==state.beforeLayout&&layout)layout.click();
    cropRestore(state.before);
  }
  state.marker.replaceWith(state.controls);largeCrop=null;
  if(state.dialog.open)state.dialog.close();state.dialog.remove();
  momentraCropOverlay();drawFraming();
  if(state.prefix==='edit')editorFramingPreview();
  state.trigger?.focus();
}
function openLargeCrop(prefix,trigger){
  if(largeCrop)return;
  const surface=document.querySelector('[data-crop-prefix="'+prefix+'"]'),controls=surface?.closest('.split-controls');
  if(!surface||!controls)return;
  if(!framingSource(prefix)){toast('Load a video preview or source frame before adjusting the crop.','bad');return;}
  const marker=document.createComment('crop controls'),dialog=document.createElement('dialog');dialog.className='large-crop-dialog';
  dialog.setAttribute('aria-labelledby','largeCropTitle');
  dialog.innerHTML=`<div class="large-crop-shell"><header class="row"><div class="grow"><h2 id="largeCropTitle">Adjust crop</h2><p class="help">Frame your facecam and gameplay. Drag a rectangle, resize its corners, or use the arrow keys.</p></div><button type="button" class="btn sm" id="largeCropClose" aria-label="Close crop editor">✕</button></header><div class="large-crop-grid"><section id="largeCropControls"></section><aside class="large-crop-output"><b>Output preview</b><canvas width="360" height="640" data-large-output="${prefix}" aria-label="Output framing preview"></canvas><p class="help">Framing preview · captions appear in the clip preview.</p>${prefix==='o'||window.momentraDraftSource?.()?'<button type="button" class="btn sm" id="largeCropPlay">Play / pause</button><input type="range" min="0" max="8" step="0.05" id="largeCropScrub" aria-label="Seek within crop preview">':'<p class="help">Original source still frame</p>'}</aside></div><footer class="row"><button type="button" class="btn sm" id="largeCropUndo" disabled>Undo</button><button type="button" class="btn sm" id="largeCropReset">Reset crop</button><span class="grow"></span><button type="button" class="btn" id="largeCropCancel">Cancel</button><button type="button" class="btn primary" id="largeCropApply">Apply crop</button></footer></div>`;
  controls.before(marker);document.body.append(dialog);
  largeCrop={prefix,controls,marker,dialog,trigger,before:cropSnapshot(prefix),beforeLayout:frameLayout(prefix),history:[]};
  dialog.querySelector('#largeCropControls').append(controls);
  dialog.addEventListener('cancel',e=>{e.preventDefault();cropFinish(false);});
  dialog.addEventListener('close',()=>{if(largeCrop?.dialog===dialog)cropFinish(false);});
  dialog.querySelector('#largeCropApply').onclick=()=>cropFinish(true);
  for(const id of ['largeCropCancel','largeCropClose'])dialog.querySelector('#'+id).onclick=()=>cropFinish(false);
  dialog.querySelector('#largeCropReset').onclick=()=>{cropRemember();cropRestore(SPLIT_DEFAULTS);};
  dialog.querySelector('#largeCropUndo').onclick=()=>{const previous=largeCrop.history.pop();if(previous)cropRestore(previous);dialog.querySelector('#largeCropUndo').disabled=!largeCrop.history.length;};
  dialog.addEventListener('focusin',e=>{if(e.target.matches('input[type=number]'))cropRemember();});
  dialog.addEventListener('pointerdown',e=>{if(e.target.closest('.crop-box,[data-crop-preset]'))cropRemember();},true);
  dialog.addEventListener('keydown',e=>{if(e.target.closest('.crop-box')&&e.key.startsWith('Arrow'))cropRemember();},true);
  if(prefix==='o'||window.momentraDraftSource?.()){
    const v=prefix==='edit'?window.momentraDraftSource():framingState.video;
    dialog.querySelector('#largeCropPlay').onclick=()=>{if(prefix==='edit')window.momentraDraftMode?.('draft');if(v.paused)v.play().catch(()=>{});else v.pause();};
    const scrub=dialog.querySelector('#largeCropScrub'),draft=prefix==='edit'?window.momentraDraftSnapshot?.():null;
    scrub.min=draft?.bounds.start||0;scrub.max=draft?.bounds.end||v.duration||8;scrub.value=draft?v.currentTime+draft.source.offset:v.currentTime||0;
    scrub.oninput=()=>{if(prefix==='edit')window.momentraDraftSeek(Number(scrub.value));else v.currentTime=Number(scrub.value);};
  }
  dialog.showModal();momentraCropOverlay();drawFraming();
}
document.addEventListener('click',e=>{const trigger=e.target.closest('[data-adjust-crop]');if(trigger)openLargeCrop(trigger.dataset.adjustCrop,trigger);});
const largeCropStyle=document.createElement('style');largeCropStyle.textContent=`
.crop-box>span.resize-handle{left:auto;right:auto;top:auto;bottom:auto;padding:0;background:#fff}.crop-box>span.handle-nw{left:-6px;top:-6px}.crop-box>span.handle-ne{right:-6px;top:-6px}.crop-box>span.handle-sw{left:-6px;bottom:-6px}.crop-box>span.handle-se{right:-6px;bottom:-6px}

.source-crop>.adjust-crop{position:absolute;right:8px;top:8px;z-index:8;font-size:11px;height:30px;background:var(--surface);border:1px solid var(--line)}.large-crop-dialog{width:min(1450px,96vw);max-width:96vw;max-height:94vh;padding:0;border:1px solid var(--line);border-radius:16px;background:var(--surface);color:var(--text)}.large-crop-shell{padding:22px;display:flex;flex-direction:column;gap:18px}.large-crop-shell header{align-items:start}.large-crop-shell header h2{font-size:22px}.large-crop-shell .help{margin:6px 0;font-size:12px}.large-crop-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(170px,260px);gap:22px;align-items:start}.large-crop-grid .split-controls{border:0;padding:0;display:block!important}.large-crop-grid .source-crop{margin-top:8px}.large-crop-grid .adjust-crop{display:none}.large-crop-grid .resize-handle{width:18px;height:18px}.large-crop-output{display:grid;gap:10px;position:sticky;top:0}.large-crop-output canvas{display:block;width:100%;max-height:60vh;object-fit:contain;background:#111;border-radius:10px}.large-crop-output>input{width:100%}.large-crop-shell footer{border-top:1px solid var(--line);padding-top:14px;position:sticky;bottom:0;background:var(--surface)}@media(max-width:760px){.large-crop-grid{grid-template-columns:1fr}.large-crop-output{max-width:230px;margin:auto}.large-crop-shell{padding:14px}.large-crop-dialog{max-height:96vh}.large-crop-shell footer{flex-wrap:wrap}}
`;document.head.append(largeCropStyle);
/* A creator's saved split framing can be reused without waiting for the facecam to appear. */
function creatorCropPresets(){
  const selected=targetCreator();
  return `<div class="creator-crop-presets"><label class="f">Creator crop preset<select id="cropPresetCreator"><option value="">Choose a creator</option>${S.creators.map(c=>`<option value="${esc(c.id)}" ${c.id===selected?'selected':''}>${esc(c.name)}${c.layout?.startsWith('facecam_')?' · saved crop':''}</option>`).join('')}</select></label><div class="row"><button type="button" class="btn sm" id="loadCreatorCrop">Load saved crop</button><button type="button" class="btn sm" id="saveCreatorCrop">Save crop for creator</button></div><p class="help" id="creatorCropStatus" role="status">Reuse a creator's framing even when this video starts with an intro. Saving replaces that creator's default crop.</p></div>`;
}
function applyCreatorCrop(c){
  if(!c?.layout?.startsWith('facecam_')){toast('No facecam crop is saved for this creator yet. Frame a video, then save the crop.','bad');return;}
  for(const[key,value]of Object.entries(SPLIT_DEFAULTS)){const field=document.getElementById('o_'+key);if(field)field.value=c[key]??value;}
  const layout=document.querySelector('[data-seg=o_layout][data-v="'+c.layout+'"]');if(layout)layout.click();
  storeFraming();momentraCropOverlay();drawFraming();
  const status=document.getElementById('creatorCropStatus');if(status)status.textContent=c.name+' crop loaded. The preview may still show the intro; the saved crop will apply to the video.';
}
document.addEventListener('change',e=>{
  if(e.target.id!=='o_creator')return;
  const c=S.creators.find(c=>c.id===e.target.value),select=document.getElementById('cropPresetCreator');if(select)select.value=c?.id||'';
  if(c?.layout?.startsWith('facecam_'))applyCreatorCrop(c);
});
document.addEventListener('click',async e=>{
  const load=e.target.closest('#loadCreatorCrop'),save=e.target.closest('#saveCreatorCrop');if(!load&&!save)return;
  const c=S.creators.find(c=>c.id===document.getElementById('cropPresetCreator')?.value);
  if(!c){toast('Choose the creator whose crop you want to load or save.','bad');return;}
  if(load)return applyCreatorCrop(c);
  save.disabled=true;
  try{
    const body={...readSplit('o'),layout:document.getElementById('o_layout').value};
    if(!body.layout.startsWith('facecam_'))throw new Error('Choose Facecam top or Facecam bottom before saving a crop.');
    const saved=await send('/api/creators/'+encodeURIComponent(c.id),body,'PUT');Object.assign(c,saved);
    storeFraming();await tick();
    const status=document.getElementById('creatorCropStatus');if(status)status.textContent='Saved for '+c.name+'. Select this creator or load their preset on your next video.';
    const option=document.querySelector('#cropPresetCreator option[value="'+c.id+'"]');if(option)option.textContent=c.name+' · saved crop';
    toast('Crop preset saved for '+c.name,'ok');
  }catch(error){toast(error.message,'bad');}finally{save.disabled=false;}
});
const presetStyles=document.createElement('style');presetStyles.textContent='.creator-crop-presets{padding:12px;margin:10px 0 16px;border:1px solid var(--line);border-radius:10px;background:var(--bg)}.creator-crop-presets .f{margin-bottom:10px}.creator-crop-presets .help{margin:10px 0 0}.preview-jump{margin-top:8px;font-size:11px}';document.head.append(presetStyles);
