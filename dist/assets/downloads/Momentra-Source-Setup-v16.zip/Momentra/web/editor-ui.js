/* Source-clock caption corrections and trim tools. No transcript is sent to an AI service. */
(() => {
  'use strict';
  let state = null, generation = 0, controller = null;
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const escape = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const time = n => Number(n).toFixed(2);
  const identity = (j,c) => ({jid:typeof j === 'string' ? j : j.id, cid:typeof c === 'string' ? c : c.id, clip:typeof c === 'string' ? null:c});
  const endpoint = s => `/api/jobs/${encodeURIComponent(s.jid)}/clips/${encodeURIComponent(s.cid)}/editor`;
  let previewSnapshot = null, snapshotVersion = 0;
  function snapshot() {
    if (!state?.data) return null;
    if (!previewSnapshot) previewSnapshot = Object.freeze({
      jid:state.jid, cid:state.cid, revision:++snapshotVersion,
      editor_revision:state.data.editor_revision, editor_rendered_revision:state.data.editor_rendered_revision,
      cut:Object.freeze({start:Number(state.start),end:Number(state.end)}),
      rendered_cut:Object.freeze({...state.data.rendered_cut}), bounds:Object.freeze({...state.data.bounds}),
      window:Object.freeze({...state.data.window}), source:Object.freeze({...state.data.source}),
      words:Object.freeze(state.data.words.map(w=>Object.freeze({...w,...state.edits.get(w.id)}))),
      reset:state.reset, loading:state.loading, error:state.error
    });
    return previewSnapshot;
  }
  const notify = () => { previewSnapshot=null; window.momentraDraftChanged?.(); window.momentraClipDraftChanged?.(); document.dispatchEvent(new Event('momentra:editor-dirty')); };
  const dirty = () => !!state && (state.reset || state.edits.size > 0 || (state.data && (Number(state.start) !== state.data.cut.start || Number(state.end) !== state.data.cut.end)));
  async function request(url, signal) {
    const response = await fetch(url, {credentials:'same-origin', signal});
    let data; try { data = await response.json(); } catch { throw new Error('The editor could not be loaded. Try reopening this clip.'); }
    if (!response.ok) throw new Error(data.detail || 'The editor could not be loaded.');
    return data;
  }
  function style() {
    if ($('#momentraEditorStyles')) return;
    const element = document.createElement('style'); element.id = 'momentraEditorStyles';
    element.textContent = `.word-editor,.trim-editor{display:grid;gap:10px;min-width:0}.editor-word-list{max-height:310px;overflow:auto;border:1px solid var(--line);border-radius:6px}.editor-word-row{display:grid;grid-template-columns:24px 40px minmax(80px,1fr) 72px 72px;gap:5px;align-items:center;padding:6px;border-bottom:1px solid var(--line);font-size:11px}.editor-word-row:last-child{border-bottom:0}.editor-word-row.current{background:var(--muted)}.editor-word-row.selected{border-left:3px solid var(--brand)}.editor-word-row.outside{opacity:.65}.editor-word-row input{width:100%;min-width:0;padding:5px;font-size:11px}.editor-word-row button{padding:5px;min-width:0}.editor-word-row .word-select{width:15px}.editor-word-text{display:block;margin-bottom:3px;user-select:text;overflow-wrap:anywhere}.editor-word-head{font-size:10px;color:var(--dim);padding:5px;text-align:right}.editor-tool-row{display:flex;gap:6px;flex-wrap:wrap;align-items:center}.editor-tool-row .btn{font-size:11px;padding:6px 8px;min-height:30px}.editor-source-video{display:block;width:100%;max-height:200px;background:#111;border-radius:6px}.editor-source-note,.editor-notice{font-size:11px;color:var(--dim);margin:0;line-height:1.5}.editor-notice.error{color:var(--bad,#c66)}.editor-waveform{width:100%;height:64px;display:block;border:1px solid var(--line);border-radius:5px}.editor-dual-range{display:grid;gap:4px}.editor-dual-range label{display:grid;grid-template-columns:42px 1fr;align-items:center;font-size:11px;color:var(--dim)}.editor-dual-range input{width:100%;accent-color:var(--brand)}.editor-time-row{display:flex;gap:5px;align-items:center;flex-wrap:wrap}.editor-time-row span{font-size:11px}.editor-time-row .btn{padding:4px 6px;font-size:11px}.editor-selection-note{font-size:11px;color:var(--dim)}@media(max-width:500px){.editor-word-row{grid-template-columns:20px 34px minmax(70px,1fr) 59px 59px;gap:3px}.editor-word-row input{padding:4px 2px}}`;
    document.head.appendChild(element);
  }
  function notice(message, error=false) {
    for (const root of [$('#captionWordEditor'), $('#clipTimingEditor')]) {
      if (!root) continue;
      let element = $('.editor-notice', root);
      if (!element) { element = document.createElement('p'); root.prepend(element); }
      element.className = `editor-notice${error?' error':''}`; element.textContent = message;
      if(!error&&/^Loading/.test(message)&&window.momentraLoading)element.innerHTML=window.momentraLoading(message);
    }
  }
  function setCut(side, value, seek=false) {
    if (!state?.data) return;
    state[side] = String(value);
    const field = $(`#clipTimingEditor [data-editor-time="${side}"], #clipTimingEditor [data-f="${side}"]`); if (field) field.value = String(value);
    const range = $(`[data-editor-range="${side}"]`); if (range) range.value = String(value);
    updateCut(); if (seek) seekSource(Number(value)); notify();
  }
  function validate() {
    if (!state?.data || state.loading) throw new Error('Wait for the captions and original video times to load before saving.');
    if (state.error) throw new Error(state.error);
    if (state.start === '' || state.end === '') throw new Error('Enter both cut times.');
    const start = Number(state.start), end = Number(state.end), bounds = state.data.bounds;
    if (![start,end].every(Number.isFinite) || start < bounds.start || end > bounds.end || end <= start || end-start < 3 || end-start > 180) throw new Error('Choose an ordered cut of 3–180 seconds inside the available video.');
    const words = state.data.words.map(w => ({...w,...state.edits.get(w.id)}));
    for (let i=0;i<words.length;i++) {
      const w=words[i], edit=state.edits.get(w.id);
      if (!edit) continue;
      if (typeof w.text !== 'string' || w.text.length > 200 || /[\x00-\x1f]/.test(w.text)) throw new Error('A caption word can have up to 200 characters without line breaks.');
      if (edit.start === '' || edit.end === '' || ![Number(w.start),Number(w.end)].every(Number.isFinite) || Number(w.start)<bounds.start || Number(w.end)>bounds.end || Number(w.end)<=Number(w.start)) throw new Error('Each word needs finite ordered times inside the available video.');
      if (('start' in edit || 'end' in edit) && ((i>0 && Number(w.start)<Number(words[i-1].end)-.001) || (i+1<words.length && Number(w.end)>Number(words[i+1].start)+.001))) throw new Error('Word times must stay ordered without overlapping neighbouring words.');
    }
    return {start,end};
  }
  function updateCut() {
    if (!state?.data) return;
    const duration = $('[data-editor-duration]');
    if (duration) duration.textContent = `${time(Number(state.end)-Number(state.start))} seconds · source clock`;
    for (const row of $$('[data-word-id]')) { const w = effective(row.dataset.wordId); row.classList.toggle('outside', Number(w.start)<Number(state.start) || Number(w.start)>=Number(state.end)); }
    try { validate(); notice('Edits stay local until Save and re-make. Corrections are kept when styles or cut times change.'); }
    catch (error) { notice(error.message,true); }
    drawWaveform();
  }
  function effective(id) { const word = state?.data?.words.find(w=>w.id===id); return {...word,...state?.edits.get(id)}; }
  const sourcePlayer=()=>window.momentraDraftSource?.() || $('[data-editor-source]');
  function seekSource(value) {
    const video = sourcePlayer(); if (!video || !state?.data?.source.available || !Number.isFinite(value)) return;
    if (window.momentraDraftSource?.()) {window.momentraDraftSeek(value);highlight();return;}
    const offset = state.data.source.offset, bounds = state.data.bounds;
    video.currentTime = Math.max(0, Math.min(bounds.end-.01,Math.max(bounds.start,value))-offset);
    highlight();
  }
  function highlight() {
    if (!state?.data) return;
    const video = sourcePlayer(); if (!video) return;
    const stamp = window.momentraDraftSnapshot?.() ? (state.playhead ?? state.start) : video.currentTime+state.data.source.offset;
    for (const row of $$('[data-word-id]')) { const w = effective(row.dataset.wordId); row.classList.toggle('current', Number(w.start)<=stamp && stamp<Number(w.end)); }
    const label = $('[data-editor-playhead]'); if (label) label.textContent = `${time(stamp)}s source`;
  }
  function selection() {
    let ids = [...(state?.selected || [])];
    const selected = window.getSelection?.();
    if (selected && !selected.isCollapsed && selected.rangeCount) {
      const range = selected.getRangeAt(0), rows = $$('[data-word-id]');
      const found = rows.filter(row => { try { return range.intersectsNode($('.editor-word-text', row)); } catch { return false; } }).map(row=>row.dataset.wordId);
      if (found.length) ids=found;
    }
    return ids.map(effective).filter(w=>w.id).sort((a,b)=>Number(a.start)-Number(b.start));
  }
  function cutSelection(mode) {
    const words=selection(); if (!words.length) return notice('Select words or tick their boxes, then choose a cut button.',true);
    if (mode==='start' || mode==='both') setCut('start',words[0].start);
    if (mode==='end' || mode==='both') setCut('end',words[words.length-1].end);
    seekSource(Number(state.start));
  }
  function wordsUI() {
    const root=$('#captionWordEditor'); if (!root || !state?.data) return;
    root.classList.add('word-editor');
    root.innerHTML=`<p class="editor-notice"></p><div class="editor-tool-row"><button class="btn" type="button" data-editor-cut="start">Start at selection</button><button class="btn" type="button" data-editor-cut="end">End at selection</button><button class="btn" type="button" data-editor-cut="both">Keep selected words</button><button class="btn ghost" type="button" data-editor-reset>Reset captions</button></div><p class="editor-selection-note">Select the caption text or tick words. Cut buttons are explicit; typing does not change the cut. Blank text hides a word.</p><div class="editor-word-head">Caption text · word start · word end (source seconds)</div><div class="editor-word-list">${state.data.words.map(word=>{
      const w=effective(word.id); return `<div class="editor-word-row" data-word-id="${escape(w.id)}"><input class="word-select" type="checkbox" aria-label="Select ${escape(w.text)}" ${state.selected.has(w.id)?'checked':''}><button type="button" class="btn ghost" data-editor-seek="${escape(w.id)}" aria-label="Seek to ${escape(w.text)}">${time(w.start)}</button><label><span class="editor-word-text">${escape(w.text)||'(hidden)'}</span><input type="text" maxlength="200" data-word-field="text" aria-label="Caption text at ${time(w.start)} seconds" value="${escape(w.text)}"></label><input type="number" step="0.01" data-word-field="start" aria-label="Word start at ${time(w.start)} seconds" value="${escape(w.start)}"><input type="number" step="0.01" data-word-field="end" aria-label="Word end at ${time(w.start)} seconds" value="${escape(w.end)}"></div>`;
    }).join('') || '<p class="editor-source-note" style="padding:12px">No timed speech was found in this window. You can still trim the source video.</p>'}</div>${state.data.words_truncated?'<p class="editor-source-note">Showing the first 3000 words in this window. Narrow the preview to see the rest.</p>':''}`;
    root.oninput = wordInput;
    root.onchange = event=>{ const box=event.target.closest('.word-select'); if (!box) return; const row=box.closest('[data-word-id]'); if (box.checked) state.selected.add(row.dataset.wordId); else state.selected.delete(row.dataset.wordId); row.classList.toggle('selected',box.checked); };
    root.onclick = wordClick;
  }
  function wordInput(event) {
    const input=event.target.closest('[data-word-field]'); if (!input || !state?.data) return;
    if (state.reset) return notice('Save the caption reset first, or reopen the clip to keep your current corrections.',true);
    const id=input.closest('[data-word-id]').dataset.wordId, key=input.dataset.wordField, original=state.data.words.find(w=>w.id===id), patch={...state.edits.get(id)};
    const value=key==='text'?input.value:(input.value===''?'':Number(input.value));
    if (value===original[key]) delete patch[key]; else patch[key]=value;
    if (Object.keys(patch).length) state.edits.set(id,patch); else state.edits.delete(id);
    const text=$('.editor-word-text',input.closest('[data-word-id]')); if (key==='text') text.textContent=value || '(hidden)';
    updateCut(); notify();
  }
  function wordClick(event) {
    const button=event.target.closest('button'); if (!button || !state?.data) return;
    if (button.dataset.editorSeek) return seekSource(Number(effective(button.dataset.editorSeek).start));
    if (button.dataset.editorCut) return cutSelection(button.dataset.editorCut);
    if (button.hasAttribute('data-editor-reset')) {
      if (!window.confirm('Reset all manual caption corrections to the saved automatic captions? This is saved only after Save and re-make.')) return;
      state.edits.clear(); state.reset=true;
      state.data.words=state.data.words.map(w=>({...w,text:w.original_text,start:w.original_start,end:w.original_end}));
      wordsUI(); $$('[data-word-field]',$('#captionWordEditor')).forEach(input=>input.disabled=true); updateCut(); notify();
    }
  }
  function timingUI() {
    const root=$('#clipTimingEditor'); if (!root || !state?.data) return;
    // Retain fallback data-f inputs: the host's draft tracker and remake form still see the same elements.
    const fallback=$('[data-f="start"]',root)?.closest('.two');
    root.classList.add('trim-editor');
    for (const old of $$('[data-editor-owned]',root)) old.remove();
    const wrapper=document.createElement('div'); wrapper.dataset.editorOwned='true'; wrapper.className='trim-editor';
    const source=state.data.source;
    wrapper.innerHTML=`<p class="editor-notice"></p><p class="editor-source-note">Available original: ${time(state.data.bounds.start)}–${time(state.data.bounds.end)}s. The source player can play beyond the exported cut.</p>${source.available?(window.momentraDraftSource?.()?'<p class="editor-source-note">Timing shares the Draft player and its source clock; no second audio player.</p><p class="editor-source-note" data-editor-playhead></p>':`<video class="editor-source-video" data-editor-source controls playsinline preload="metadata" src="${escape(source.url)}"></video><p class="editor-source-note" data-editor-playhead></p>`):'<p class="editor-source-note">The original source is missing. No waveform or source playback is available.</p>'}<canvas class="editor-waveform" width="600" height="64" data-editor-waveform aria-label="Audio waveform and selected cut"></canvas><p class="editor-source-note" data-editor-wave-note>Loading bounded audio preview…</p><div class="editor-dual-range"><label>Start<input type="range" min="${state.data.window.start}" max="${state.data.window.end}" step="0.01" data-editor-range="start" aria-label="Cut start"></label><label>End<input type="range" min="${state.data.window.start}" max="${state.data.window.end}" step="0.01" data-editor-range="end" aria-label="Cut end"></label></div><p class="editor-source-note" data-editor-duration></p><div class="editor-time-row"><span>Start</span>${[-.5,-.1,.1,.5].map(v=>`<button class="btn" type="button" data-editor-nudge="start" data-editor-step="${v}">${v>0?'+':''}${v}s</button>`).join('')}<button type="button" class="btn" data-editor-snap="start">Snap to word</button></div><div class="editor-time-row"><span>End</span>${[-.5,-.1,.1,.5].map(v=>`<button class="btn" type="button" data-editor-nudge="end" data-editor-step="${v}">${v>0?'+':''}${v}s</button>`).join('')}<button type="button" class="btn" data-editor-snap="end">Snap to word</button></div><div class="editor-tool-row"><button type="button" class="btn" data-editor-listen>Play from cut start</button><button type="button" class="btn" data-editor-window>Load words around these times</button></div>`;
    root.appendChild(wrapper);
    if (!fallback && !$('[data-editor-time="start"], [data-f="start"]',root)) {
      const fields=document.createElement('div'); fields.className='two'; fields.innerHTML='<label class="f">Start (seconds)<input data-editor-time="start" type="number" step="0.01"></label><label class="f">End (seconds)<input data-editor-time="end" type="number" step="0.01"></label>'; root.prepend(fields);
    }
    for (const side of ['start','end']) {
      const input=$(`[data-editor-time="${side}"], [data-f="${side}"]`,root); if (!input) continue;
      input.step='.01'; input.min=state.data.bounds.start; input.max=state.data.bounds.end; input.value=state[side];
      input.oninput=()=>setCut(side,input.value);
      const range=$(`[data-editor-range="${side}"]`,root); range.value=state[side]; range.oninput=()=>setCut(side,range.value,true);
    }
    wrapper.addEventListener('click', async event=>{
      const b=event.target.closest('button'); if (!b) return;
      if (b.dataset.editorNudge) { const side=b.dataset.editorNudge; return setCut(side,time(Number(state[side])+Number(b.dataset.editorStep)),true); }
      if (b.dataset.editorSnap) { const side=b.dataset.editorSnap, values=state.data.words.map(w=>Number(effective(w.id)[side])); if (!values.length) return notice('No timed words to snap to in this window.',true); return setCut(side,values.reduce((a,n)=>Math.abs(n-Number(state[side]))<Math.abs(a-Number(state[side]))?n:a),true); }
      if (b.hasAttribute('data-editor-listen')) { window.momentraDraftMode?.('draft'); seekSource(Number(state.start)); const video=sourcePlayer(); if (video) video.play().catch(()=>{}); }
      if (b.hasAttribute('data-editor-window')) {
        try { validate(); const bounds=state.data.bounds, a=Math.max(bounds.start,Number(state.start)-15), end=Math.min(bounds.end,Number(state.end)+15); await load(state,a,end,true); } catch(error) { notice(error.message,true); }
      }
    });
    const video=$('[data-editor-source]',root);
    if (video) { video.addEventListener('loadedmetadata',()=>seekSource(Number(state.start)),{once:true}); video.addEventListener('timeupdate',highlight); video.addEventListener('error',()=>notice('Your browser cannot play this original format. Use precise times and the waveform; exported MP4 playback is unchanged.',true)); }
    const canvas=$('[data-editor-waveform]',root); canvas.addEventListener('click',event=>{const rect=canvas.getBoundingClientRect(); seekSource(state.data.window.start+(event.clientX-rect.left)/rect.width*(state.data.window.end-state.data.window.start));});
  }
  function drawWaveform() {
    const canvas=$('[data-editor-waveform]'); if (!canvas || !state?.data) return;
    const ctx=canvas.getContext('2d'); if (!ctx) return;
    const {width,height}=canvas, a=state.data.window.start, span=state.data.window.end-a;
    const palette=getComputedStyle(document.documentElement), colour=palette.getPropertyValue('--brand').trim()||'#d9a45e';
    ctx.clearRect(0,0,width,height); ctx.fillStyle=colour; ctx.globalAlpha=.12;
    ctx.fillRect(Math.max(0,(Number(state.start)-a)/span*width),0,Math.max(0,(Number(state.end)-Math.max(a,Number(state.start)))/span*width),height); ctx.globalAlpha=1;
    ctx.fillStyle=colour; const peaks=state.wave?.peaks || [];
    peaks.forEach((p,i)=>{ const h=Math.max(1,p*(height-4)); ctx.fillRect(i/peaks.length*width,(height-h)/2,Math.max(1,width/peaks.length-1),h); });
    if (!peaks.length) { ctx.strokeStyle=palette.getPropertyValue('--line').trim()||'#888'; ctx.beginPath(); ctx.moveTo(0,height/2);ctx.lineTo(width,height/2);ctx.stroke(); }
  }
  async function load(target,start,end,preserve=false) {
    const token=++generation; controller?.abort(); controller=new AbortController();
    target.loading=true; target.error=null; notice('Loading saved captions and original video times…');
    try {
      const query=start==null?'':`?start=${start}&end=${end}`;
      const data=await request(endpoint(target)+query,controller.signal); if (token!==generation || state!==target) return;
      if (preserve && target.data && data.editor_revision!==target.data.editor_revision) throw new Error('This clip changed elsewhere. Reopen it before saving.');
      if (preserve) {
        const known=new Set(data.words.map(w=>w.id));
        data.words=[...target.data.words.filter(w=>target.edits.has(w.id)&&!known.has(w.id)),...data.words].sort((a,b)=>a.start-b.start);
        if (target.reset) data.words=data.words.map(w=>({...w,text:w.original_text,start:w.original_start,end:w.original_end}));
      }
      target.data=data; target.loading=false;
      if (!preserve) {target.start=String(data.cut.start);target.end=String(data.cut.end);target.edits.clear();target.reset=false;}
      wordsUI(); if(target.reset) $$('[data-word-field]',$('#captionWordEditor')).forEach(input=>input.disabled=true); timingUI(); updateCut(); notify();
      const wave=await request(endpoint(target)+`/waveform?start=${data.window.start}&end=${data.window.end}`,controller.signal); if (token!==generation || state!==target) return;
      target.wave=wave; const note=$('[data-editor-wave-note]'); if (note) note.textContent=wave.available?'Audio level only. Click to seek; word snapping is explicit.':wave.reason||'No audio waveform is available. Use precise times.'; drawWaveform();
    } catch(error) {
      if (error.name==='AbortError' || token!==generation) return;
      target.loading=false;
      if (target.data) { const note=$('[data-editor-wave-note]'); if (note) note.textContent=error.message; }
      else {target.error=error.message;notice(error.message,true);} notify();
    }
  }
  window.momentraEditorOpen=(j,c)=>{
    style(); const ids=identity(j,c); controller?.abort(); previewSnapshot=null; state={...ids,data:null,edits:new Map(),selected:new Set(),reset:false,start:'',end:'',wave:null,error:null,loading:true};
    return load(state);
  };
  window.momentraEditorRefresh=(j,c)=>{
    if (!state) return;
    const ids=identity(j,c); if (ids.jid!==state.jid || ids.cid!==state.cid) return window.momentraEditorOpen(j,c);
    if (!state.data || state.loading) return;
    const revision=ids.clip?.editor_revision ?? state.data.editor_revision, rendered=ids.clip?.editor_rendered_revision ?? state.data.editor_rendered_revision;
    if (revision!==state.data.editor_revision || rendered!==state.data.editor_rendered_revision) {
      if (revision!==state.data.editor_revision && dirty()) {state.error='This clip changed elsewhere. Reopen it before saving your draft.';notice(state.error,true);return;}
      if (state.accepting && revision!==state.data.editor_revision) {state.data.editor_revision=revision;state.accepting=false;}
      state.data.editor_rendered_revision=rendered;
      if(ids.clip?.rendered_cut)state.data.rendered_cut={...ids.clip.rendered_cut};
      if(revision===state.data.editor_revision){notify();return;}
      return load(state);
    }
  };
  window.momentraEditorChanges=()=>{
    if (!state) return {};
    const values=validate();
    const result={editor_revision:state.data.editor_revision,...values};
    if (state.reset) result.captions_reset=true;
    else if (state.edits.size) result.caption_edits=[...state.edits].map(([id,edit])=>({id,...Object.fromEntries(Object.entries(edit).map(([key,value])=>[key,key==='text'?value:Number(value)]))}));
    return result;
  };
  window.momentraEditorCanClose=()=>!dirty();
  window.momentraEditorSnapshot=snapshot;
  window.momentraEditorPlayhead=stamp=>{if(state){state.playhead=stamp;highlight();}};
  window.momentraEditorSaved=accepted=>{
    if (!state) return;
    const saved=accepted?.clips?.find(c=>c.id===state.cid);
    if(saved&&state.data){state.data.editor_revision=saved.editor_revision??state.data.editor_revision;state.data.editor_rendered_revision=saved.editor_rendered_revision??state.data.editor_rendered_revision;}
    // Promote effective corrections before clearing patches. Polling must never flash automatic words.
    if(state.data){state.data.words=state.data.words.map(w=>({...w,...state.edits.get(w.id)}));state.data.cut={start:Number(state.start),end:Number(state.end)};}
    state.accepting=true;state.edits.clear();state.reset=false;notify();
  };
  document.addEventListener('click',event=>{
    const tab=event.target.closest('[data-editor-tab]');
    if (tab && tab.dataset.editorTab!=='timing' && !window.momentraDraftSource?.()) sourcePlayer()?.pause();
  });
  const close = ()=>{sourcePlayer()?.pause();controller?.abort();generation++;state=null;previewSnapshot=null;};
  window.momentraEditorClose=close;
  const observe=document.getElementById('clipdlg'); if (observe) observe.addEventListener('close',close);
})();
