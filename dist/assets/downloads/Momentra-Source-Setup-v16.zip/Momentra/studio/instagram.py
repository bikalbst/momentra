"""Meta Unified Login and Instagram publishing settings. Tokens stay on this machine."""
import base64
import hashlib
import hmac
import json
import re
import threading
import time
from urllib.parse import urlencode

import httpx

from . import accounts, ctx

GRAPH = "https://graph.facebook.com/v27.0"
_lock = threading.RLock()
_pending = {}


def credentials():
    return dict(accounts._apps_saved().get("instagram_unified") or {})


def configured():
    saved = credentials()
    return bool(saved.get("id") and saved.get("secret") and saved.get("config_id"))


def save_setup(body):
    old = credentials()
    app_id = str(body.get("client_id") or old.get("id") or "").strip()
    config_id = str(body.get("config_id") or old.get("config_id") or "").strip()
    secret = str(body.get("client_secret") or (old.get("secret") if old.get("id") == app_id else "") or "").strip()
    if not re.fullmatch(r"\d{5,40}", app_id) or not re.fullmatch(r"\d{5,40}", config_id):
        raise ValueError("Paste your Meta App ID and Configuration ID from the Unified login setup.")
    if not secret or len(secret) > 500:
        raise ValueError("Paste your Meta App Secret. A blank field keeps the saved secret for the same app.")
    with accounts._lock:
        data = dict(accounts._apps_saved())
        data["instagram_unified"] = {"id": app_id, "secret": secret, "config_id": config_id}
        path = accounts._apps_file()
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(data, indent=1), encoding="utf-8")
        try:
            temp.chmod(0o600)
        except OSError:
            pass
        temp.replace(path)
        accounts._apps_seen["at"] = None
    ctx.bump()
    return public_setup()


def public_setup():
    from . import instagram_gateway
    saved = credentials()
    return {"configured": configured(), "app_id": saved.get("id", ""), "config_id": saved.get("config_id", ""),
            "has_secret": bool(saved.get("secret")), "link": instagram_gateway.status()}


def _prune():
    for key, value in list(_pending.items()):
        if time.time() - value["created"] > 900:
            _pending.pop(key, None)


def cancel(state):
    with _lock:
        _pending.pop(state, None)


def connect_url():
    from . import instagram_gateway
    saved = credentials()
    if not configured():
        raise ValueError("Save your Meta App ID, App Secret and Configuration ID first.")
    base = instagram_gateway.public_base()
    state = accounts._new_state("instagram")
    with _lock:
        _prune()
        _pending[state] = {"user": ctx.uid(), "created": time.time(), "credentials": saved,
                           "redirect": base + "/oauth/instagram/callback"}
    return "https://www.facebook.com/dialog/oauth?" + urlencode({
        "client_id": saved["id"], "config_id": saved["config_id"], "redirect_uri": base + "/oauth/instagram/callback",
        "response_type": "code", "display": "popup", "prompt": "login", "state": state})


def state_owner(state):
    with _lock:
        _prune()
        pending = _pending.get(state)
        return pending.get("user") if pending else None


def graph(path, token=None, method="GET", params=None, data=None):
    """Only fixed Graph paths, bearer headers, bounded responses and credential-free errors."""
    try:
        response = httpx.request(method, GRAPH + path, params=params, data=data,
                                 headers={"Authorization": "Bearer " + token} if token else {}, timeout=45)
        if len(response.content) > 2097152:
            raise ValueError("Response too large")
        payload = response.json()
        if not isinstance(payload, dict):
            raise ValueError("Invalid response")
    except (httpx.HTTPError, ValueError):
        raise RuntimeError("Meta could not be reached. Check your internet connection and try again.") from None
    error = payload.get("error") or {}
    if response.status_code >= 400 or error:
        code = error.get("code")
        if code in (102, 190) or error.get("error_subcode") in (458, 459, 460, 463, 464, 467):
            raise accounts.ReconnectRequired("Instagram access expired or was revoked. Connect Instagram again before retrying.")
        if code in (10, 200):
            raise accounts.ReconnectRequired("Meta denied the required Instagram permission. Check your configuration and account access, then connect again.")
        raise RuntimeError(f"Meta rejected this request (code {code or response.status_code}). Check account eligibility and your Meta app configuration.")
    return payload


def finish(code, state):
    """Called only after the one-time state identifies its owner; never connect an arbitrary first account."""
    with _lock:
        _prune()
        pending = _pending.get(state)
        if not pending or pending["user"] != ctx.uid():
            raise ValueError("This Instagram sign-in expired. Press Connect again.")
        saved = pending["credentials"]
        if saved != credentials():
            raise ValueError("Instagram setup changed during sign-in. Press Connect again.")
    accounts._take_state(state, "instagram")
    if not code or len(code) > 16384:
        raise ValueError("Meta did not return a valid sign-in code.")
    token = graph("/oauth/access_token", params={"client_id": saved["id"], "client_secret": saved["secret"],
                  "redirect_uri": pending["redirect"], "code": code}).get("access_token")
    if not isinstance(token, str) or not token:
        raise ValueError("Meta did not return an access token. Check your configuration's system-user token setting.")
    me = graph("/me", token, params={"fields": "client_business_id"})
    if not str(me.get("client_business_id") or "").isdigit():
        raise ValueError("Meta did not return a client business portfolio. Use an Instagram Login Compatible Unified login configuration.")
    rows, after = [], None
    for _ in range(5):
        page = graph("/me/assigned_instagram_accounts", token,
                     params={"fields": "id,username", "limit": 100, **({"after": after} if after else {})})
        for item in page.get("data", []):
            ident, username = str(item.get("id") or ""), str(item.get("username") or "")
            if ident.isdigit() and username:
                rows.append({"id": ident, "name": "@" + username[:100]})
        paging = page.get("paging") or {}
        after = paging.get("cursors", {}).get("after") if paging.get("next") else None
        if not after:
            break
    rows = list({r["id"]: r for r in rows}.values())
    if not rows:
        raise ValueError("Meta shared no Instagram accounts. Use a Creator or Business account in the selected portfolio and share it during login.")
    with _lock:
        if state not in _pending:
            raise ValueError("This sign-in was cancelled. Press Connect again.")
        pending.update(token=token, accounts=rows, business_id=str(me["client_business_id"]), meta_user_id=str(me.get("id") or ""))
        if not accounts.finish_connection(state, "instagram", status="select_account", accounts=rows,
                                           message="Choose the Instagram account Momentra should post to."):
            _pending.pop(state, None)
            raise ValueError("This sign-in was cancelled. Press Connect again.")


def select_account(state, ident):
    with _lock:
        _prune()
        pending = _pending.get(state)
        if not pending or pending["user"] != ctx.uid() or not pending.get("token"):
            raise ValueError("This Instagram sign-in expired. Press Connect again.")
        if pending["credentials"] != credentials():
            raise ValueError("Instagram setup changed. Press Connect again.")
        accounts.connection_status(state)
        choice = next((a for a in pending["accounts"] if a["id"] == ident), None)
        if not choice:
            raise ValueError("Choose an Instagram account returned by this sign-in.")
        saved = pending["credentials"]
        acc = {"id": "ig_" + ident, "platform": "instagram", "name": choice["name"], "added": time.time(),
               "user_id": ident, "token": pending["token"], "login": "unified", "meta_app_id": saved["id"],
               "config_id": saved["config_id"], "business_id": pending["business_id"], "meta_user_id": pending["meta_user_id"],
               "detail": "Connected through Meta Unified login", "needs_reconnect": False}
        accounts._put(acc)
        accounts.finish_connection(state, "instagram", status="connected", name=choice["name"], message="Instagram connected.")
        _pending.pop(state, None)
    return {"connected": True, "name": choice["name"]}


def signed_request(value):
    """Validate Meta deauthorization/deletion callbacks without reading arbitrary credentials."""
    try:
        signature, encoded = value.split(".", 1)
        decode = lambda s: base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
        secret = credentials().get("secret")
        if not secret or not hmac.compare_digest(decode(signature), hmac.new(secret.encode(), encoded.encode(), hashlib.sha256).digest()):
            return None
        payload = json.loads(decode(encoded))
        if not isinstance(payload, dict):
            return None
        if payload.get("algorithm", "").upper() != "HMAC-SHA256" or not str(payload.get("user_id") or "").isdigit():
            return None
        return payload
    except (ValueError, TypeError, UnicodeError):
        return None


def revoke_user(meta_user_id):
    """Remove only matching local Unified-login tokens after a verified Meta callback."""
    from . import auth
    count = 0
    for uid in auth.user_ids():
        with ctx.as_user(uid), accounts._lock:
            all_accounts = accounts._all()
            keep = [a for a in all_accounts if not (a.get("login") == "unified" and a.get("meta_user_id") == str(meta_user_id)
                                                   and a.get("meta_app_id") == credentials().get("id"))]
            if len(keep) != len(all_accounts):
                count += len(all_accounts) - len(keep)
                accounts._write("accounts.json", keep)
    return count


def upload(acc, path, caption, job_id):
    from . import instagram_gateway, lifecycle, posting
    if acc.get("needs_reconnect") or acc.get("meta_app_id") != credentials().get("id"):
        raise accounts.ReconnectRequired("Your Instagram setup changed or access was revoked. Connect Instagram again.")
    if not job_id or not posting.public_artifact(ctx.uid(), job_id, path.name):
        raise ValueError("Review and approve this clip before posting it to Instagram.")
    base = instagram_gateway.public_base()
    token, ident = acc["token"], acc["user_id"]
    box = graph(f"/{ident}/media", token, "POST", data={"media_type": "REELS", "caption": caption[:2200],
                "share_to_feed": "true", "video_url": accounts.clip_link(job_id, path.name, base_url=base)})
    creation_id = str(box.get("id") or "")
    if not creation_id.isdigit():
        raise RuntimeError("Meta did not return a Reel container. No publish request was sent.")
    for _ in range(90):
        lifecycle.require_accepting()
        result = graph(f"/{creation_id}", token, params={"fields": "status_code"})
        if result.get("status_code") == "FINISHED":
            break
        if result.get("status_code") in ("ERROR", "EXPIRED"):
            raise RuntimeError("Instagram could not process this export. Review the file and retry.")
        time.sleep(6)
    else:
        raise RuntimeError("Instagram took too long to process this video. Check Instagram before retrying.")
    # Persisted 'posting' state survives crashes. Never automatically retry an ambiguous publish.
    try:
        result = graph(f"/{ident}/media_publish", token, "POST", data={"creation_id": creation_id})
    except accounts.ReconnectRequired:
        raise
    except Exception:
        raise accounts.ReconnectRequired("Instagram's publish result could not be confirmed. Check your Instagram profile before reconnecting and retrying to avoid a duplicate.") from None
    media_id = str(result.get("id") or "")
    if not media_id.isdigit():
        raise accounts.ReconnectRequired("Instagram's publish result was unclear. Check your profile before retrying to avoid a duplicate.")
    link = ""
    try:
        link = graph(f"/{media_id}", token, params={"fields": "permalink"}).get("permalink", "")
    except (ValueError, RuntimeError):
        pass
    return media_id, link
