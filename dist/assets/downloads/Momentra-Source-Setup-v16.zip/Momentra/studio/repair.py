"""Explicit local-only timing repairs. Never use the ordinary caption/AI pipeline."""
import copy
import math
import re
import uuid
from pathlib import Path

from . import ctx, editor, jobs, lifecycle, preflight, render, roman


TIMING_CODES = frozenset(("duration", "timing", "starts"))


def cached_words(clip):
    """Already-effective words in the saved source clock, including an explicit empty list."""
    words = clip.get("rendered_words") if "rendered_words" in clip else clip.get("fixed_words")
    if not isinstance(words, list) or len(words) > editor.MAX_WORDS:
        raise ValueError("No usable saved caption timing is available. Save and re-make this clip instead.")
    previous = -math.inf
    for word in words:
        if not isinstance(word, dict) or not isinstance(word.get("w"), str):
            raise ValueError("The saved caption words are not valid. Save and re-make this clip instead.")
        start, end = editor.number(word.get("s"), "Word time"), editor.number(word.get("e"), "Word time")
        if start < 0 or start < previous or end <= start:
            raise ValueError("The saved caption timing is not valid. Save and re-make this clip instead.")
        previous = start
    return copy.deepcopy(words)


def _posting():
    # Posting imports preflight/jobs too; defer this import until all modules have loaded.
    from . import posting
    return posting


def _uploads(job, clip):
    return copy.deepcopy([p for p in _posting()._posts if p.get("user") == job["user"]
                          and p.get("job") == job["id"] and p.get("clip") == clip["id"]])


def _busy(job, clip):
    return (job.get("status") in ("queued", "running", "live")
            or any(c.get("status") in ("queued", "rendering") for c in job.get("clips", []))
            or any(p.get("status") == "posting" for p in _uploads(job, clip))
            or any(p.get("status") == "posting" for p in (clip.get("posts") or {}).values()))


def available(job, clip):
    """Local eligibility only; the caller also checks whether timing actually failed."""
    if job.get("user") != ctx.uid() or clip.get("status") != "done":
        return False
    if editor.revision(clip) != clip.get("editor_rendered_revision", 0):
        return False
    with _posting()._lock:
        if _busy(job, clip):
            return False
    try:
        editor.source(job, clip)
        editor.cut(job, clip)
        cached_words(clip)
    except (OSError, ValueError, TypeError, KeyError):
        return False
    return True


def _content(clip):
    return copy.deepcopy({k: v for k, v in clip.items() if k not in ("status", "error", "timing_repair", "posts")})


def _source_stamp(path):
    st = path.stat()
    return (str(path.resolve()), st.st_size, st.st_mtime_ns)


def _prior_exists(job, clip):
    try:
        path = preflight.export_path(job, clip)
        return path.is_file() and path.stat().st_size > 0
    except (OSError, ValueError):
        return False


def interrupted(job, clip):
    """Called by job recovery before ordinary remakes; an interrupted repair never starts AI."""
    message = "Timing repair was interrupted. The previous export is unchanged. Check it before retrying."
    clip.update(status="done" if _prior_exists(job, clip) else "error", error=message)
    clip["timing_repair"] = {**clip.get("timing_repair", {}), "status": "error", "message": message}


def request(jid, cid, body):
    lifecycle.require_accepting()
    with jobs._lock, _posting()._lock:
        job = jobs.get(jid)
        clip = next((c for c in job.get("clips", []) if c["id"] == cid), None) if job else None
        if not clip:
            raise KeyError(cid)
        if not isinstance(body, dict) or body.get("confirm") is not True:
            raise ValueError("Confirm the local timing repair before starting it.")
        for field in ("expected_version", "editor_revision"):
            value = body.get(field)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError("Send the saved export version and editor revision. Reopen this clip and try again.")
        if body["expected_version"] != clip.get("version", 0) or body["editor_revision"] != editor.revision(clip):
            raise editor.Conflict("This clip changed. Reopen it and check the new export before repairing it.")
        if not available(job, clip):
            raise editor.Conflict("Repair needs a finished saved clip, its local source and saved captions, with no edits or uploads in progress.")
        report = preflight.check(job, clip)
        if not any(c["status"] == "blocked" and c["code"] in TIMING_CODES for c in report["checks"]):
            raise editor.Conflict("This export has no blocked timing check. Review its other checks instead.")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", cid):
            raise ValueError("The clip name is not valid for a local repair.")
        source, offset = editor.source(job, clip)
        start, end = editor.cut(job, clip)
        words = cached_words(clip)
        settings = copy.deepcopy({**job.get("options", {}), **clip})
        settings.update(start=start - offset, end=end - offset, hook=roman.to_roman(clip.get("hook") or ""))
        near = [dict(w, s=w["s"] - offset, e=w["e"] - offset) for w in words]
        directory = Path(job["dir"]) / "clips"
        version = clip.get("version", 0) + 1
        # Failed or interrupted attempts may have left an artifact. Never replace any previous file.
        while any((directory / f"{cid}-timing-v{version}.{ext}").exists() for ext in ("mp4", "jpg", "ass", "json")):
            version += 1
        name = f"{cid}-timing-v{version}"
        token = uuid.uuid4().hex
        snapshot = {"job": job, "clip": clip, "user": job["user"], "content": _content(clip),
                    "job_status": job.get("status"), "options": copy.deepcopy(job.get("options", {})),
                    "uploads": _uploads(job, clip), "posts": copy.deepcopy(clip.get("posts")),
                    "source": source, "offset": offset, "source_stamp": _source_stamp(source),
                    "settings": settings, "words": words, "near": near, "width": job["width"], "height": job["height"],
                    "directory": directory, "name": name, "version": version, "token": token}
        prior = copy.deepcopy(clip)
        clip.update(status="queued", error=None, timing_repair={"id": token, "status": "queued",
                    "expected_version": body["expected_version"], "editor_revision": body["editor_revision"],
                    "target_version": version, "message": "Local timing repair queued. Previous export is kept."})
        try:
            jobs.save(job)
            # An owned closure, not a ('clip', ...) entry: no render_one, ASR, AI or ready callbacks.
            jobs.submit(lambda: _run(snapshot))
        except Exception:
            clip.clear()
            clip.update(prior)
            jobs.save(job)
            raise
        return {"accepted": True, "status": "queued", "version": body["expected_version"],
                "editor_revision": body["editor_revision"], "target_version": version}


def _owns(snapshot, status):
    job, clip = snapshot["job"], snapshot["clip"]
    return (jobs.get(job["id"]) is job and job.get("user") == snapshot["user"]
            and any(c is clip for c in job.get("clips", []))
            and clip.get("timing_repair", {}).get("id") == snapshot["token"]
            and clip.get("status") == status and clip.get("timing_repair", {}).get("status") == status)


def _unchanged(snapshot, status):
    job, clip = snapshot["job"], snapshot["clip"]
    return (_owns(snapshot, status) and _content(clip) == snapshot["content"]
            and job.get("status") == snapshot["job_status"] and job.get("options", {}) == snapshot["options"]
            and _uploads(job, clip) == snapshot["uploads"] and clip.get("posts") == snapshot["posts"]
            and editor.source(job, clip) == (snapshot["source"], snapshot["offset"])
            and _source_stamp(snapshot["source"]) == snapshot["source_stamp"])


def _fail(snapshot, status, message):
    job, clip = snapshot["job"], snapshot["clip"]
    if not _owns(snapshot, status):
        return
    clip.update(status="done" if _prior_exists(job, clip) else "error", error=message)
    clip["timing_repair"].update(status="error", message=message)
    jobs.save(job)


def _run(snapshot):
    # Even direct execution (tests/recovery) must run as the captured owner, not a worker's last user.
    with ctx.as_user(snapshot["user"]):
        job, clip = snapshot["job"], snapshot["clip"]
        status = "queued"
        try:
            with jobs._lock, _posting()._lock:
                if not _unchanged(snapshot, status):
                    _fail(snapshot, status, "This clip changed while repair was waiting. Its export is unchanged. Reopen it before retrying.")
                    return
                clip["status"] = status = "rendering"
                clip["timing_repair"].update(status=status, message="Repairing the saved export locally. Previous export is kept.")
                jobs.save(job)
            out = render.render_clip(snapshot["source"], snapshot["directory"], snapshot["name"],
                                     snapshot["settings"], snapshot["near"], snapshot["width"], snapshot["height"])
            # render_clip validates its temporary export before publishing files. Only its artifact keys commit.
            if out.get("file") != snapshot["name"] + ".mp4" or out.get("cover") != snapshot["name"] + ".jpg":
                raise ValueError("Unexpected timing repair artifact.")
            with jobs._lock, _posting()._lock:
                if not _unchanged(snapshot, status):
                    _fail(snapshot, status, "This clip or its upload changed during repair. The new file was not selected. Review the saved export before retrying.")
                    return
                history = copy.deepcopy(clip.get("timing_repair_history", []))
                history.append({"version": clip.get("version", 0), "file": clip.get("file"), "cover": clip.get("cover"),
                                "editor_revision": editor.revision(clip)})
                previous = copy.deepcopy(clip)
                clip.update({k: out[k] for k in ("file", "cover", "layout") if k in out}, status="done", error=None,
                            version=snapshot["version"], rendered_words=snapshot["words"],
                            rendered_cut={"start": snapshot["content"]["start"], "end": snapshot["content"]["end"]},
                            editor_rendered_revision=editor.revision(clip), timing_repair_history=history)
                clip["timing_repair"].update(status="done", message="Timing repair finished. Review the new export before posting.")
                try:
                    jobs.save(job)
                except Exception:
                    clip.clear()
                    clip.update(previous)
                    raise
        except Exception:
            with jobs._lock, _posting()._lock:
                _fail(snapshot, status, "Timing repair could not finish. The previous export is unchanged. Check the local video tools and try again.")
