"""Turns a time range into a vertical clip: 9:16 layout, bouncy word captions, hook title, cover."""
import os
import re
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path

from . import config, roman, lifecycle, timeline
from .media import NO_WINDOW, run

W, H = config.OUT_W, config.OUT_H

# ASS colours are &HBBGGRR. `size` is the ASS font size (line height); _Font turns it into real pixels.
STYLES = {
    "bounce": {"label": "Bounce", "font": "Poppins ExtraBold", "size": 132, "base": "FFFFFF", "active": "00F0FF",
               "strong": "FFFFFF", "outline": 7, "pop": 112, "upper": True, "per": 3},
    "hype": {"label": "Hype", "font": "Anton", "size": 152, "base": "FFFFFF", "active": "3C3CFF",
             "strong": "00D7FF", "outline": 7, "pop": 114, "upper": True, "per": 2},
    "clean": {"label": "Clean", "font": "Poppins ExtraBold", "size": 100, "base": "FFFFFF", "active": "6BD7FF",
              "strong": "FFFFFF", "outline": 5, "pop": 106, "upper": False, "per": 4},
    "karaoke": {"label": "Karaoke", "font": "Poppins ExtraBold", "size": 122, "base": "FFFFFF", "active": "60EF79",
                "strong": "FFFFFF", "outline": 6, "pop": 100, "upper": True, "per": 3, "mode": "steady"},
    "neon": {"label": "Neon", "font": "Archivo Black", "size": 122, "base": "FFFFFF", "active": "FFF040",
             "strong": "FFFFFF", "outline": 4, "pop": 108, "upper": True, "per": 3, "glow": True},
    "outline": {"label": "Outline", "font": "Archivo Black", "size": 132, "base": "FFFFFF", "active": "FFFFFF",
                "strong": "FFFFFF", "outline": 10, "pop": 100, "upper": True, "per": 3, "mode": "steady"},
    "typewriter": {"label": "Typewriter", "font": "Poppins ExtraBold", "size": 94, "base": "FFFFFF", "active": "FFFFFF",
                   "strong": "FFFFFF", "outline": 4, "pop": 100, "upper": False, "per": 4, "mode": "typewriter"},
    "subtitle": {"label": "Subtitle", "font": "Poppins ExtraBold", "size": 80, "base": "FFFFFF", "active": "FFFFFF",
                 "strong": "FFFFFF", "outline": 10, "pop": 100, "upper": False, "per": 6, "mode": "subtitle"},
}
HOOK = {"font": "Poppins ExtraBold", "size": 96, "ink": "14100E", "box": "FFFFFF", "pad_x": 36, "pad_y": 22, "radius": 26,
        "max_w": 900}
FONT_FILES = {"Poppins ExtraBold": "Poppins-ExtraBold.ttf", "Anton": "Anton-Regular.ttf", "Archivo Black": "ArchivoBlack-Regular.ttf"}
CAP_MAX_W = 960   # captions never run wider than this, whatever is said


class _Font:
    """Measures text exactly as the renderer will draw it, so every word can be placed by hand: the highlighted
    word can grow without pushing its neighbours, and the heading box fits its text."""
    _cache: dict = {}

    def __init__(self, name):
        import struct
        path = Path(__file__).resolve().parent / "fonts" / FONT_FILES.get(name, FONT_FILES["Poppins ExtraBold"])
        d = path.read_bytes()
        tables = {}
        for i in range(struct.unpack(">H", d[4:6])[0]):
            tag, _, off, _ = struct.unpack(">4sIII", d[12 + 16 * i: 28 + 16 * i])
            tables[tag] = off
        self.upm = struct.unpack(">H", d[tables[b"head"] + 18: tables[b"head"] + 20])[0]
        o = tables[b"OS/2"]
        self.asc, self.desc = struct.unpack(">HH", d[o + 74: o + 78])      # what the renderer sizes the font by
        self.cap = struct.unpack(">h", d[o + 88: o + 90])[0] or int(self.upm * 0.7)
        self.path = str(path)
        self._pil = {}

    @classmethod
    def get(cls, name):
        if name not in cls._cache:
            cls._cache[name] = cls(name)
        return cls._cache[name]

    def em(self, size):
        return size * self.upm / (self.asc + self.desc)

    def width(self, text, size):
        """Pixels wide at this ASS size."""
        try:
            from PIL import ImageFont
            if "f" not in self._pil:
                self._pil["f"] = ImageFont.truetype(self.path, 200)
            return self._pil["f"].getlength(text) * self.em(size) / 200
        except Exception:  # noqa: BLE001 - no measuring library: a fair estimate keeps clips rendering
            return len(text) * self.em(size) * 0.62

    def cap_shift(self, size):
        """How far below the anchor the middle of a capital letter sits when text is centred on a point."""
        return ((self.asc - self.desc) / 2 - self.cap / 2) * size / (self.asc + self.desc)


CAPTION_LEAD = 0.0  # measured: word stamps are within 0.15 s of the voice, so no shift is needed
def install_fonts():
    """Copy the bundled caption fonts next to the data, so captions look the same on every machine and server."""
    src = Path(__file__).resolve().parent / "fonts"
    for f in src.glob("*.ttf"):
        if not (config.FONTS_DIR / f.name).exists():
            shutil.copyfile(f, config.FONTS_DIR / f.name)


LAYOUTS = {"blur": "Full frame + blurred fill", "zoom": "Zoomed in + blurred fill", "crop": "Fill the screen (centre crop)",
           "facecam_top": "Facecam top + gameplay below", "facecam_bottom": "Gameplay above + facecam bottom",
           "two_person": "Two people · equal 50:50 panels", "portrait": "Portrait · selected person crop"}


def clean_split(values) -> dict:
    """Percentages of the original video. Each clip owns its crop settings."""
    import math
    defaults = {"facecam_height": 30, "face_x": 0, "face_y": 0, "face_w": 25, "face_h": 35,
                "game_x": 0, "game_y": 0, "game_w": 100, "game_h": 100}
    out = {}
    for key, default in defaults.items():
        value = float(values.get(key, default))
        if not math.isfinite(value):
            raise ValueError("Crop values must be finite numbers.")
        out[key] = max(20, min(45, value)) if key == "facecam_height" else max(0 if key.endswith(("_x", "_y")) else 5, min(100, value))
    for region in ("face", "game"):
        for position, size in (("x", "w"), ("y", "h")):
            out[f"{region}_{position}"] = min(out[f"{region}_{position}"], 100 - out[f"{region}_{size}"])
    return out


def _ts(t):
    t = max(0.0, t)
    h, m = int(t // 3600), int(t % 3600 // 60)
    return f"{h}:{m:02d}:{t % 60:05.2f}"


def clean_caption(values) -> dict:
    """Caption centre as percentages; an unset vertical position retains the layout default."""
    import math
    out = {}
    fields = {"caption_x": (50.0, 0, 100), "caption_y": (None, 0, 100),
              "caption_size": (100.0, 50, 200), "caption_letter_spacing": (0.0, 0, 20),
              "caption_word_spacing": (0.0, 0, 40), "hook_x": (50.0, 0, 100),
              "hook_y": (None, 0, 100), "hook_size": (100.0, 50, 200)}
    for key, (default, low, high) in fields.items():
        value = values.get(key, default)
        if value in (None, ""):
            out[key] = default
            continue
        value = float(value)
        if not math.isfinite(value):
            raise ValueError("Caption positions must be finite numbers.")
        out[key] = max(low, min(high, value))
    return out


def _clean(text):
    return re.sub(r"[\x00-\x1f\x7f]+", " ", re.sub(r"[{}\\]", "", str(text))).strip()


def _key(word):
    return re.sub(r"[^a-z0-9']", "", word.lower())


def _groups(words, per):
    out, cur = [], []
    for w in words:
        if cur and (len(cur) >= per or sum(len(x["w"]) for x in cur) + len(w["w"]) > 16
                    or w["s"] - cur[-1]["e"] > 0.45 or cur[-1]["w"][-1:] in ".?!"):
            out.append(cur)
            cur = []
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def geometry(src_w, src_h, layout):
    """Where the video sits in the 1080x1920 frame, and where hook and captions go."""
    if layout in ("facecam_top", "facecam_bottom", "two_person"):
        return layout, H, 110, 1040 if layout == "facecam_bottom" else 1450
    if layout == "portrait":
        return layout, H, 300, 1380
    if src_h >= src_w and layout != "crop":
        layout = "crop"  # already vertical or square: nothing to gain from a blurred fill
    if layout == "blur":
        fg_h = min(H, int(round(W * src_h / src_w / 2)) * 2)
    elif layout == "zoom":
        fg_h = 1000
    else:
        fg_h = H
    top = (H - fg_h) // 2
    if layout == "crop":
        return layout, fg_h, 300, 1380
    return layout, fg_h, max(230, top - 190), min(1640, top + fg_h + 180)


def _hook_events(hook, dur, y, x=None, scale=1):
    """The heading: dark text in a white rounded box that fits it, on one line or two balanced ones."""
    f, size = _Font.get(HOOK["font"]), HOOK["size"]
    size = int(size * scale)
    words = hook.split()
    if not words:
        return []
    lines = [" ".join(words)]
    if f.width(lines[0], size) > HOOK["max_w"] and len(words) > 1:      # two lines, split where they come out most even
        cut = min(range(1, len(words)), key=lambda i: max(f.width(" ".join(words[:i]), size), f.width(" ".join(words[i:]), size)))
        lines = [" ".join(words[:cut]), " ".join(words[cut:])]
    widest = max(f.width(l, size) for l in lines)
    if widest > HOOK["max_w"]:
        size = max(40, int(size * HOOK["max_w"] / widest))
        widest = max(f.width(l, size) for l in lines)
    line_h = f.em(size) * 1.16
    bw, bh = widest + 2 * HOOK["pad_x"], line_h * len(lines) + 2 * HOOK["pad_y"]
    x = max(bw / 2, min(W - bw / 2, W / 2 if x is None else x))
    y = max(bh / 2, min(H - bh / 2, y))
    x0, y0, r = x - bw / 2, y - bh / 2, min(HOOK["radius"], bh / 2)
    x1, y1 = x0 + bw, y0 + bh
    n = lambda v: f"{v:.0f}"                                                         # noqa: E731
    box = (f"m {n(x0 + r)} {n(y0)} l {n(x1 - r)} {n(y0)} b {n(x1)} {n(y0)} {n(x1)} {n(y0)} {n(x1)} {n(y0 + r)} "
           f"l {n(x1)} {n(y1 - r)} b {n(x1)} {n(y1)} {n(x1)} {n(y1)} {n(x1 - r)} {n(y1)} "
           f"l {n(x0 + r)} {n(y1)} b {n(x0)} {n(y1)} {n(x0)} {n(y1)} {n(x0)} {n(y1 - r)} "
           f"l {n(x0)} {n(y0 + r)} b {n(x0)} {n(y0)} {n(x0)} {n(y0)} {n(x0 + r)} {n(y0)}")
    span = f"{_ts(0)},{_ts(dur)}"
    ev = [f"Dialogue: 3,{span},Hook,,0,0,0,,{{\\an7\\pos(0,0)\\fad(160,0)\\c&H{HOOK['box']}&\\p1}}{box}{{\\p0}}"]
    for i, line in enumerate(lines):
        cy = y - line_h * (len(lines) - 1) / 2 + i * line_h - f.cap_shift(size)
        ev.append(f"Dialogue: 4,{span},Hook,,0,0,0,,{{\\an5\\pos({x:.0f},{cy:.0f})\\fad(160,0)\\fs{size}}}{line}")
    return ev


def build_ass(words, start, end, hook, style_name, highlight, hook_y, cap_y, cap_x=None, text_settings=None) -> str:
    settings = clean_caption(text_settings or {})
    st = dict(STYLES.get(style_name, STYLES["bounce"]))
    st["size"] = int(st["size"] * settings["caption_size"] / 100)
    st["outline"] = max(1, st["outline"] * settings["caption_size"] / 100)
    tracking, word_space = settings["caption_letter_spacing"], settings["caption_word_spacing"]
    cap_x = W / 2 if cap_x is None else float(cap_x)
    cap_y = max(st["size"], min(H - st["size"], cap_y))
    def centre(width):
        return max(width / 2 + 12, min(W - width / 2 - 12, cap_x))
    words = [dict(w, s=w["s"] - CAPTION_LEAD, e=w["e"] - CAPTION_LEAD) for w in words]
    strong = {_key(h) for h in highlight if _key(h)}
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{st['font']},{st['size']},&H00{st['base']},&H00{st['base']},&H00000000,&H80181818,0,0,0,0,100,100,0,0,{3 if st.get('mode') == 'subtitle' else 1},{st['outline']},0,5,0,0,0,1
Style: Hook,{HOOK['font']},{HOOK['size']},&H00{HOOK['ink']},&H00{HOOK['ink']},&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    dur = end - start
    if settings["hook_y"] is not None:
        hook_y = H * settings["hook_y"] / 100
    ev = _hook_events(_clean(hook), dur, hook_y, W * settings["hook_x"] / 100, settings["hook_size"] / 100)
    f = _Font.get(st["font"])
    measure = lambda text, size: f.width(text, size) + max(0, len(text) - 1) * tracking
    space = f"{{\\fsp{tracking + word_space:g}}} {{\\fsp{tracking:g}}}" if word_space else " "
    inside = [dict(w, w=_clean(w["w"])) for w in words if w["s"] >= start - 0.05 and w["s"] < end]
    inside = sorted((w for w in inside if w["w"]), key=lambda w: w["s"])
    for i, w in enumerate(inside[:-1]):
        w["e"] = max(w["s"], min(w["e"], inside[i + 1]["s"]))
    groups = _groups(inside, st["per"])
    for gi, g in enumerate(groups):
        g_start = max(0.0, g[0]["s"] - start)
        g_end = min(g[-1]["e"] + 0.25, groups[gi + 1][0]["s"] if gi + 1 < len(groups) else end) - start
        if g_end - g_start < 0.02:
            continue
        texts = []
        for x in g:
            t = re.sub(r"[.,;:]+$", "", x["w"])
            texts.append(t.upper() if st["upper"] else t)
        if st.get("mode") in ("typewriter", "subtitle"):
            line = " ".join(texts)
            size = min(st["size"], max(36, int(st["size"] * CAP_MAX_W / max(1, measure(line, st["size"]) + word_space * (len(texts) - 1)))))
            pos = f"\\an5\\pos({centre(measure(line, size) + word_space * (len(texts) - 1)):.0f},{cap_y:.0f})\\fs{size}\\fsp{tracking:g}"
            line = space.join(texts)
            if st["mode"] == "subtitle":
                ev.append(f"Dialogue: 1,{_ts(g_start)},{_ts(g_end)},Cap,,0,0,0,,{{{pos}}}{line}")
            else:
                prefix = ""
                for wi, word in enumerate(g):
                    a = max(g_start, word["s"] - start)
                    b = min(g_end, (g[wi + 1]["s"] - start) if wi + 1 < len(g) else g_end)
                    text = texts[wi]
                    for ci in range(1, len(text) + 1):
                        t0 = a + (b - a) * (ci - 1) / max(1, len(text)) * 0.7
                        t1 = a + (b - a) * ci / max(1, len(text)) * 0.7 if ci < len(text) else b
                        if t1 - t0 >= .01:
                            ev.append(f"Dialogue: 1,{_ts(t0)},{_ts(t1)},Cap,,0,0,0,,{{{pos}}}{prefix}{text[:ci]}")
                    prefix += text + space
            continue
        if not all(roman.drawable(t) for t in texts):
            # A script the caption font cannot draw (Japanese, Thai, Chinese...): its words cannot be measured, so
            # they are not placed one by one. The line is drawn whole and centred, in a font the system has for it.
            line = " ".join(texts)
            fs = max(44, min(int(st["size"] * 0.7), int(1500 / max(1, len(line)) * 1.6)))
            ev.append(f"Dialogue: 1,{_ts(g_start)},{_ts(g_end)},Cap,,60,60,0,,{{\\an5\\pos({centre(CAP_MAX_W):.0f},{cap_y:.0f})\\q0\\fs{fs}}}{line}")
            continue
        size = st["size"]
        gap = f.width("n n", size) - 2 * f.width("n", size) + (2 * st["outline"] + 6) * size / st["size"] + word_space + tracking
        total = sum(measure(t, size) for t in texts) + gap * (len(texts) - 1)
        if total > CAP_MAX_W:                                  # a long phrase: shrink it to fit, never run off the frame
            size = max(36, int(size * CAP_MAX_W / total))
            gap = f.width("n n", size) - 2 * f.width("n", size) + (2 * st["outline"] + 6) * size / st["size"] + word_space + tracking
            total = sum(measure(t, size) for t in texts) + gap * (len(texts) - 1)
        cy = cap_y - f.cap_shift(size)
        x = centre(total) - total / 2
        p = st["pop"]
        for i, (w, t) in enumerate(zip(g, texts)):
            wd = measure(t, size)
            p = 100 if st.get("mode") == "steady" else max(104, min(st["pop"], 100 + int(2200 / max(wd, 1))))
            pos = f"\\an5\\pos({x + wd / 2:.0f},{cy:.0f})\\fs{size}\\fsp{tracking:g}"
            if st.get("glow"):
                pos += "\\blur2\\3c&HAA6020&\\bord6"
            x += wd + gap
            a = max(g_start, w["s"] - start)
            b = (g[i + 1]["s"] - start) if i + 1 < len(g) else g_end
            base = st["strong"] if _key(w["w"]) in strong else st["base"]
            if st.get("mode") == "steady":
                for lo, hi, color in ((g_start, a, base), (a, b, st["active"]), (b, g_end, base)):
                    if hi - lo >= .02:
                        ev.append(f"Dialogue: 1,{_ts(lo)},{_ts(hi)},Cap,,0,0,0,,{{{pos}\\c&H{color}&}}{t}")
                continue
            if a - g_start >= 0.02:                                                   # waiting to be said
                ev.append(f"Dialogue: 1,{_ts(g_start)},{_ts(a)},Cap,,0,0,0,,{{{pos}\\c&H{base}&}}{t}")
            if b - a >= 0.02:                                                         # being said: colour and a quick pop, in front
                ev.append(f"Dialogue: 2,{_ts(a)},{_ts(b)},Cap,,0,0,0,,{{{pos}\\c&H{st['active']}&\\fscx94\\fscy94"
                          f"\\t(0,90,\\fscx{p}\\fscy{p})\\t(90,200,\\fscx{p - 5}\\fscy{p - 5})}}{t}")
            if g_end - b >= 0.02:                                                     # said
                ev.append(f"Dialogue: 1,{_ts(b)},{_ts(g_end)},Cap,,0,0,0,,{{{pos}\\c&H{base}&\\fscx{p - 5}\\fscy{p - 5}"
                          f"\\t(0,90,\\fscx100\\fscy100)}}{t}")
    return head + "\n".join(ev) + "\n"


def _filter(layout, fg_h, split=None):
    if layout == "portrait":
        values = clean_split(split or {})
        x, y, w, h = (values[f"face_{k}"] / 100 for k in ("x", "y", "w", "h"))
        return (f"[0:v]fps={config.OUT_FPS},crop=w='max(2,trunc(iw*{w}/2)*2)':h='max(2,trunc(ih*{h}/2)*2)':"
                f"x='trunc(iw*{x}/2)*2':y='trunc(ih*{y}/2)*2',"
                f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1[v0];")
    if layout in ("facecam_top", "facecam_bottom", "two_person"):
        values = clean_split(split or {})
        face_h = H // 2 if layout == "two_person" else int(H * values["facecam_height"] / 100 / 2) * 2
        game_h = H - face_h
        def region(prefix, height, label):
            x, y, w, h = (values[f"{prefix}_{k}"] / 100 for k in ("x", "y", "w", "h"))
            return (f"crop=w='max(2,trunc(iw*{w}/2)*2)':h='max(2,trunc(ih*{h}/2)*2)':"
                    f"x='trunc(iw*{x}/2)*2':y='trunc(ih*{y}/2)*2',"
                    f"scale={W}:{height}:force_original_aspect_ratio=increase,crop={W}:{height},setsar=1[{label}];")
        order = "[game][face]" if layout == "facecam_bottom" else "[face][game]"
        return (f"[0:v]fps={config.OUT_FPS},split=2[cam][play];[cam]" + region("face", face_h, "face")
                + "[play]" + region("game", game_h, "game") + order + "vstack=inputs=2[v0];")
    if layout == "crop":
        return f"[0:v]fps={config.OUT_FPS},scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1[v0];"
    return (f"[0:v]fps={config.OUT_FPS},split=2[a][b];"
            f"[a]scale=270:480:force_original_aspect_ratio=increase,crop=270:480,boxblur=6:2,"
            f"scale={W}:{H},eq=brightness=-0.14:saturation=1.15[bg];"
            f"[b]scale={W}:{fg_h}:force_original_aspect_ratio=increase,crop={W}:{fg_h}[fg];"
            f"[bg][fg]overlay=0:(H-h)/2,setsar=1[v0];")


_qsv_ok = None
RENDER_SECONDS = 600      # one clip's video encode; far beyond normal, so a frozen encoder is stopped, not waited on


def render_clip(src: Path, out_dir: Path, name: str, clip: dict, words: list, src_w: int, src_h: int) -> dict:
    """Writes <name>.mp4, <name>.jpg and <name>.ass into out_dir. Returns file names."""
    out_dir.mkdir(parents=True, exist_ok=True)
    start, end = clip["start"], clip["end"]
    layout, fg_h, hook_y, cap_y = geometry(src_w, src_h, clip.get("layout", "blur"))
    position = clean_caption(clip)
    if position["caption_y"] is not None:
        cap_y = H * position["caption_y"] / 100
    ass = build_ass(words, start, end, clip.get("hook", ""), clip.get("style", "bounce"),
                    clip.get("highlight_words", []), hook_y, cap_y, W * position["caption_x"] / 100, position)
    # The clip is made in a short work folder and moved into place afterwards. The caption step of ffmpeg cannot
    # open files whose full path is longer than 260 characters on Windows, which a data folder deep inside other
    # folders easily reaches. Inside the work folder every name is short and relative (a drive colon would also
    # break the filter syntax).
    work = Path(tempfile.mkdtemp(prefix="pk"))
    try:
        return _render_in(work, src, out_dir, name, start, end, layout, fg_h, ass, clip)
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _publish_render(work, out_dir, name):
    """Stage a validated set, and restore any previous set if a replace fails."""
    token = uuid.uuid4().hex
    staged, previous, committed = {}, {}, []
    try:
        for ext in ("mp4", "jpg", "ass"):
            target = out_dir / f"{name}.{ext}"
            stage = out_dir / f".{name}-{token}.{ext}.tmp"
            shutil.copyfile(work / f"{name}.{ext}", stage)
            staged[ext] = stage
            if target.is_file():
                backup = out_dir / f".{name}-{token}.{ext}.previous"
                shutil.copyfile(target, backup)
                previous[ext] = backup
        for ext, stage in staged.items():
            os.replace(stage, out_dir / f"{name}.{ext}")
            committed.append(ext)
    except Exception:
        for ext in committed:
            target = out_dir / f"{name}.{ext}"
            if ext in previous:
                os.replace(previous[ext], target)
            else:
                target.unlink(missing_ok=True)
        raise
    finally:
        for path in [*staged.values(), *previous.values()]:
            path.unlink(missing_ok=True)


def _render_in(work: Path, src: Path, out_dir: Path, name: str, start, end, layout, fg_h, ass: str, settings=None) -> dict:
    global _qsv_ok
    (work / f"{name}.ass").write_text(ass, encoding="utf-8")
    (work / "f").mkdir()
    for f in config.FONTS_DIR.glob("*.ttf"):
        shutil.copyfile(f, work / "f" / f.name)
    settings = settings or {}
    height = max(360, min(1080, int(settings.get("quality", 1080))))
    height = height // 2 * 2
    out_h = int(height * H / W / 2) * 2
    timeline.validate_source_cut(src, start, end)
    layout_filter = _filter(layout, fg_h, settings).replace("[0:v]", "[cutv]")
    fc = timeline.cut_filters(start, end) + layout_filter + f"[v0]ass={name}.ass:fontsdir=f,scale={height}:{out_h}[v]"
    base = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-copyts", "-start_at_zero", "-i", str(src),
            "-filter_complex", fc, "-map", "[v]", "-map", "[cuta]", "-t", f"{end - start:.6f}",
            "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-movflags", "+faststart", "-pix_fmt"]
    encoders = []
    if _qsv_ok is not False:
        encoders.append(("qsv", ["nv12", "-c:v", "h264_qsv", "-global_quality", "23", "-preset", "fast"]))
    encoders.append(("x264", ["yuv420p", "-c:v", "libx264", "-crf", "21", "-preset", "veryfast"]))
    err = None
    for label, enc in encoders:
        p = lifecycle.run_process(base + enc + [f"{name}.mp4"], cwd=work, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", creationflags=NO_WINDOW, timeout=RENDER_SECONDS)
        if p.returncode == 0:
            if label == "qsv":
                _qsv_ok = True
            break
        err = p.stderr[-1200:]
        if label == "qsv":
            _qsv_ok = False
    else:
        raise RuntimeError(f"Render failed: {err}")
    timeline.validate_export(work / f"{name}.mp4", end - start)
    cover_t = min(1.2, (end - start) / 2)
    run(["ffmpeg", "-y", "-v", "error", "-ss", f"{cover_t:.2f}", "-i", f"{name}.mp4", "-frames:v", "1",
         "-q:v", "3", f"{name}.jpg"], cwd=work)
    _publish_render(work, out_dir, name)
    return {"file": f"{name}.mp4", "cover": f"{name}.jpg", "layout": layout}
