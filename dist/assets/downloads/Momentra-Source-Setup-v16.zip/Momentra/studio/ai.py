"""Talking to the AI service. You bring your own key, and choose the service and model in the dashboard
(Settings, AI) or in .env. What is saved from the dashboard is kept in ai.json in the data folder and wins.

    PEAKCUT_AI_PROVIDER   gemini | openai | xai | groq | openrouter | anthropic | ollama | custom
    PEAKCUT_AI_MODELS     one or more model ids, comma separated, tried in this order
    PEAKCUT_AI_KEY        your key (or PEAKCUT_AI_KEY_FILE, a file holding it)
    PEAKCUT_AI_BASE_URL   only for "custom" (any service that speaks the OpenAI chat format), or to override

Every service is asked for the same thing: JSON that follows a small schema. Gemini takes the schema directly.
The others are told the schema in the prompt and asked for a JSON object, which works with any chat model."""
import json
import os
import re
import threading
from contextlib import contextmanager
from contextvars import ContextVar
from urllib.parse import urlsplit

import httpx

from . import config

# name -> (label shown on the pages, address, how it is spoken to, where to get a key, an example model id)
PROVIDERS = {
    "gemini": ("Gemini", "https://generativelanguage.googleapis.com/v1beta/models", "gemini", "https://aistudio.google.com/apikey", "gemini-2.5-flash"),
    "openai": ("OpenAI", "https://api.openai.com/v1", "openai", "https://platform.openai.com/api-keys", "gpt-4o-mini"),
    "xai": ("Grok", "https://api.x.ai/v1", "openai", "https://console.x.ai", "grok-4"),
    "groq": ("Groq", "https://api.groq.com/openai/v1", "openai", "https://console.groq.com/keys", "llama-3.3-70b-versatile"),
    "openrouter": ("OpenRouter", "https://openrouter.ai/api/v1", "openai", "https://openrouter.ai/keys", "google/gemini-2.5-flash"),
    "numes": ("Numes", "https://api.numes.ai/api/v1", "openai", "https://numes.ai/docs/quickstart", "deepseek/deepseek-v4.1-flash:free"),
    "nocode": ("NoCode (custom API address)", "", "openai", "", ""),
    "anthropic": ("Claude", "https://api.anthropic.com/v1", "anthropic", "https://console.anthropic.com", ""),
    "ollama": ("Ollama (on this machine)", "http://127.0.0.1:11434/v1", "openai", "https://ollama.com", "llama3.1"),
    "custom": ("Custom (OpenAI-compatible)", "", "openai", "", ""),
}
ALIASES = {"google": "gemini", "grok": "xai", "claude": "anthropic", "local": "ollama"}
NO_KEY = {"ollama", "custom"}       # a model running on your own machine needs no key

# ---------------------------------------------------------------- the settings in use
_lock = threading.RLock()
_saved = {"at": None, "data": {}}
_request_settings = ContextVar("ai_request_settings", default=None)
_attempt_hook = ContextVar("ai_attempt_hook", default=None)


def _file():
    return config.DATA_DIR / "ai.json"


def _provider_id(value):
    p = str(value or "").strip().lower()
    return ALIASES.get(p, p)


def _models(value):
    if isinstance(value, str):
        value = value.split(",")
    if not isinstance(value, (list, tuple)):
        raise ValueError("Enter the model to use.")
    ms = []
    for model in value:
        if not isinstance(model, str):
            raise ValueError("A model id must be text.")
        m = model.strip()
        if not m:
            continue
        if len(m) > 120 or not re.fullmatch(r"[\w.\-:/@]+", m):
            raise ValueError("A model id has letters, digits and . - : / @ only.")
        ms.append(m)
    if not ms or len(ms) > 5:
        raise ValueError("Enter between one and five model ids.")
    return ms


def _address(value, p):
    if not isinstance(value, str):
        raise ValueError("The address must be text.")
    address = value.strip().rstrip("/")
    if address:
        try:
            url = urlsplit(address)
            valid = (url.scheme in ("http", "https") and url.hostname and not url.username
                     and not url.password and not url.query and not url.fragment and url.port != 0)
        except ValueError:
            valid = False
        if len(address) > 300 or re.search(r"\s", address) or not valid:
            raise ValueError("Use an http:// or https:// address without a password, query or fragment.")
    if p in ("custom", "nocode") and not address:
        raise ValueError("A custom service needs its address, for example http://127.0.0.1:1234/v1")
    return address


def _credential(value):
    if not isinstance(value, str) or len(value) > 400 or re.search(r"[\r\n\x00]", value):
        raise ValueError("The key must be a single line of text, at most 400 characters.")
    return value.strip()


def _profile(p, data):
    if p not in PROVIDERS or not isinstance(data, dict) or not {"models", "base_url", "key"} <= data.keys():
        raise ValueError("The saved AI profile is incomplete.")
    if not isinstance(data["models"], list):
        raise ValueError("The saved profile's models must be a list.")
    return {"models": _models(data["models"]), "base_url": _address(data["base_url"], p),
            "key": _credential(data["key"])}


def _normalize(data):
    """Validate before changing anything. Old dashboard files become one matching profile in memory only."""
    if not isinstance(data, dict):
        raise ValueError("The saved AI settings must be a JSON object.")
    version = data.get("version", 1)
    if type(version) is not int or version not in (1, 2):
        raise ValueError("This version of the saved AI settings is not supported.")
    if version == 2:
        p = data.get("active_provider")
        profiles = data.get("profiles")
        if not isinstance(profiles, dict) or not profiles or p not in profiles:
            raise ValueError("The saved AI settings need an active provider and its profile.")
        normalized = {pid: _profile(pid, row) for pid, row in profiles.items()}
        # If present, v9's read-compatible fields must describe the same active profile.
        if any(field in data for field in ("provider", "models", "base_url", "key")):
            if data.get("provider") != p or _profile(p, data) != normalized[p]:
                raise ValueError("The saved AI settings disagree about the active profile.")
        return {"version": 2, "active_provider": p, "profiles": normalized}
    if "profiles" in data or "active_provider" in data:
        raise ValueError("The saved AI profile version is missing or incorrect.")
    p = _provider_id(data.get("provider"))
    # A missing legacy key used to fall back to the environment, but only for that provider.
    old = dict(data)
    old.setdefault("base_url", "")
    old.setdefault("key", config.ai_key() if p == _provider_id(config.AI_PROVIDER) else "")
    return {"version": 1, "active_provider": p, "profiles": {p: _profile(p, old)}}


def _json_object(pairs):
    data = {}
    for name, value in pairs:
        if name in data:
            raise ValueError("The saved settings contain a repeated field.")
        data[name] = value
    return data


def _from_dashboard() -> dict:
    """Read-only, including legacy normalization. Invalid files are never treated as an empty file."""
    f = _file()
    with _lock:
        try:
            stat = f.stat()
        except FileNotFoundError:
            _saved.update(at=(str(f), None), data={})
            return {}
        except OSError:
            raise ValueError("The saved AI settings cannot be read. Check the file before saving.") from None
        at = (str(f), stat.st_mtime_ns, stat.st_size, stat.st_ino)
        if _saved["at"] != at:
            try:
                if not f.is_file() or stat.st_size > 128 * 1024:
                    raise ValueError("Invalid settings file.")
                data = _normalize(json.loads(f.read_text(encoding="utf-8"), object_pairs_hook=_json_object))
            except (OSError, ValueError, TypeError, KeyError):
                raise ValueError("The saved AI settings are damaged or use an unsupported version. Restore the file before saving.") from None
            _saved.update(at=at, data=data)
        return _saved["data"]


def _configured():
    return {"provider": _provider_id(config.AI_PROVIDER), "models": list(config.AI_MODELS),
            "base_url": config.AI_BASE_URL.rstrip("/"), "key": config.ai_key()}


def snapshot(provider_id=None) -> dict:
    """Internal only: one provider's settings, captured together. Never send or log this dictionary."""
    with _lock:
        d = _from_dashboard()
        p = _provider_id(provider_id) if provider_id is not None else d.get("active_provider")
        configured = _configured()
        if not p:
            p = configured["provider"]
        if p in d.get("profiles", {}):
            row = d["profiles"][p]
            return {"provider": p, "models": list(row["models"]), "base_url": row["base_url"], "key": row["key"]}
        if configured["provider"] == p:
            return configured
        return {"provider": p, "models": [], "base_url": "", "key": ""}


def current() -> dict:
    """The active dashboard profile, or the environment when nothing has been saved."""
    captured = _request_settings.get()
    return {**captured, "models": list(captured["models"])} if captured is not None else snapshot()


def provider() -> str:
    return current()["provider"]


def models() -> list:
    return current()["models"]


def key() -> str:
    return current()["key"]


def _base(c):
    return c["base_url"] or PROVIDERS.get(c["provider"], ("", ""))[1]


def _ready(c):
    return bool(c["provider"] in PROVIDERS and c["models"] and _base(c)
                and (c["key"] or c["provider"] in NO_KEY))


def label() -> str:
    return PROVIDERS.get(provider(), ("",))[0]


def base_url() -> str:
    return _base(current())


def ready() -> bool:
    try:
        return _ready(current())
    except ValueError:
        return False


def _public_profile(c, saved):
    return {"models": list(c["models"]), "base_url": c["base_url"], "has_key": bool(c["key"]),
            "ready": _ready(c), "saved_here": saved}


def public() -> dict:
    """Only metadata and key presence. No keys, hints, suffixes or other credential fragments."""
    with _lock:
        d = _from_dashboard()
        c = snapshot()
        saved = bool(d)
        profiles = {p: _public_profile(snapshot(p), p in d.get("profiles", {})) for p in PROVIDERS}
        return {"version": 2, "active_provider": c["provider"], "provider": c["provider"],
                **_public_profile(c, saved), "label": PROVIDERS.get(c["provider"], ("",))[0],
                "profiles": profiles,
                "providers": [{"id": k, "label": v[0], "address": v[1], "needs_key": k not in NO_KEY,
                               "key_url": v[3], "example": v[4]} for k, v in PROVIDERS.items()]}


def _write(d):
    """Called under the lock: back up a validated legacy file once, then atomically replace it."""
    f = _file()
    old = _from_dashboard()
    if old and old["version"] == 1:
        backup = f.with_name("ai.json.v1.bak")
        try:
            with backup.open("xb") as out:
                out.write(f.read_bytes())
            os.chmod(backup, 0o600)
        except FileExistsError:
            pass
        except OSError:
            raise ValueError("The old AI settings could not be backed up. Nothing was changed.") from None
    p = d["active_provider"]
    payload = {"version": 2, "active_provider": p, "profiles": d["profiles"],
               "provider": p, **d["profiles"][p]}  # v9 can still READ the active settings; its WRITES discard profiles.
    tmp = f.with_name("ai.json.tmp")
    try:
        with tmp.open("w", encoding="utf-8") as out:
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            json.dump(payload, out)
            out.flush()
            os.fsync(out.fileno())
        tmp.replace(f)
    except OSError:
        raise ValueError("The AI settings could not be saved. Check the data folder.") from None
    finally:
        _saved["at"] = None
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def _state():
    d = _from_dashboard()
    if d:
        return {"active_provider": d["active_provider"], "profiles": {p: dict(row) for p, row in d["profiles"].items()}}
    c = _configured()
    profiles = {}
    if c["provider"] in PROVIDERS and c["models"]:
        profiles[c["provider"]] = _profile(c["provider"], c)
    return {"active_provider": c["provider"], "profiles": profiles}


def save(provider_id: str, model_ids, address: str = "", new_key=None, *, activate=True,
         remove_key=False, confirm_remove_key=False) -> dict:
    """Update only the chosen provider. Omitted/blank keys keep its key; removal requires confirmation.
    Existing Python/API callers still activate by default; the profile editor saves with activate=False."""
    p = _provider_id(provider_id)
    if p not in PROVIDERS:
        raise ValueError("Choose one of the AI services in the list.")
    if type(activate) is not bool or type(remove_key) is not bool or type(confirm_remove_key) is not bool:
        raise ValueError("The AI action flags must be true or false.")
    with _lock:
        d = _state()
        old = snapshot(p)
        if remove_key:
            if not confirm_remove_key:
                raise ValueError("Confirm removing the key for this service first.")
            if p not in d["profiles"]:
                raise ValueError("Save this service's profile before removing its key.")
            row = dict(d["profiles"][p])
            row["key"] = ""
        else:
            ms = _models(model_ids)
            endpoint = _address(address, p)
            typed = "" if new_key is None else _credential(new_key)
            k = typed or old["key"]
            if not k and p not in NO_KEY:
                raise ValueError("Paste the key for this service.")
            row = {"models": ms, "base_url": endpoint, "key": k}
        d["profiles"][p] = row
        if (activate and not remove_key) or d["active_provider"] not in d["profiles"]:
            d["active_provider"] = p
        _write(d)
        return public()


def use(provider_id) -> dict:
    """Switch to a saved profile without changing it or making a network request."""
    p = _provider_id(provider_id)
    with _lock:
        d = _state()
        if p not in d["profiles"]:
            raise ValueError("Save this service's profile before using it.")
        d["active_provider"] = p
        _write(d)
        return public()


@contextmanager
def using_snapshot(settings=None):
    """Keep credentials together through an in-flight request and all of its retries."""
    captured = settings if settings is not None else (_request_settings.get() or current())
    captured = {**captured, "models": list(captured["models"])}
    token = _request_settings.set(captured)
    try:
        yield
    finally:
        _request_settings.reset(token)


@contextmanager
def request_attempts(before_attempt):
    """Run a no-argument budget callback before EACH transport attempt, including format retries.
    The callback may raise to stop a request. It is local to this thread/task and stores no credentials."""
    token = _attempt_hook.set(before_attempt)
    try:
        yield
    finally:
        _attempt_hook.reset(token)


def _transport(method, *args, **kwargs):
    before = _attempt_hook.get()
    if before is not None:
        before()
    try:
        return getattr(httpx, method)(*args, **kwargs)
    except httpx.RequestError:
        raise AIError("Could not connect to the AI service, or the request timed out.") from None


def list_models(provider_id=None, address=None, with_key=None) -> list:
    """An explicit model lookup uses only the selected provider's saved or newly typed key."""
    c = snapshot(provider_id)
    p = c["provider"]
    if p not in PROVIDERS:
        raise ValueError("Choose one of the AI services in the list.")
    k = (_credential(with_key) if with_key is not None else "") or c["key"]
    base = _address(address, p) if address else _base(c)
    if not base:
        raise ValueError("Enter the service's address first.")
    how = PROVIDERS[p][2]
    if how == "gemini":
        r = _transport("get", base, params={"pageSize": 200}, headers={"x-goog-api-key": k}, timeout=20)
    elif how == "anthropic":
        r = _transport("get", f"{base}/models", params={"limit": 200}, headers={"x-api-key": k, "anthropic-version": "2023-06-01"}, timeout=20)
    else:
        r = _transport("get", f"{base}/models", headers={"Authorization": f"Bearer {k}"} if k else {}, timeout=20)
    if r.status_code != 200:
        _fail(r, "")
    data = r.json()
    if how == "gemini":
        found = [m.get("name", "").split("/")[-1] for m in data.get("models", [])
                 if isinstance(m, dict) and "generateContent" in (m.get("supportedGenerationMethods") or [])]
    else:
        found = [m.get("id", "") for m in data.get("data", []) if isinstance(m, dict)]
    # A service's raw error/answer may echo credentials. Only return valid ids, never an echoed key.
    return sorted({m for m in found if isinstance(m, str) and re.fullmatch(r"[\w.\-:/@]{1,120}", m)
                   and (not k or k not in m)})[:400]


def test(provider_id=None) -> dict:
    """Explicitly test the selected saved profile, without changing the active provider or saving anything."""
    c = snapshot(provider_id)
    if not _ready(c):
        raise ValueError("Save a service, a model and a key first.")
    model = c["models"][0]
    with using_snapshot(c):
        out, sent, wrote = call(model, 'Answer with a JSON array that holds the single string "ok".', {"type": "ARRAY", "items": {"type": "STRING"}})
    if out != ["ok"]:
        raise AIError("The AI did not return the expected test answer.")
    return {"ok": True, "provider": c["provider"], "model": model, "tokens": sent + wrote, "answer": "ok"}


class AIError(RuntimeError):
    def __init__(self, message, *, status=None, retry_after=0):
        super().__init__(message)
        self.status, self.retry_after = status, retry_after


problem = {"text": "", "at": 0.0}       # why the AI last failed, for the dashboard; cleared when it answers again


def explain(e) -> str:
    """What went wrong with an AI call, in words the owner can act on."""
    text, low = str(e), str(e).lower()
    name = (models() or ["?"])[0]
    if "404" in text or "not found" in low or "does not exist" in low or "unknown model" in low or "not_found" in low:
        return f"{label()} doesn't know the model \"{name}\". Open Settings, AI, press Find models and pick one from the list."
    if "401" in text or "403" in text or "api key" in low or "api_key" in low or "unauthorized" in low or "permission" in low:
        return f"{label()} refused the key. Paste a working key under Settings, AI."
    if "402" in text or "429" in text or "quota" in low or "rate limit" in low or "exhausted" in low:
        return f"{label()} says the key has hit its limit or has no credit left. Check the account with {label()}, or try again later."
    if "connect" in low or "timed out" in low or "timeout" in low or "getaddrinfo" in low or "refused" in low:
        return f"Momentra couldn't reach {label()}. Check the internet connection" + (" and that Ollama is running." if provider() == "ollama" else ".")
    return ""


def note_problem(e):
    import time
    why = explain(e)
    if why:
        problem.update(text=why, at=time.time())


def clear_problem():
    problem.update(text="", at=0.0)


def _fail(r, model):
    # Providers may echo all or part of a key in an error. Never keep their raw body in errors or logs.
    try:
        retry = float(getattr(r, "headers", {}).get("Retry-After", 0))
    except (TypeError, ValueError):
        retry = 0
    raise AIError(f"HTTP {r.status_code}: the AI service refused the request.", status=r.status_code, retry_after=retry)


# ---------------------------------------------------------------- the schema, said in words for chat models
def _json_schema(s):
    """Gemini's schema spelling (ARRAY, OBJECT...) as ordinary JSON Schema."""
    if isinstance(s, dict):
        return {k: (v.lower() if k == "type" and isinstance(v, str) else _json_schema(v)) for k, v in s.items()}
    if isinstance(s, list):
        return [_json_schema(x) for x in s]
    return s


def _wrapped(prompt, schema):
    return (prompt + "\n\nAnswer with JSON only, no other text and no code fences: one object with a single key "
            "\"items\", whose value follows this JSON Schema:\n" + json.dumps(_json_schema(schema)))


def _parse(text):
    """The JSON in an answer, even if the model wrapped it in a code fence or a sentence."""
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        out = json.loads(text)
    except ValueError:
        m = re.search(r"[\[{].*[\]}]", text, re.S)
        if not m:
            raise AIError("The AI did not answer with JSON.")
        out = json.loads(m.group(0))
    if isinstance(out, dict) and "items" in out:
        out = out["items"]
    return out


# ---------------------------------------------------------------- one call
def call(model: str, prompt: str, schema: dict):
    """Ask one model. Returns (the parsed JSON answer, tokens sent, tokens written back)."""
    with using_snapshot():
        c = _request_settings.get()
        if c["provider"] not in PROVIDERS:
            raise ValueError("Choose one of the AI services in the list.")
        how = PROVIDERS[c["provider"]][2]
        return {"gemini": _gemini, "openai": _openai, "anthropic": _anthropic}[how](model, prompt, schema)


def _adapter_settings():
    # Direct internal-adapter callers remain supported, without repeated reads during one request.
    return _request_settings.get() or current()


def _gemini(model, prompt, schema):
    c = _adapter_settings()
    body = {"contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.4, "responseMimeType": "application/json", "responseSchema": schema}}
    r = _transport("post", f"{_base(c)}/{model}:generateContent", json=body, headers={"x-goog-api-key": c["key"]}, timeout=120)
    if r.status_code != 200:
        _fail(r, model)
    data = r.json()
    text = "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"])
    u = data.get("usageMetadata", {})
    sent = int(u.get("promptTokenCount") or 0)
    return json.loads(text), sent, max(0, int(u.get("totalTokenCount") or 0) - sent)   # the answer, and any thinking billed with it


def _openai(model, prompt, schema):
    c = _adapter_settings()
    headers = {"Authorization": f"Bearer {c['key']}"} if c["key"] else {}
    body = {"model": model, "messages": [{"role": "user", "content": _wrapped(prompt, schema)}]}
    # Most services accept these two extras; a few models refuse one of them, so they are dropped on a refusal.
    extras = [{"temperature": 0.4, "response_format": {"type": "json_object"}}, {"response_format": {"type": "json_object"}}, {}]
    r = None
    for extra in extras:
        r = _transport("post", f"{_base(c)}/chat/completions", json={**body, **extra}, headers=headers, timeout=180)
        if r.status_code not in (400, 422):
            break
    if r.status_code != 200:
        _fail(r, model)
    data = r.json()
    u = data.get("usage") or {}
    return _parse(data["choices"][0]["message"].get("content")), int(u.get("prompt_tokens") or 0), int(u.get("completion_tokens") or 0)


def _anthropic(model, prompt, schema):
    c = _adapter_settings()
    body = {"model": model, "max_tokens": 8192, "messages": [{"role": "user", "content": _wrapped(prompt, schema)}]}
    r = _transport("post", f"{_base(c)}/messages", json=body, timeout=180,
                   headers={"x-api-key": c["key"], "anthropic-version": "2023-06-01"})
    if r.status_code != 200:
        _fail(r, model)
    data = r.json()
    text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    u = data.get("usage") or {}
    return _parse(text), int(u.get("input_tokens") or 0), int(u.get("output_tokens") or 0)
