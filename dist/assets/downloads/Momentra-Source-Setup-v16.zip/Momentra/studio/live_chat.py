"""Independent read-only chats for one recording. Message text is a bounded local preview, never an AI prompt."""
import collections
from datetime import datetime
import json
import math
import re
import socket
import ssl
import threading
import time
from urllib.parse import urlparse, quote
import uuid

import httpx

NAMES = {"twitch": "Twitch", "kick": "Kick", "youtube": "YouTube"}


def source_platform(url):
    host = (urlparse(url).hostname or "").lower()
    return next((p for p, domains in {"twitch": ("twitch.tv", "www.twitch.tv"),
        "kick": ("kick.com", "www.kick.com"), "youtube": ("youtube.com", "www.youtube.com", "youtu.be")}.items() if host in domains), None)


def channel_url(platform, url):
    """Only named public platform hosts; never arbitrary hosts or embedded credentials."""
    url = str(url or "").strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    parsed = urlparse(url)
    if source_platform(url) != platform or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise ValueError("Chat needs a valid linked platform channel.")
    if platform in ("twitch", "kick"):
        slug = parsed.path.strip("/")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,60}", slug):
            raise ValueError("Chat needs a channel link, not a clip or saved video.")
        return f"https://{'www.twitch.tv' if platform == 'twitch' else 'kick.com'}/{slug.lower()}"
    if not re.fullmatch(r"/(?:@[\w.\-]+|channel/[\w-]+)(?:/live)?/?", parsed.path) and not (
        re.fullmatch(r"/(?:watch|live/[\w-]{11})", parsed.path) or parsed.hostname == "youtu.be"):
        raise ValueError("YouTube chat needs a channel or live video link.")
    return "https://" + parsed.netloc + parsed.path + (("?" + parsed.query) if parsed.query else "")


def selected_sources(settings, video_url):
    source = source_platform(video_url)
    if settings.get("chat_mode") == "combined":
        platforms = list(dict.fromkeys(settings.get("chat_platforms") or []))[:2]
    else:
        platforms = [source] if source else []
    channels = settings.get("channels") or {}
    result = {}
    for p in platforms:
        url = video_url if p == source else channels.get(p)
        if url:
            try:
                result[p] = channel_url(p, url)
            except ValueError:
                continue
    return result


class Hub:
    def __init__(self, settings, video_url, clock, stopping, notify=lambda: None):
        self.sources = selected_sources(settings, video_url)
        self.video_platform = source_platform(video_url)
        self.clock, self.stopping = clock, stopping
        self.stop_event = threading.Event()
        self.lock = threading.RLock()
        self.offsets = dict(settings.get("chat_offsets") or {})
        self.counts = {p: collections.Counter() for p in self.sources}
        self.states = {p: {"platform": p, "label": NAMES[p], "status": "connecting", "total": 0,
                           "message": "Connecting to public live chat."} for p in self.sources}
        self.messages = collections.deque(maxlen=80)
        self.seen = {p: collections.OrderedDict() for p in self.sources}
        self.resources = {}
        self.threads = []
        self.started_wall = time.time()
        self.notify, self.notified_at = notify, 0

    def changed(self):
        now = time.monotonic()
        if now - self.notified_at >= 1:
            self.notified_at = now
            self.notify()

    def stopped(self):
        return self.stop_event.is_set() or self.stopping()

    def state(self, platform, status, message=""):
        with self.lock:
            if self.stopped() and status != "stopped":
                return
            self.states[platform].update(status=status, message=message)
        self.changed()

    def attach(self, platform, resource):
        with self.lock:
            if self.stopped():
                resource.close()
                return False
            self.resources[platform] = resource
            return True

    def start(self):
        for p, url in self.sources.items():
            thread = threading.Thread(target=self._run, args=(p, url), name="live-chat-" + p, daemon=True)
            self.threads.append(thread)
            thread.start()

    def close(self):
        self.stop_event.set()
        with self.lock:
            resources = list(self.resources.values())
            self.resources.clear()
            for p in self.states:
                self.states[p].update(status="stopped", message="Recording stopped.")
        for resource in resources:
            try:
                resource.close()
            except Exception:
                pass

    def add(self, platform, ident, text, author="", sent_at=None):
        if self.stopped() or platform not in self.sources or not isinstance(text, str) or not text.strip():
            return False
        now = time.time()
        if sent_at is not None and (not math.isfinite(sent_at) or sent_at < self.started_wall - 2 or abs(now - sent_at) > 120):
            return False  # Drop initial history/replays and stale bursts on reconnect.
        clock = float(self.clock())
        if clock <= 0:
            return False  # No recorded video yet; do not create a start-up spike.
        offset = float(self.offsets.get(platform, 0))
        at = clock + (min(0, sent_at - now) if sent_at is not None else 0) + offset
        if at < 0:
            return False
        key = str(ident or "")[:200]
        if not key:
            return False
        with self.lock:
            if key in self.seen[platform]:
                return False
            self.seen[platform][key] = True
            while len(self.seen[platform]) > 10000:
                self.seen[platform].popitem(last=False)
            self.counts[platform][int(at)] += 1
            self.states[platform]["total"] += 1
            self.messages.append({"platform": platform, "label": NAMES[platform], "time": round(at, 2),
                                  "text": re.sub(r"[\x00-\x1f\x7f]", " ", text)[:400],
                                  "author": re.sub(r"[\x00-\x1f\x7f]", " ", str(author))[:60]})
            cutoff = max(0, int(clock) - 8 * 3600)
            for sec in list(self.counts[platform]):
                if sec < cutoff:
                    del self.counts[platform][sec]
        self.changed()
        return True

    def snapshot(self):
        with self.lock:
            return {"sources": [dict(s, offset=self.offsets.get(p, 0)) for p, s in self.states.items()],
                    "messages": sorted(self.messages, key=lambda m: m["time"])}

    def series(self, start, end):
        with self.lock:
            if not any(s["status"] == "connected" or s["total"] for s in self.states.values()):
                return None
            return [sum(c.get(t, 0) for c in self.counts.values()) for t in range(start, end)]

    def strongest_series(self, start, end):
        """Each chat competes against its own baseline, so the biggest one cannot drown out another."""
        with self.lock:
            available = [c for p, c in self.counts.items() if self.states[p]["status"] == "connected" or self.states[p]["total"]]
            if not available:
                return None
            rows = []
            for counts in available:
                baseline_start, baseline_end = max(0, end - 190), max(0, end - 10)
                base = sum(counts.get(t, 0) for t in range(baseline_start, baseline_end)) / max(1, baseline_end - baseline_start)
                rows.append([counts.get(t, 0) / max(base, 1.) for t in range(start, end)])
            return [max(values) for values in zip(*rows)]

    def spike(self, now):
        with self.lock:
            for p, counts in self.counts.items():
                baseline = sum(counts.get(t, 0) for t in range(max(0, now - 190), now - 10)) / max(1, min(180, now - 10))
                recent = sum(counts.get(t, 0) for t in range(max(0, now - 8), now)) / 8
                if recent >= max(1.5, baseline * 1.6):
                    return f"{NAMES[p]} chat +{round((recent / max(baseline, .01) - 1) * 100)}%"
        return None

    def _run(self, platform, url):
        while not self.stopped():
            try:
                self.state(platform, "connecting", "Connecting to public live chat.")
                {"twitch": self._twitch, "youtube": self._youtube, "kick": self._kick}[platform](url)
                if not self.stopped():
                    self.state(platform, "reconnecting", "Chat disconnected. Recording continues; retrying shortly.")
            except Exception:
                if not self.stopped():
                    self.state(platform, "unavailable", f"{NAMES[platform]} chat is offline, blocked or unavailable. Recording continues; retrying.")
            finally:
                with self.lock:
                    resource = self.resources.pop(platform, None)
                if resource:
                    try:
                        resource.close()
                    except Exception:
                        pass
            if self.stopped():
                break
            if self.stop_event.wait(60):
                break

    def _twitch(self, url):
        from . import profiles
        if self.video_platform != "twitch" and not profiles.live_shared("twitch", url).get("live"):
            raise ValueError("Twitch channel is offline or unavailable")
        channel = urlparse(url).path.strip("/")
        raw = socket.create_connection(("irc.chat.twitch.tv", 6697), timeout=15)
        try:
            sock = ssl.create_default_context().wrap_socket(raw, server_hostname="irc.chat.twitch.tv")
        except Exception:
            raw.close()
            raise
        if not self.attach("twitch", sock):
            return
        sock.settimeout(2)
        sock.sendall(f"CAP REQ :twitch.tv/tags twitch.tv/commands\r\nNICK justinfan{uuid.uuid4().int % 90000 + 10000}\r\nJOIN #{channel}\r\n".encode())
        rest = b""
        live_checked = time.monotonic()
        while not self.stopped():
            if self.video_platform != "twitch" and time.monotonic() - live_checked >= 75:
                live_checked = time.monotonic()
                if not profiles.live_shared("twitch", url).get("live"):
                    raise ValueError("Twitch channel ended")
            try:
                data = sock.recv(8192)
            except socket.timeout:
                continue
            if not data:
                return
            *lines, rest = (rest + data).split(b"\r\n")
            if len(rest) > 65536:
                raise ValueError("Oversized IRC message")
            for line in lines:
                text = line.decode("utf-8", errors="replace")
                if text.startswith("PING"):
                    sock.sendall(b"PONG :tmi.twitch.tv\r\n")
                elif f" JOIN #{channel}" in text or f" ROOMSTATE #{channel}" in text:
                    self.state("twitch", "connected", "Reading public live chat.")
                elif "Login authentication failed" in text or "Improperly formatted auth" in text:
                    raise ValueError("Twitch refused chat access")
                elif f" PRIVMSG #{channel} :" in text:
                    tags = dict(part.split("=", 1) for part in text[1:].split(" ", 1)[0].split(";") if "=" in part) if text.startswith("@") else {}
                    author = tags.get("display-name") or ""
                    stamp = float(tags["tmi-sent-ts"]) / 1000 if tags.get("tmi-sent-ts", "").isdigit() else None
                    self.state("twitch", "connected", "Reading public live chat.")
                    self.add("twitch", tags.get("id") or str(uuid.uuid4()), text.split(f" PRIVMSG #{channel} :", 1)[1], author, stamp)

    def _youtube(self, url):
        import yt_dlp
        from yt_dlp.extractor.youtube import YoutubeIE
        from yt_dlp.networking import Request
        # Reuse the bundled extractor's current webpage parser and public cookie handling.
        # No video/audio download or posting credentials are used for this connection.
        with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "skip_download": True, "socket_timeout": 15,
                              "retries": 0, "extractor_retries": 0, "noplaylist": True}) as ydl:
            if not self.attach("youtube", ydl):
                return
            info = ydl.extract_info(url.rstrip("/") + ("/live" if re.search(r"youtube.com/(?:@[^/]+|channel/[^/]+)$", url) else ""), download=False)
            if self.stopped():
                return
            if not info or not info.get("is_live") or not re.fullmatch(r"[\w-]{11}", info.get("id", "")):
                raise ValueError("YouTube channel is not live")
            ie = YoutubeIE(ydl)
            page = ie._download_webpage("https://www.youtube.com/watch?v=" + info["id"], info["id"])
            initial = ie.extract_yt_initial_data(info["id"], page)
            cfg = ie.extract_ytcfg(info["id"], page)
            chat = initial.get("contents", {}).get("twoColumnWatchNextResults", {}).get("conversationBar", {}).get("liveChatRenderer", {})
            choices = chat.get("header", {}).get("liveChatHeaderRenderer", {}).get("viewSelector", {}).get("sortFilterSubMenuRenderer", {}).get("subMenuItems", [])
            continuation = next((c["reloadContinuationData"]["continuation"] for c in chat.get("continuations", []) if "reloadContinuationData" in c), None)
            if not continuation and choices:
                continuation = choices[-1].get("continuation", {}).get("reloadContinuationData", {}).get("continuation")
            context = cfg.get("INNERTUBE_CONTEXT")
            if not continuation or not context:
                raise ValueError("YouTube live chat is unavailable")
            # A reload token opens the chat page; its timed token is used for API polling.
            chat_page = ie._download_webpage("https://www.youtube.com/live_chat?continuation=" + quote(continuation), info["id"])
            chat_initial = ie.extract_yt_initial_data(info["id"], chat_page)
            first = chat_initial.get("continuationContents", {}).get("liveChatContinuation", {})
            self._youtube_actions(first.get("actions", []))
            first_next = next((value for c in first.get("continuations", []) for key, value in c.items()
                               if key in ("timedContinuationData", "invalidationContinuationData")), {})
            continuation = first_next.get("continuation")
            if not continuation:
                raise ValueError("YouTube live chat is unavailable")
            while continuation and not self.stopped():
                headers = ie.generate_api_headers(ytcfg=cfg, visitor_data=context.get("client", {}).get("visitorData"))
                headers["Content-Type"] = "application/json"
                request = Request("https://www.youtube.com/youtubei/v1/live_chat/get_live_chat?key=" + quote(cfg.get("INNERTUBE_API_KEY", "")),
                    data=json.dumps({"context": context, "continuation": continuation}).encode(),
                    headers=headers)
                with ydl.urlopen(request) as response:
                    raw = response.read(4_000_001)
                if self.stopped():
                    return
                if len(raw) > 4_000_000:
                    raise ValueError("Oversized YouTube chat response")
                data = json.loads(raw).get("continuationContents", {}).get("liveChatContinuation", {})
                if not data:
                    raise ValueError("YouTube chat ended or is unavailable")
                self.state("youtube", "connected", "Reading public live chat.")
                self._youtube_actions(data.get("actions", []))
                next_data = next((value for c in data.get("continuations", []) for key, value in c.items()
                                  if key in ("timedContinuationData", "invalidationContinuationData")), {})
                continuation = next_data.get("continuation")
                pause = max(1, min(120, float(next_data.get("timeoutMs", 5000)) / 1000))
                if self.stop_event.wait(pause):
                    return

    def _youtube_actions(self, actions):
        for action in actions:
            item = action.get("addChatItemAction", {}).get("item", {}).get("liveChatTextMessageRenderer")
            if not item:
                continue
            text = "".join(run.get("text") or (run.get("emoji", {}).get("shortcuts") or [""])[0]
                           for run in item.get("message", {}).get("runs", []))
            stamp = float(item["timestampUsec"]) / 1e6 if item.get("timestampUsec") else None
            self.add("youtube", item.get("id"), text, item.get("authorName", {}).get("simpleText", ""), stamp)

    def _kick(self, url):
        import websocket
        slug = urlparse(url).path.strip("/")
        headers = {"User-Agent": "Mozilla/5.0", "Origin": "https://kick.com", "Accept": "application/json"}
        with httpx.Client(timeout=15, headers=headers) as client:
            response = client.get("https://kick.com/api/v2/channels/" + slug)
            response.raise_for_status()
            channel = response.json()
            if not channel.get("livestream"):
                raise ValueError("Kick channel is offline")
            channel_id, room_id = int(channel["id"]), int(channel["chatroom"]["id"])
            ident = str(uuid.uuid4())
            response = client.post(f"https://web.kick.com/api/v1/realtime/channels/{channel_id}/chat/connection",
                json={"client": {"id": ident, "type": "web"}, "capabilities": {"accepted_providers": [{"provider": "centrifugo"}]}})
            response.raise_for_status()
            connections = response.json()["data"]["connections"]
            endpoint = next(c["credentials"]["url"] for c in connections if c["provider"] == "centrifugo")
            host = urlparse(endpoint)
            if host.scheme != "wss" or not re.fullmatch(r"realtime\.[a-z0-9-]+\.platform\.kick\.com", host.hostname or "") or host.port not in (None, 443) or host.username or host.password:
                raise ValueError("Unexpected Kick chat server")
            def token():
                result = client.post("https://web.kick.com/api/v1/realtime/auth/connection", json={"client_id": ident})
                result.raise_for_status()
                return result.json()["data"]["token"]
            guest = token()
            sock = websocket.create_connection(endpoint, timeout=15, origin="https://kick.com")
            if not self.attach("kick", sock):
                return
            sock.settimeout(2)
            sock.send(json.dumps({"id": 1, "connect": {"token": guest, "name": "js"}}))
            refresh_at = time.monotonic() + 2400
            request_id = 2
            while not self.stopped():
                if time.monotonic() >= refresh_at:
                    request_id += 1
                    sock.send(json.dumps({"id": request_id, "refresh": {"token": token()}}))
                    refresh_at = time.monotonic() + 2400
                try:
                    frame = sock.recv()
                except websocket.WebSocketTimeoutException:
                    continue
                if not frame:
                    return
                if len(frame) > 1_000_000:
                    raise ValueError("Oversized chat frame")
                for line in frame.splitlines():
                    item = json.loads(line)
                    if not item:
                        sock.send("{}")
                    elif item.get("error") or item.get("push", {}).get("disconnect") or item.get("push", {}).get("unsubscribe"):
                        raise ValueError("Chat connection ended")
                    elif item.get("id") == 1 and "connect" in item:
                        sock.send(json.dumps({"id": 2, "subscribe": {"channel": f"chatrooms.{room_id}.v2"}}))
                    elif item.get("id") == 2 and "subscribe" in item:
                        self.state("kick", "connected", "Reading public live chat (unofficial website connector).")
                    else:
                        payload = item.get("push", {}).get("pub", {}).get("data", {})
                        if isinstance(payload, str):
                            payload = json.loads(payload)
                        if payload.get("event") == "App\\Events\\StopStreamBroadcast":
                            raise ValueError("Kick stream ended")
                        if payload.get("event") not in ("App\\Events\\ChatMessageEvent", "App\\Events\\ChatMessageSentEvent"):
                            continue
                        data = payload.get("data", {})
                        if isinstance(data, str):
                            data = json.loads(data)
                        stamp = datetime.fromisoformat(data["created_at"].replace("Z", "+00:00")).timestamp() if data.get("created_at") else None
                        self.add("kick", data.get("id"), data.get("content", ""), (data.get("sender") or {}).get("username", ""), stamp)
