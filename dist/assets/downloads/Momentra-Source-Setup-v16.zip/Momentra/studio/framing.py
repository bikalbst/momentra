"""Bounded local face/panel suggestions. No identity recognition or remote video calls."""
import hashlib
import math
from pathlib import Path
import threading
import time

import numpy as np

from . import editor, lifecycle, media
from .framing_visual import visual_candidates

MODEL = Path(__file__).resolve().parent / "vision-assets" / "face_detection_yunet_2023mar.onnx"
MODEL_SHA256 = "8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4"
MAX_FRAMES = 9
MAX_SECONDS = 180
TIMEOUT = 25
_slots = threading.BoundedSemaphore(1)
_cache = {}
_cache_lock = threading.Lock()


def available():
    try:
        import cv2
        return MODEL.is_file() and hasattr(cv2, "FaceDetectorYN") and hashlib.sha256(MODEL.read_bytes()).hexdigest() == MODEL_SHA256
    except (ImportError, OSError):
        return False


def _box(x, y, width, height):
    width, height = max(.05, min(1., width)), max(.05, min(1., height))
    return (max(0., min(1. - width, x)), max(0., min(1. - height, y)), width, height)


def _iou(a, b):
    left, top = max(a[0], b[0]), max(a[1], b[1])
    right, bottom = min(a[0] + a[2], b[0] + b[2]), min(a[1] + a[3], b[1] + b[3])
    intersection = max(0., right - left) * max(0., bottom - top)
    return intersection / max(1e-8, a[2] * a[3] + b[2] * b[3] - intersection)


def _contains(panel, face):
    cx, cy = face[0] + face[2] / 2, face[1] + face[3] / 2
    return panel[0] <= cx <= panel[0] + panel[2] and panel[1] <= cy <= panel[1] + panel[3]


def panels(frame):
    """Find strong sustained borders, not faces or people, in a source frame."""
    import cv2
    h, w = frame.shape[:2]
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 60, 150)
    result = []
    contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    for contour in sorted(contours, key=cv2.contourArea, reverse=True)[:100]:
        perimeter = cv2.arcLength(contour, True)
        polygon = cv2.approxPolyDP(contour, .025 * perimeter, True)
        if len(polygon) != 4 or not cv2.isContourConvex(polygon):
            continue
        x, y, rw, rh = cv2.boundingRect(polygon)
        area = rw * rh / (w * h)
        if not .015 <= area <= .92 or rw < w * .08 or rh < h * .08:
            continue
        if cv2.contourArea(polygon) / max(1, rw * rh) < .8:
            continue
        box = _box(x / w, y / h, rw / w, rh / h)
        if not any(_iou(box, other) > .85 for other in result):
            result.append(box)
    # Conversation grids often meet at a seam and have no closed outer border.
    for axis in (0, 1):
        length = h if axis == 0 else w
        projection = np.mean(edges > 0, axis=1 if axis == 0 else 0)
        lo, hi = int(length * .25), int(length * .75)
        if hi <= lo:
            continue
        position = lo + int(np.argmax(projection[lo:hi]))
        if projection[position] < .5:
            continue
        ratio = position / length
        pair = [(0., 0., 1., ratio), (0., ratio, 1., 1. - ratio)] if axis == 0 else [(0., 0., ratio, 1.), (ratio, 0., 1. - ratio, 1.)]
        result.extend(pair)
    return result[:24]


def detect(frame, detector):
    h, w = frame.shape[:2]
    detector.setInputSize((w, h))
    _, found = detector.detect(frame)
    faces = []
    for row in found if found is not None else []:
        x, y, rw, rh = [float(v) for v in row[:4]]
        confidence = float(row[-1])
        if confidence >= .8 and rw >= 8 and rh >= 8:
            faces.append({"box": _box(x / w, y / h, rw / w, rh / h), "confidence": confidence})
    return {"faces": faces, "panels": panels(frame)}


def _tracks(samples):
    tracks = []
    for sample in samples:
        used = set()
        for face in sorted(sample["faces"], key=lambda f: -f["confidence"])[:12]:
            choices = [(i, _iou(face["box"], track["boxes"][-1])) for i, track in enumerate(tracks) if i not in used]
            index, score = max(choices, key=lambda x: x[1], default=(-1, 0))
            if score < .15:
                tracks.append({"boxes": [], "scores": [], "panels": []})
                index = len(tracks) - 1
            track = tracks[index]
            track["boxes"].append(face["box"])
            track["scores"].append(face["confidence"])
            choices = [panel for panel in sample["panels"] if _contains(panel, face["box"]) and panel[2] * panel[3] >= face["box"][2] * face["box"][3] * 1.3]
            if choices:
                track["panels"].append(min(choices, key=lambda b: b[2] * b[3]))
            used.add(index)
    return sorted(tracks, key=lambda t: (-len(t["boxes"]), -float(np.mean(t["scores"]))))


def _median(boxes):
    return _box(*[float(value) for value in np.median(np.array(boxes), axis=0)])


def _person_crop(face, source_aspect, output_aspect):
    x, y, w, h = face
    crop_h = min(1., max(h * 3.6, .28))
    crop_w = crop_h * output_aspect / source_aspect
    if crop_w > 1.:
        crop_w, crop_h = 1., source_aspect / output_aspect
    crop_w = max(w * 2.2, crop_w)
    crop_h = max(h * 2.8, crop_h)
    return _box(x + w / 2 - crop_w / 2, y + h * .8 - crop_h * .36, crop_w, crop_h)


def _fields(prefix, box):
    return {prefix + "_" + key: round(value * 100, 3) for key, value in zip(("x", "y", "w", "h"), box)}


def propose(samples, mode, width, height):
    tracks = _tracks(samples)
    stable = [t for t in tracks if len(t["boxes"]) >= max(2, math.ceil(len(samples) * .45))]
    result = {"available": True, "mode": mode, "suggestion": None, "confidence": "low", "sample_count": len(samples),
              "method": "Local YuNet faces + panel borders; stable crop, not identity recognition or dynamic tracking."}
    if not stable:
        return {**result, "message": "No face stayed confidently visible across enough samples. Keep your manual crop."}
    aspect = width / height
    if mode == "two_person":
        if len(stable) < 2:
            return {**result, "message": "Two stable people or conversation panels were not found. Set the two crops manually."}
        first, second = stable[:2]
        a, b = _median(first["boxes"]), _median(second["boxes"])
        if _iou(a, b) > .15:
            return {**result, "message": "The face regions are ambiguous. Keep your manual crops."}
        ca = _median(first["panels"]) if len(first["panels"]) >= len(first["boxes"]) * .5 else _person_crop(a, aspect, 1080 / 960)
        cb = _median(second["panels"]) if len(second["panels"]) >= len(second["boxes"]) * .5 else _person_crop(b, aspect, 1080 / 960)
        if _iou(ca, cb) > .45:
            ca, cb = _person_crop(a, aspect, 1080 / 960), _person_crop(b, aspect, 1080 / 960)
        regions = sorted((ca, cb), key=lambda p: (round(p[1], 1), p[0]))
        suggestion = {"layout": "two_person", **_fields("face", regions[0]), **_fields("game", regions[1])}
        panel_found = len(first["panels"]) >= len(first["boxes"]) * .5 and len(second["panels"]) >= len(second["boxes"]) * .5
        return {**result, "suggestion": suggestion, "confidence": "high" if panel_found else "medium",
                "message": "Two stable regions proposed at exact 50:50. Review faces and panel edges, then Apply; you can swap the panels."}
    track = stable[0]
    face = _median(track["boxes"])
    if mode == "portrait":
        crop = _person_crop(face, aspect, 9 / 16)
        return {**result, "suggestion": {"layout": "portrait", **_fields("face", crop)}, "confidence": "medium",
                "message": "A stable person crop is proposed. Review headroom and movement before applying."}
    camera = _median(track["panels"]) if len(track["panels"]) >= len(track["boxes"]) * .5 else None
    if camera is None or camera[2] * camera[3] > .5:
        return {**result, "message": "A face was detected, but its camera-panel boundary is uncertain. Choose the camera rectangle manually."}
    # Prefer a large non-camera panel; full source is an honest fallback for gameplay.
    gameplay = [p for sample in samples for p in sample["panels"] if p[2] * p[3] > .3 and _iou(p, camera) < .05]
    game = max(gameplay, key=lambda p: p[2] * p[3]) if gameplay else (0., 0., 1., 1.)
    return {**result, "suggestion": {"layout": mode, **_fields("face", camera), **_fields("game", game)}, "confidence": "medium",
            "message": "Camera panel proposed. Gameplay uses a separate panel when detected, otherwise the full source. Review before applying."}


def analyze(job, clip, mode="facecam_top", start=None, end=None):
    if mode not in ("facecam_top", "facecam_bottom", "two_person", "portrait"):
        raise ValueError("Choose facecam top, facecam bottom, two people or portrait.")
    lifecycle.require_accepting()
    a, b = editor.cut(job, clip, {"start": clip["start"] if start is None else start, "end": clip["end"] if end is None else end})
    if b - a > MAX_SECONDS:
        raise ValueError("Auto frame up to 180 seconds at once.")
    source, offset = editor.source(job, clip)
    if not available():
        return {"available": False, "suggestion": None, "message": "The local face detector is unavailable. Use manual crops."}
    if not _slots.acquire(blocking=False):
        return {"available": True, "suggestion": None, "message": "Auto framing is busy. Try again in a moment."}
    try:
        import cv2
        stat = source.stat()
        key = (str(source), stat.st_size, stat.st_mtime_ns, a, b, mode, editor.revision(clip), clip.get("version", 0))
        with _cache_lock:
            if key in _cache:
                return _cache[key]
        meta = media.inspect_export(source, timeout=8)
        w, h = meta["width"], meta["height"]
        if w <= 0 or h <= 0:
            raise ValueError("The original video dimensions are unavailable.")
        scale = min(1., 640 / max(w, h))
        sw, sh = max(2, int(w * scale) // 2 * 2), max(2, int(h * scale) // 2 * 2)
        detector = cv2.FaceDetectorYN.create(str(MODEL), "", (sw, sh), .8, .3, 100)
        deadline = time.monotonic() + TIMEOUT
        samples = []
        for timestamp in np.linspace(a + min(.1, (b - a) / 10), b - min(.1, (b - a) / 10), MAX_FRAMES):
            if time.monotonic() >= deadline or not lifecycle.accepting():
                break
            command = ["ffmpeg", "-nostdin", "-v", "error", "-ss", str(max(0., timestamp - offset)), "-i", str(source),
                       "-frames:v", "1", "-vf", f"scale={sw}:{sh}", "-f", "rawvideo", "-pix_fmt", "bgr24", "pipe:1"]
            process = lifecycle.run_process(command, capture_output=True, timeout=max(.1, min(6, deadline - time.monotonic())), creationflags=media.NO_WINDOW)
            if process.returncode or len(process.stdout) != sw * sh * 3:
                continue
            frame = np.frombuffer(process.stdout, dtype=np.uint8).reshape(sh, sw, 3)
            samples.append(detect(frame, detector))
        report = propose(samples, mode, w, h) if len(samples) >= 2 else {"available": True, "suggestion": None, "message": "Too few frames could be analyzed. Use manual crops."}
        report.update(start=a, end=b, editor_revision=editor.revision(clip), version=clip.get("version", 0))
        with _cache_lock:
            if len(_cache) >= 32:
                _cache.clear()
            _cache[key] = report
        return report
    finally:
        _slots.release()
