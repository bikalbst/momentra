"""Checks a finished export before it enters the posting queue."""
import math
import threading
from pathlib import Path

from . import accounts, ctx, media

_cache = {}
_lock = threading.RLock()


class Blocked(ValueError):
    def __init__(self, report):
        self.report = report
        super().__init__(next((c["message"] for c in report["checks"] if c["status"] == "blocked"),
                              "Check this clip before posting it."))


def export_path(job, clip):
    root = (Path(job["dir"]) / "clips").resolve()
    name = str(clip.get("file") or "")
    if not name or Path(name).name != name or "/" in name or "\\" in name:
        raise ValueError("The export file name is not valid. Re-make the clip.")
    path = (root / name).resolve()
    if not path.is_relative_to(root):
        raise ValueError("The export file is outside this video's folder.")
    return path


def _inspect(path, version):
    st = path.stat()
    key = (str(path), version, st.st_size, st.st_mtime_ns)
    with _lock:
        if key in _cache:
            return _cache[key]
    result = media.inspect_export(path, timeout=12)
    with _lock:
        if len(_cache) >= 256:
            _cache.clear()
        _cache[key] = result
    return result


def check(job, clip, account_ids=None, expected_version=None, path=None):
    checks = []
    timing = {"expected_duration": None, "duration": None, "video_start": None, "audio_start": None,
              "video_duration": None, "audio_duration": None, "av_offset": None}

    def note(code, status, message):
        checks.append({"code": code, "status": status, "message": message})

    version = clip.get("version", 0)
    if job.get("user") != ctx.uid():
        note("owner", "blocked", "This clip does not belong to this workspace.")
    elif clip.get("status") != "done":
        note("ready", "blocked", "Wait for this clip to finish rendering before posting it.")
    else:
        note("ready", "pass", "The clip has finished rendering.")
    if expected_version is not None and version != expected_version:
        note("version", "blocked", "This clip changed after it was queued. Review it and retry to approve the new export.")
    if clip.get("editor_revision", 0) != clip.get("editor_rendered_revision", 0):
        note("draft", "blocked", "The latest edits have not finished rendering.")
    else:
        note("draft", "pass", "The export matches the saved edits.")
    try:
        start, end = float(clip["start"]), float(clip["end"])
        valid = math.isfinite(start) and math.isfinite(end) and start >= 0 and 3 <= end - start <= 180
        if not valid:
            raise ValueError()
        expected_duration = end - start
        timing["expected_duration"] = expected_duration
        note("cut", "pass", f"The saved cut is {expected_duration:.2f} seconds long.")
    except (KeyError, ValueError, TypeError, OverflowError):
        expected_duration = None
        note("cut", "blocked", "The saved clip times are not valid. Re-make the clip.")

    if account_ids is not None:
        if not account_ids:
            note("accounts", "blocked", "Choose at least one connected account.")
        for aid in dict.fromkeys(account_ids):
            acc = accounts.get(aid)
            if not acc or acc.get("platform") not in accounts.PLATFORM_NAMES:
                note("account", "blocked", "A selected account was disconnected or is not supported.")
            elif acc.get("needs_reconnect"):
                note("account", "blocked", f"Connect {acc['name']} again before retrying this post.")
            else:
                note("account", "pass", f"{acc['name']} is connected. The platform may still require renewed permission.")

    try:
        file = Path(path) if path is not None else export_path(job, clip)
        if not file.is_file() or file.stat().st_size == 0:
            raise ValueError("The export is missing or empty. Re-make the clip.")
        note("file", "pass", "The export file is present and nonempty.")
    except (OSError, ValueError) as exc:
        file = None
        note("file", "blocked", str(exc) if isinstance(exc, ValueError) else "The export file could not be opened.")

    if file is not None:
        try:
            info = _inspect(file, version)
        except (OSError, ValueError, RuntimeError, TypeError, KeyError):
            note("media", "blocked", "The export could not be read by the video tools. Re-make it or check FFprobe in Settings.")
        else:
            if not info["has_video"]:
                note("video", "blocked", "The export has no video track.")
            else:
                note("video", "pass", "The export has a video track.")
            if not info["has_audio"]:
                note("audio", "blocked", "The export has no audio track. Re-make it before posting.")
            else:
                note("audio", "pass", "The export has an audio track; this does not prove speech is audible.")
            duration = info["duration"]
            timing["duration"] = duration if math.isfinite(duration) else None
            if not math.isfinite(duration) or duration <= 0:
                note("duration", "blocked", "The export does not have a valid duration.")
            elif expected_duration is not None and abs(duration - expected_duration) > max(.6, expected_duration * .03):
                note("duration", "blocked", f"The saved cut is {expected_duration:.2f}s, but the export is {duration:.2f}s. Repair export timing or re-make the clip.")
            else:
                note("duration", "pass", "The export duration matches the saved cut.")
            for key in ("video_start", "audio_start", "video_duration", "audio_duration"):
                value = info.get(key)
                timing[key] = value if isinstance(value, (int, float)) and math.isfinite(value) else None
            vs, ast = timing["video_start"], timing["audio_start"]
            if vs is not None and ast is not None:
                timing["av_offset"] = ast - vs
                note("starts", "blocked" if max(abs(vs), abs(ast)) > .12 else "pass",
                     f"Video starts at {vs:.3f}s and audio at {ast:.3f}s; export tracks should start near zero.")
                note("timing", "blocked" if abs(ast - vs) > .12 else "pass",
                     f"Audio starts {abs(ast - vs):.3f}s {'after' if ast >= vs else 'before'} video. "
                     + ("Repair the export timing before posting." if abs(ast - vs) > .12 else "The track starts are aligned."))
            elif info["has_video"] and info["has_audio"]:
                note("starts", "unknown", "The video tools did not report both track start times. Review playback timing yourself.")
            stream_durations = [timing[k] for k in ("video_duration", "audio_duration") if timing[k] is not None]
            if expected_duration is not None and any(d <= 0 or abs(d - expected_duration) > max(.6, expected_duration * .03) for d in stream_durations):
                detail = ", ".join(f"{label} {timing[key]:.2f}s" for label, key in (("video", "video_duration"), ("audio", "audio_duration")) if timing[key] is not None)
                note("timing", "blocked", f"Expected both tracks to last {expected_duration:.2f}s; measured {detail}. Repair export timing or re-make the clip.")
            width, height = info["width"], info["height"]
            if width <= 0 or height <= 0:
                note("dimensions", "blocked", "The export dimensions are not valid.")
            elif abs(width / height - 9 / 16) > .02:
                note("dimensions", "warning", f"The export is {width} × {height}, not the usual vertical 9:16 format.")
            else:
                note("dimensions", "pass", f"Vertical export: {width} × {height}.")
            if width > 0 and width < 720:
                note("resolution", "warning", "This export is below 720 pixels wide and may look soft.")
            if info["video_codec"] != "h264" or (info["has_audio"] and info["audio_codec"] != "aac"):
                note("codecs", "warning", "H.264 video with AAC audio is the safest format for these platforms.")
            else:
                note("codecs", "pass", "H.264 video and AAC audio.")

    words = clip.get("rendered_words", clip.get("fixed_words"))
    if not words:
        note("captions", "warning", "No saved caption words were found. Review the video if captions are expected.")
    else:
        valid = isinstance(words, list)
        previous = -math.inf
        for word in words if valid else []:
            try:
                start, end = float(word["s"]), float(word["e"])
                if not isinstance(word.get("w"), str) or not math.isfinite(start) or not math.isfinite(end) or start < previous or end <= start:
                    valid = False
                    break
                previous = start
            except (KeyError, TypeError, ValueError, OverflowError):
                valid = False
                break
        note("captions", "pass" if valid else "warning",
             "Saved caption timing is well formed. Review spelling and placement in the video."
             if valid else "Some saved caption timing is unusual. Review the rendered captions.")
    note("human_review", "unknown", "Caption accuracy, framing, platform safe zones and content rights still need your review.")
    status = "blocked" if any(c["status"] == "blocked" for c in checks) else "warning" if any(c["status"] == "warning" for c in checks) else "pass"
    from . import repair
    timing_blocked = any(c["status"] == "blocked" and c["code"] in repair.TIMING_CODES for c in checks)
    return {"version": version, "editor_revision": clip.get("editor_revision", 0), "status": status,
            "can_post": status != "blocked", "checks": checks, "timing": timing,
            "timing_blocked": timing_blocked, "can_repair": timing_blocked and repair.available(job, clip),
            "posting_paused": accounts.settings()["paused"]}


def require(job, clip, account_ids=None, expected_version=None, path=None):
    report = check(job, clip, account_ids, expected_version, path)
    if not report["can_post"]:
        raise Blocked(report)
    return report
