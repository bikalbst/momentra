"""Sparse local frame changes for candidate review, without highlight claims."""
import math
from pathlib import Path
import time

import numpy as np

from . import lifecycle, media


def visual_candidates(path, start, end, min_len=15, max_len=60, limit=8):
    """Sparse motion/scene signals for human review, not judgments of highlight quality."""
    if not Path(path).is_file() or not lifecycle.accepting() or int(limit) <= 0:
        return []
    start, end = float(start), float(end)
    if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end <= start:
        return []
    count = min(36, max(3, int((end - start) / 10)))
    deadline, previous, signals = time.monotonic() + 20, None, []
    for timestamp in np.linspace(start, max(start, end - .1), count):
        if time.monotonic() >= deadline or not lifecycle.accepting():
            break
        try:
            process = lifecycle.run_process(["ffmpeg", "-nostdin", "-v", "error", "-ss", str(timestamp), "-i", str(path),
                         "-frames:v", "1", "-vf", "scale=160:90", "-f", "rawvideo", "-pix_fmt", "gray", "pipe:1"],
                         capture_output=True, timeout=max(.1, min(4, deadline - time.monotonic())), creationflags=media.NO_WINDOW)
        except Exception:
            continue
        if process.returncode or len(process.stdout) != 160 * 90:
            continue
        frame = np.frombuffer(process.stdout, dtype=np.uint8).astype(np.float32)
        if previous is not None:
            movement = float(np.mean(np.abs(frame - previous)) / 255)
            if movement > .07:
                signals.append((movement, float(timestamp)))
        previous = frame
    length = max(3, min(max_len, max(min_len, 15), end - start))
    found = []
    for movement, timestamp in sorted(signals, reverse=True):
        a = max(start, min(timestamp - length / 3, end - length))
        b = min(end, a + length)
        if b - a < 3 or any(min(b, c["end"]) - max(a, c["start"]) > length * .3 for c in found):
            continue
        found.append({"start": round(a, 2), "end": round(b, 2), "score": round(min(100, movement * 200)), "kind": "motion",
                      "reason": "Sparse local frame-change signal. Review manually; this does not recognize a joke, reaction or successful play."})
        if len(found) >= min(8, max(0, int(limit))):
            break
    return found
