"""Private, source-clock caption drafts and bounded local editor previews. No AI calls here."""
import array
import hashlib
import json
import math
import subprocess
import sys
import threading
from pathlib import Path

from . import lifecycle, media, roman

MIN_CUT = 3
MAX_CUT = 180
MAX_WINDOW = 240
MAX_WORDS = 3000
WAVE_TIMEOUT = 12
_wave_slots = threading.BoundedSemaphore(2)
PRIVATE_FIELDS = ("manual_words", "editor_words", "editor_coverage", "rendered_words", "rendered_cut")


class Conflict(ValueError):
    """The page is editing an older version of the clip."""


def number(value, label="Time"):
    try:
        valid = not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)
    except OverflowError:
        valid = False
    if not valid:
        raise ValueError(f"{label} must be a finite number.")
    return float(value)


def revision(clip):
    return int(clip.get("editor_revision", 0))


def check_revision(clip, changes):
    expected = changes.get("editor_revision")
    if expected is None:
        if "caption_edits" in changes or "captions_reset" in changes:
            raise ValueError("Open the caption editor again before saving these captions.")
        return                         # older pages can still save styles and crops
    if isinstance(expected, bool) or not isinstance(expected, int) or expected < 0:
        raise ValueError("The caption editor version isn't valid.")
    if expected != revision(clip):
        raise Conflict("This clip changed elsewhere. Reopen it before saving your changes.")


def bounds(job, clip):
    if clip.get("src"):
        lo = number(clip.get("src_offset", 0))
        hi = number(clip.get("src_end"))
    else:
        lo, hi = 0.0, number(job.get("duration"))
    if lo < 0 or hi <= lo:
        raise ValueError("The original video's available times are unknown.")
    return lo, hi


def cut(job, clip, changes=None, clamp=False):
    changes = changes or {}
    start = number(changes.get("start", clip["start"]))
    end = number(changes.get("end", clip["end"]))
    # Check order before any clamp: a backwards cut must never silently become valid.
    if start < 0 or end <= start:
        raise ValueError("The end of the clip must be after its start.")
    if not MIN_CUT <= end - start <= MAX_CUT:
        raise ValueError("A clip can be 3 to 180 seconds long.")
    lo, hi = bounds(job, clip)
    if clamp:
        start, end = max(lo, start), min(hi, end)
    elif start < lo or end > hi:
        raise ValueError("Choose times inside the available original video.")
    start, end = round(start, 2), round(end, 2)
    if start < lo - .005 or end > hi + .005 or not MIN_CUT <= round(end - start, 2) <= MAX_CUT:
        raise ValueError("The available part must make a clip 3 to 180 seconds long.")
    return start, end


def window(job, clip, start=None, end=None):
    lo, hi = bounds(job, clip)
    if start is None and end is None:
        start, end = max(lo, clip["start"] - 15), min(hi, clip["end"] + 15)
    else:
        start, end = number(start), number(end)
    if not lo <= start < end <= hi or end - start > MAX_WINDOW:
        raise ValueError("Preview up to 240 seconds inside the available original video.")
    return float(start), float(end)


def source(job, clip):
    value = clip.get("src") or job.get("source_path")
    if not value or not Path(value).is_file():
        raise FileNotFoundError("The original video is no longer available.")
    return Path(value), number(clip.get("src_offset", 0)) if clip.get("src") else 0.0


def identify(clip, words, transliterate=False):
    """IDs describe original word identity, not its edited text or timing."""
    out, counts = [], {}
    for word in words or []:
        if not isinstance(word, dict):
            continue
        try:
            start, end = number(word["s"]), number(word["e"])
            text = word["w"]
            if not isinstance(text, str) or start < 0 or end < start:
                continue
        except (KeyError, ValueError, TypeError):
            continue
        if transliterate:
            text = roman.to_roman(text)
        key = f"{start:.6f}:{end:.6f}:{roman.to_roman(text)}"
        count = counts.get(key, 0)
        counts[key] = count + 1
        wid = word.get("id") or "w-" + hashlib.sha256(f"{clip['id']}:{key}:{count}".encode()).hexdigest()[:20]
        if not isinstance(wid, str):
            continue
        out.append({"id": wid, "w": text, "s": start, "e": end})
    return sorted(out, key=lambda w: (w["s"], w["e"], w["id"]))


def base_words(clip, transcript=None):
    base = identify(clip, clip.get("editor_words") or clip.get("fixed_words") or [], transliterate=True)
    covered = clip.get("editor_coverage") or ([clip.get("fixed_for", [])[:2]] if clip.get("fixed_for") else [])
    if not base:
        return identify(clip, transcript or [], transliterate=True)
    ids = {w["id"] for w in base}
    for word in identify(clip, transcript or [], transliterate=True):
        if word["id"] not in ids and not any(len(span) == 2 and span[0] <= word["s"] <= span[1] for span in covered):
            base.append(word)
    return sorted(base, key=lambda w: (w["s"], w["e"], w["id"]))


def apply_manual(clip, words):
    manual = clip.get("manual_words") or {}
    return [dict(w, **manual.get(w["id"], {})) for w in words]


def read_words(job):
    f = Path(job["dir"]) / "words.json"
    if not f.is_file():
        return []
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            raise ValueError()
        return data
    except (ValueError, OSError):
        raise ValueError("The saved captions could not be read. Try again after the video finishes.") from None


def read_window(job, clip, start, end):
    """Read only word identity/timing, then keep a candidate window, never expose a full transcript."""
    return [w for w in identify(clip, read_words(job), transliterate=True) if start <= w["s"] <= end]


def prepare_captions(job, clip, changes):
    reset = changes.get("captions_reset", False)
    if not isinstance(reset, bool):
        raise ValueError("Caption reset must be true or false.")
    edits = changes.get("caption_edits", [])
    if not isinstance(edits, list) or len(edits) > MAX_WORDS:
        raise ValueError("Send up to 3000 caption word changes at a time.")
    if reset and edits:
        raise ValueError("Reset captions or edit words, not both at once.")
    if "caption_edits" not in changes and not reset:
        return {}
    a, b = window(job, clip)
    transcript = identify(clip, read_words(job), transliterate=True)
    base = base_words(clip, [w for w in transcript if a <= w["s"] <= b])
    # Words in another explicitly loaded candidate window can be edited in the same request.
    requested = {e.get("id") for e in edits if isinstance(e, dict) and isinstance(e.get("id"), str)}
    known = {w["id"] for w in base}
    for i, word in enumerate(transcript):
        if word["id"] in requested and word["id"] not in known:
            for neighbour in transcript[max(0, i - 1):i + 2]:
                if neighbour["id"] not in known:
                    base.append(neighbour)
                    known.add(neighbour["id"])
    base.sort(key=lambda w: (w["s"], w["e"], w["id"]))
    by_id = {w["id"]: w for w in base}
    manual = {} if reset else dict(clip.get("manual_words") or {})
    seen = set()
    lo, hi = bounds(job, clip)
    for edit in edits:
        if not isinstance(edit, dict) or set(edit) - {"id", "text", "start", "end"}:
            raise ValueError("That caption word change isn't valid.")
        wid = edit.get("id")
        if not isinstance(wid, str) or wid not in by_id or wid in seen:
            raise ValueError("That caption word is missing or repeated. Reopen the editor.")
        if not any(k in edit for k in ("text", "start", "end")):
            raise ValueError("Choose a caption word change.")
        seen.add(wid)
        word = dict(by_id[wid], **manual.get(wid, {}))
        if "text" in edit:
            text = edit["text"]
            if not isinstance(text, str) or len(text) > 200 or any(ord(ch) < 32 for ch in text):
                raise ValueError("A caption word can have up to 200 characters, without line breaks.")
            word["w"] = text.strip()          # empty text explicitly hides this word; no translation
        for key, internal in (("start", "s"), ("end", "e")):
            if key in edit:
                word[internal] = round(number(edit[key], "Word time"), 3)
        if not lo <= word["s"] < word["e"] <= hi:
            raise ValueError("Each word must end after it starts, inside the available video.")
        manual[wid] = {k: word[k] for k in ("w", "s", "e")}
    effective = [dict(w, **manual.get(w["id"], {})) for w in base]
    # Original transcripts may overlap; only newly edited timings need an ordered, non-overlapping slot.
    time_edits = {e.get("id") for e in edits if isinstance(e, dict) and any(k in e for k in ("start", "end")) and isinstance(e.get("id"), str)}
    for i, word in enumerate(effective):
        if word["id"] not in time_edits:
            continue
        if (i and word["s"] < effective[i - 1]["e"] - .001) or (i + 1 < len(effective) and word["e"] > effective[i + 1]["s"] + .001):
            raise ValueError("Word times must stay ordered and must not overlap the next word.")
    return {"manual_words": manual, "editor_words": base}


def view(job, clip, start=None, end=None):
    a, b = window(job, clip, start, end)
    lo, hi = bounds(job, clip)
    base = base_words(clip, read_window(job, clip, a, b))
    effective = apply_manual(clip, base)
    originals = {w["id"]: w for w in base}
    words = [w for w in effective if a <= w["s"] < b]
    truncated = len(words) > MAX_WORDS
    words = [{"id": w["id"], "text": w["w"], "start": w["s"], "end": w["e"],
              "original_text": originals[w["id"]]["w"], "original_start": originals[w["id"]]["s"], "original_end": originals[w["id"]]["e"]}
             for w in words[:MAX_WORDS]]
    try:
        _, offset = source(job, clip)
        available = True
    except FileNotFoundError:
        available, offset = False, lo
    prefix = f"/api/jobs/{job['id']}/clips/{clip['id']}/editor"
    return {"editor_revision": revision(clip), "editor_rendered_revision": int(clip.get("editor_rendered_revision", 0)),
            "version": clip.get("version", 0), "words": words, "words_truncated": truncated,
            "manual_captions": bool(clip.get("manual_words")), "cut": {"start": clip["start"], "end": clip["end"]},
            "rendered_cut": clip.get("rendered_cut", {"start": clip["start"], "end": clip["end"]}),
            "bounds": {"start": lo, "end": hi}, "window": {"start": a, "end": b},
            "source": {"available": available, "url": prefix + "/source" if available else None, "offset": offset,
                       "compatible_preview_url": prefix + "/source-preview" if available else None},
            "waveform_url": prefix + "/waveform"}


def waveform(job, clip, start=None, end=None):
    a, b = window(job, clip, start, end)
    out = {"start": a, "end": b, "peaks": [], "available": False}
    if not _wave_slots.acquire(blocking=False):
        return {**out, "reason": "The audio preview is busy. Try again in a moment."}
    try:
        src, offset = source(job, clip)
        command = ["ffmpeg", "-nostdin", "-v", "error", "-ss", str(max(0, a - offset)), "-i", str(src),
                   "-t", str(b - a), "-vn", "-ac", "1", "-ar", "1000", "-f", "s16le", "pipe:1"]
        process = lifecycle.run_process(command, capture_output=True, timeout=WAVE_TIMEOUT, creationflags=media.NO_WINDOW)
        if process.returncode or not process.stdout:
            return {**out, "reason": "No audio waveform is available. Use the video and precise times instead."}
        samples = array.array("h")
        samples.frombytes(process.stdout[:int(MAX_WINDOW * 1000) * 2 // 2 * 2])
        if sys.byteorder != "little":
            samples.byteswap()
        count = min(600, max(1, int((b - a) * 8)))
        peaks = []
        for i in range(count):
            values = samples[len(samples) * i // count:len(samples) * (i + 1) // count]
            peaks.append(round(max((abs(n) for n in values), default=0) / 32768, 4))
        return {**out, "available": True, "peaks": peaks}
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
        return {**out, "reason": "The audio preview could not be read in time. Use the video and precise times instead."}
    finally:
        _wave_slots.release()
