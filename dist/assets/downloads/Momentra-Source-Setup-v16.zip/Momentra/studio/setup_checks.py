"""Read-only setup checks and a bounded, cached connectivity probe."""
import importlib.metadata
import shutil
import sys
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from . import accounts, ai, config, fetch_model, media, tools

_connection_lock = threading.Lock()
_connection = {}


def _reachable(url):
    try:
        request = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "Momentra connection check"})
        with urllib.request.urlopen(request, timeout=3) as response:
            return response.status == 204
    except Exception:
        return False


def connection(refresh=False):
    # Fixed destinations only. No videos, account data or credentials are sent.
    with _connection_lock:
        age = time.time() - _connection.get("checked_at", 0)
        if _connection and age < (5 if refresh else 30):
            return dict(_connection)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(_reachable, ("https://www.google.com/generate_204", "https://cp.cloudflare.com/generate_204")))
        online = any(results)
        _connection.update(online=online, checked_at=time.time(),
                           message="Internet reachable" if online else "No internet detected. A firewall or network restriction can also block this check.")
        return dict(_connection)


def _version(package):
    try:
        return importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:
        return ""


def report():
    bundled = bool(getattr(sys, "frozen", False))
    rows = []

    def row(ident, label, ready, detail, command="", optional=False, action=""):
        rows.append(dict(id=ident, label=label, ready=ready, detail=detail,
                         command=command if not ready else "", optional=optional, action=action,
                         status=("Configured" if ident == "ai" else "Connected" if ident == "youtube" else "Setup") if ready else "Optional" if optional else "Needs setup"))

    row("python", "Python runtime", True, ("Bundled · " if bundled else "Installed · ") + sys.version.split()[0])
    tools.setup()
    for name in tools.NEEDED:
        try:
            version = media.run([name, "-version"], timeout=5).splitlines()[0].split(" Copyright")[0][:140]
            row(name, "FFmpeg" if name == "ffmpeg" else "FFprobe", True, ("Bundled · " if bundled else "Installed · ") + version)
        except Exception:
            command = "winget install Gyan.FFmpeg" if sys.platform == "win32" else "brew install ffmpeg" if sys.platform == "darwin" else "sudo apt install ffmpeg"
            row(name, name, False, "Video tools could not start.", command)
    ready = fetch_model.ready()
    row("model", "Speech model", ready, ("Bundled · Ready for local transcription" if bundled else "Ready for local transcription") if ready else "The complete speech model was not found.",
        "" if bundled else "python -m studio.fetch_model")
    for ident, label, package in (("speech", "Speech engine", "sherpa-onnx"), ("downloader", "Video downloader", "yt-dlp")):
        version = _version(package)
        row(ident, label, bool(version), ("Bundled · " if bundled else "Installed · ") + version if version else "Package missing. Download a fresh Momentra build." if bundled else "Package missing.",
            "" if bundled else "python -m pip install -r requirements.txt")
    browser = config.env("MOMENTRA_INTERFACE") == "browser" or not bundled
    row("webview", "Desktop WebView", True, "Not required for the browser version" if browser else "Available · this desktop window is running", optional=True)
    available = shutil.disk_usage(config.DATA_DIR).free
    row("storage", "Working storage", available >= 2 * 1024**3, f"{available / 1024**3:.1f} GB free. Allow space for source videos and exports.")
    row("ai", "AI provider", ai.ready(), "Configured; this check does not send an AI request. Use AI settings to test the key." if ai.ready() else "Optional. Local clipping works without an AI key.", optional=True, action="ai")
    connected = any(a["platform"] == "youtube" for a in accounts.list_accounts())
    row("youtube", "YouTube posting", connected, "Account saved; reconnect in Connected apps if posting fails." if connected else "Optional. Connect an account to post clips.", optional=True, action="apps")
    return dict(bundled=bundled, checks=rows, checked_at=time.time())
