"""Common-clock cuts and bounded export timing checks. No independent stream-origin reset."""
import json
import math
from pathlib import Path

from . import config, lifecycle, media


def inspect(path, timeout=12):
    raw = media.run(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(path)], timeout=timeout)
    data = json.loads(raw)
    fmt = data.get("format") or {}
    streams = data.get("streams") or []
    def value(item, key):
        try:
            number = float(item[key])
            return number if math.isfinite(number) else None
        except (KeyError, TypeError, ValueError, OverflowError):
            return None
    video = next((s for s in streams if s.get("codec_type") == "video"), {})
    audio = next((s for s in streams if s.get("codec_type") == "audio"), {})
    return {"start": value(fmt, "start_time"), "duration": value(fmt, "duration"),
            "video_start": value(video, "start_time"), "audio_start": value(audio, "start_time"),
            "video_duration": value(video, "duration"), "audio_duration": value(audio, "duration"),
            "has_video": bool(video), "has_audio": bool(audio)}


def cut_filters(start, end):
    duration = end - start
    if not all(math.isfinite(float(v)) for v in (start, end)) or start < 0 or duration <= 0:
        raise ValueError("The export cut times are not valid.")
    # -copyts/-start_at_zero preserve the common input origin. Subtract the chosen cut, not each track's first frame.
    return (f"[0:v]trim=start={start:.6f}:end={end:.6f},setpts=PTS-{start:.6f}/TB[cutv];"
            f"[0:a:0]atrim=start={start:.6f}:end={end:.6f},asetpts=PTS-{start:.6f}/TB,"
            f"aresample=async=1:first_pts=0,loudnorm=I=-14:TP=-1.5:LRA=11,"
            f"aformat=sample_fmts=s16,apad=whole_dur={duration:.6f},atrim=duration={duration:.6f}[cuta];")


def validate_source_cut(path, start, end, timeout=20):
    info = inspect(path, timeout=min(12, timeout))
    if not info["has_video"] or not info["has_audio"]:
        raise ValueError("The original source needs video and audio to repair this export.")
    origin = info["start"] if info["start"] is not None else min(v for v in (info["video_start"], info["audio_start"]) if v is not None)
    audio_end = None if info["audio_start"] is None or info["audio_duration"] is None else info["audio_start"] + info["audio_duration"] - origin
    if audio_end is not None and audio_end < end - .15:
        raise ValueError("The selected source ends before the audio cut. Choose an earlier end rather than padding missing audio.")
    # An absolute end is essential: FFprobe may seek back to an earlier keyframe.
    # A relative %+length ends too early when that preroll is long.
    raw = media.run(["ffprobe", "-v", "error", "-read_intervals", f"{max(0, start - 2):.6f}%{end + origin + 1:.6f}",
                     "-select_streams", "v:0", "-show_frames", "-show_entries", "frame=best_effort_timestamp_time", "-of", "json", str(path)], timeout=timeout)
    stamps = []
    for frame in json.loads(raw).get("frames", []):
        try:
            stamp = float(frame["best_effort_timestamp_time"]) - origin
            if math.isfinite(stamp):
                stamps.append(stamp)
        except (KeyError, ValueError, TypeError):
            continue
    before = [t for t in stamps if t <= start]
    relevant = ([max(before)] if before else []) + [t for t in stamps if start < t <= end]
    if not relevant or relevant[0] > start + .12 or relevant[-1] < end - .15:
        raise ValueError("Video frames do not cover this cut. Shorten the cut or use another source; timing repair cannot restore missing footage.")
    if any(b <= a or b - a > .5 for a, b in zip(relevant, relevant[1:])):
        raise ValueError("The source has a timestamp gap inside this cut. Timing repair cannot recreate the missing video frames.")
    return info


def validate_export(path, expected, timeout=20):
    info = inspect(path, timeout=min(12, timeout))
    if not info["has_video"] or not info["has_audio"]:
        raise ValueError("The export must contain video and audio tracks.")
    tolerance = max(.12, 2 / config.OUT_FPS)
    for key in ("video_start", "audio_start"):
        stamp = info[key]
        if stamp is None or abs(stamp) > tolerance:
            raise ValueError("The exported audio/video timeline does not start at the cut. Repair the export timing.")
    if abs(info["video_start"] - info["audio_start"]) > tolerance:
        raise ValueError("The exported video and audio start at different times.")
    for key in ("duration", "video_duration", "audio_duration"):
        value = info[key]
        if value is None or value <= 0 or abs(value - expected) > max(.15, 2 / config.OUT_FPS):
            raise ValueError("The export duration does not match the cut. The source may have missing frames.")
    # Decode the bounded exported clip; an encoder's success exit alone does not prove a playable file.
    media.run(["ffmpeg", "-nostdin", "-v", "error", "-i", str(path), "-t", str(expected + .2), "-f", "null", "-"], timeout=timeout)
    return info
