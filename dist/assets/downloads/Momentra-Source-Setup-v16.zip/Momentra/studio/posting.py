"""Post queue: decides when each finished clip goes to which account, posts it, and tracks views."""
import secrets
import shutil
import threading
import time
from pathlib import Path

import json

from . import accounts, alerts, config, creators, ctx, jobs, live
from . import lifecycle, preflight

_lock = threading.RLock()
_stop_event = threading.Event()
_start_lock = threading.Lock()
_started = False
_threads = []
_FILE = config.DATA_DIR / "posts.json"
try:
    _posts: list = json.loads(_FILE.read_text(encoding="utf-8")) if _FILE.exists() else []
except ValueError:
    _posts = []


def _mine() -> list:
    u = ctx.uid()
    return [p for p in _posts if p.get("user") == u]
OPEN = ("scheduled", "posting")


def _save():
    with _lock:
        tmp = _FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(_posts, indent=1), encoding="utf-8")
        tmp.replace(_FILE)


def _day(t):
    return time.strftime("%Y-%m-%d", time.localtime(t))


def _mirror(p):
    """Copy the post's state onto its clip so the clip card can show it."""
    job = jobs.get(p["job"])
    clip = next((c for c in job["clips"] if c["id"] == p["clip"]), None) if job else None
    if clip is not None:
        clip.setdefault("posts", {})[p["id"]] = {k: p.get(k) for k in ("account_name", "platform", "status", "url", "due_at", "error")}
        jobs.save(job)


def _next_slot(account_id, gap_min, cap):
    """Earliest time that respects the gap between posts and the daily cap for this account."""
    mine = [p for p in _mine() if p["account"] == account_id and p["status"] in OPEN + ("posted",)]
    t = max(time.time(), max((p.get("posted_at") or p["due_at"] for p in mine), default=0) + gap_min * 60)
    for _ in range(30):
        if sum(1 for p in mine if _day(p.get("posted_at") or p["due_at"]) == _day(t)) < cap:
            break
        lt = time.localtime(t + 86400)
        t = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 9, 0, 0, 0, 0, -1))  # 9:00 next day
    return t


def _artifact_path(p):
    root = (config.user_dir(p["user"]) / "post-media").resolve()
    name = p.get("artifact", "")
    if not name or Path(name).name != name or "/" in name or "\\" in name:
        raise ValueError("The approved posting copy is missing. Review the clip and retry.")
    path = (root / name).resolve()
    if not path.is_relative_to(root):
        raise ValueError("The approved posting copy is not valid.")
    return path


def public_artifact(uid, job_id, name):
    """A signed platform link may fetch only the durable, approved posting copy."""
    with _lock:
        p = next((p for p in _posts if p.get("user") == uid and p["job"] == job_id and p.get("artifact") == name), None)
        if not p:
            return None
        try:
            path = _artifact_path(p)
            return path if path.is_file() else None
        except (OSError, ValueError):
            return None


def _snapshot(job, clip, p):
    root = config.user_dir(ctx.uid()) / "post-media"
    root.mkdir(parents=True, exist_ok=True)
    name = f"post-{p['id']}-v{clip.get('version', 0)}.mp4"
    target = root / name
    tmp = target.with_suffix(".tmp")
    try:
        shutil.copyfile(preflight.export_path(job, clip), tmp)
        tmp.replace(target)
    finally:
        tmp.unlink(missing_ok=True)
    p.update(artifact=name, render_version=clip.get("version", 0),
             editor_revision=clip.get("editor_revision", 0),
             approved_clip={k: clip.get(k) for k in ("title", "hook", "description", "hashtags", "start", "end")})


def enqueue(job, clip, account_ids, now=False) -> list:
    lifecycle.require_accepting()
    if now and accounts.settings()["paused"]:
        raise ValueError("Posting is paused. Open Home and choose Resume posting, then try Post now again. Resuming also releases other due queued posts.")
    c = creators.get(job["creator"]) or creators.DEFAULTS
    made = []
    with jobs._lock:
        preflight.require(job, clip, account_ids)
        with _lock:
            for aid in dict.fromkeys(account_ids):
                acc = accounts.get(aid)
                if not acc:
                    continue
                if any(p["job"] == job["id"] and p["clip"] == clip["id"] and p["account"] == aid
                       and p["status"] in OPEN + ("blocked", "posted") for p in _mine()):
                    continue  # never post the same clip to the same account twice
                due = time.time() if now else _next_slot(aid, c["post_gap_min"], c["daily_cap"])
                p = {"id": secrets.token_hex(8), "user": ctx.uid(), "job": job["id"], "clip": clip["id"], "creator": job["creator"],
                     "account": aid, "account_name": acc["name"], "platform": acc["platform"], "status": "scheduled",
                     "due_at": due, "created": time.time(), "title": clip.get("title") or clip.get("hook") or "Clip",
                     "score": clip.get("score", 0), "tries": 0, "url": "", "remote_id": "", "error": None, "views": None}
                _snapshot(job, clip, p)
                _posts.append(p)
                made.append(p)
            _save()
    for p in made:
        _mirror(p)
    return made


def on_clip_ready(job, clip):
    """Called once when a clip first finishes rendering."""
    if not lifecycle.accepting():
        return
    c = creators.get(job["creator"])
    if not c or not c["autopost"] or not c["accounts"]:
        return
    if clip.get("score", 0) < c["post_min_score"]:
        return  # includes hand-made clips (score 0): those wait for you to press Post
    try:
        made = enqueue(job, clip, c["accounts"])
    except preflight.Blocked as exc:
        creators.log(c["id"], f"Posting needs review: {exc}")
        clip["post_check"] = {"status": "blocked", "message": str(exc), "version": clip.get("version", 0)}
        jobs.save(job)
        return
    if made:
        creators.log(c["id"], f"Queued for {len(made)} account(s): {clip.get('title') or clip.get('hook')}")


def _caption(clip, creator):
    tags = " ".join("#" + h for h in (clip.get("hashtags") or []))
    return "\n\n".join(x for x in (clip.get("description", ""), tags, creator.get("post_footer", "")) if x)


def _post(p):
    job = jobs.get(p["job"])
    clip = next((c for c in job["clips"] if c["id"] == p["clip"]), None) if job else None
    acc = accounts.get(p["account"])
    try:
        if not clip or not acc:
            raise ValueError("The clip or connected account is no longer available.")
        with jobs._lock:
            if "render_version" not in p:
                raise ValueError("This older queued post has no approved export. Review the clip and retry.")
            path = _artifact_path(p)
            preflight.require(job, clip, [p["account"]], p["render_version"], path)
    except (preflight.Blocked, OSError, ValueError) as exc:
        p.update(status="blocked", error=str(exc)[-300:])
        _save()
        _mirror(p)
        return
    try:
        with _lock:
            if not lifecycle.accepting():
                p.update(status="scheduled", error="Posting will continue next time the studio opens.")
                _save()
                return
            # Save before the first platform request: an interrupted upload must be reviewed.
            p["status"] = "posting"
            _save()
        creator = creators.get(job["creator"]) or dict(creators.DEFAULTS, name="clips")
        approved = p.get("approved_clip") or clip
        title, cap = approved.get("title") or approved.get("hook") or "Clip", _caption(approved, creator)
        if acc["platform"] == "youtube":
            rid, url = accounts.youtube_upload(acc, path, title, cap + "\n\n#Shorts", approved.get("hashtags") or [], creator["privacy"])
        elif acc["platform"] == "instagram":
            rid, url = accounts.instagram_upload(acc, path, f"{title}\n\n{cap}", job["id"])
        elif acc["platform"] == "tiktok":
            rid, url = accounts.tiktok_upload(acc, path, f"{title}\n\n{cap}", creator["privacy"])
        else:
            raise RuntimeError("That kind of account is no longer supported.")
        p.update(status="posted", posted_at=time.time(), remote_id=rid, url=url, error=None)
        creators.log(p["creator"], f"Posted to {acc['name']}: {title}")
    except accounts.ReconnectRequired as exc:
        acc["needs_reconnect"] = True
        accounts._put(acc)
        p.update(status="blocked", error=str(exc)[-300:])
    except Exception as e:  # noqa: BLE001
        p["tries"] += 1
        p["error"] = str(e)[-300:]
        if p["tries"] < 3 and clip and acc:
            p.update(status="scheduled", due_at=time.time() + 600)  # try again in 10 minutes
        else:
            p["status"] = "failed"
            creators.log(p["creator"], f"Post failed on {p['account_name']}: {p['error']}")
            alerts.notify(f"post failed on {p['account_name']} ({p['title']}): {p['error'][:200]}", kind="post")
    _save()
    _mirror(p)


def _run():
    while not _stop_event.wait(15):
        due = [p for p in list(_posts) if p["status"] == "scheduled" and p["due_at"] <= time.time() and p.get("user")]
        for p in due:
            if _stop_event.is_set() or not lifecycle.accepting():
                return
            try:
                with ctx.as_user(p["user"]):
                    if accounts.settings()["paused"]:
                        continue
                    from . import setup_checks
                    if not setup_checks.connection()["online"]:
                        # No upload was attempted, so an outage must not exhaust the post's retry budget.
                        p.update(due_at=time.time() + 60, error="Waiting for the internet connection. No upload attempted.")
                        _save()
                        _mirror(p)
                        ctx.bump()
                        continue
                    with _lock:
                        if _stop_event.is_set() or not lifecycle.accepting():
                            return
                        if p["status"] != "scheduled":
                            continue
                        p["status"] = "posting"
                        _save()
                    _post(p)
            except Exception:  # noqa: BLE001
                pass


def _stats_for(recent):
    for aid in {p["account"] for p in recent if p["platform"] == "youtube"}:
        acc = accounts.get(aid)
        if acc:
            views = accounts.youtube_views(acc, [p["remote_id"] for p in recent if p["account"] == aid])
            for p in recent:
                if p["account"] == aid and p["remote_id"] in views:
                    p["views"] = views[p["remote_id"]]
    for p in recent:
        acc = accounts.get(p["account"]) if p["platform"] == "instagram" else None
        if acc:
            v = accounts.instagram_views(acc, p["remote_id"])
            if v is not None:
                p["views"] = v


def _stats():
    while not _stop_event.is_set():
        for uid in {p.get("user") for p in _posts if p.get("user")}:
            if _stop_event.is_set() or not lifecycle.accepting():
                return
            try:
                with ctx.as_user(uid):
                    _stats_for([p for p in _mine() if p["status"] == "posted" and time.time() - p["posted_at"] < 14 * 86400])
            except Exception:  # noqa: BLE001
                pass
        _save()
        _stop_event.wait(1800)


def cancel(pid):
    with _lock:
        p = next((p for p in _mine() if p["id"] == pid), None)
        if not p or p["status"] not in ("scheduled", "blocked"):
            raise ValueError("Only posts that are still waiting can be cancelled.")
        p["status"] = "cancelled"
        _save()
    _mirror(p)


def retry(pid):
    lifecycle.require_accepting()
    with jobs._lock:
        with _lock:
            p = next((p for p in _mine() if p["id"] == pid), None)
            if not p or p["status"] not in ("failed", "cancelled", "blocked"):
                raise ValueError("Only failed, blocked or cancelled posts can be retried.")
        job = jobs.get(p["job"])
        clip = next((c for c in job["clips"] if c["id"] == p["clip"]), None) if job else None
        if not clip:
            raise ValueError("This clip is no longer available.")
        preflight.require(job, clip, [p["account"]])
        with _lock:
            _snapshot(job, clip, p)
            p.update(status="scheduled", due_at=time.time(), tries=0, error=None)
            _save()
    _mirror(p)


def overview() -> dict:
    today = _day(time.time())
    _posts = _mine()  # everything below is about the signed-in user only
    rows = []
    all_cs, all_js = creators.all_creators(), jobs.list_jobs()
    for c in all_cs:
        js = [j for j in all_js if j["creator"] == c["id"]]
        clips = [k for j in js for k in j["clips"] if k.get("status") == "done"]
        ps = [p for p in _posts if p["creator"] == c["id"]]
        views = sum(p["views"] or 0 for p in ps)
        rows.append({
            "id": c["id"], "name": c["name"],
            "state": "recording" if live.active_for(c["id"]) else "waiting" if c["auto_watch"] and c["channel"] else "idle",
            "autopost": c["autopost"] and bool(c["accounts"]),
            "clips_today": sum(1 for k in clips if _day(k.get("made_at", 0)) == today), "clips_total": len(clips),
            "posted_today": sum(1 for p in ps if p["status"] == "posted" and _day(p["posted_at"]) == today),
            "posted_total": sum(1 for p in ps if p["status"] == "posted"),
            "queued": sum(1 for p in ps if p["status"] in OPEN), "failed": sum(1 for p in ps if p["status"] in ("failed", "blocked")),
            "views": views, "earnings": round(views / 1000 * c["rate_per_1k"], 2)})
    names = {c["id"]: c["name"] for c in all_cs}
    account_names = {a["id"]: a["name"] for a in accounts.list_accounts()}
    queue = sorted((p for p in _posts if p["status"] in OPEN), key=lambda p: p["due_at"])
    done = sorted((p for p in _posts if p["status"] in ("posted", "failed", "blocked")), key=lambda p: -(p.get("posted_at") or p["due_at"]))[:15]
    show = [{**{k: v for k, v in p.items() if k not in ("user", "artifact", "approved_clip")},
             "account_name": account_names.get(p["account"], p["account_name"]),
             "creator_name": names.get(p["creator"], "")} for p in queue + done]
    # last 14 days, oldest first, for the home graph
    days = [_day(time.time() - 86400 * i) for i in range(13, -1, -1)]
    made, posted, views = {d: 0 for d in days}, {d: 0 for d in days}, {d: 0 for d in days}
    for j in all_js:
        for k in j["clips"]:
            d = _day(k.get("made_at") or j["created"])
            if k.get("status") == "done" and d in made:
                made[d] += 1
    for p in _posts:
        if p["status"] == "posted" and _day(p["posted_at"]) in posted:
            posted[_day(p["posted_at"])] += 1
            views[_day(p["posted_at"])] += p["views"] or 0
    daily = [{"day": d, "clips": made[d], "posted": posted[d], "views": views[d]} for d in days]
    return {"paused": accounts.settings()["paused"], "creators": rows, "posts": show, "daily": daily,
            "alerts": alerts.configured(), "recording": len(live.active_mine())}


def digest_text() -> str:
    o = overview()
    lines = ["Momentra daily summary"]
    for r in o["creators"]:
        lines.append(f"- {r['name']}: {r['state']}, {r['clips_today']} clips today, {r['posted_today']} posted today, "
                     f"{r['queued']} waiting, {r['failed']} failed, {r['views']} views")
    if not o["creators"]:
        lines.append("No creators set up yet.")
    if o["paused"]:
        lines.append("Posting is paused.")
    return "\n".join(lines)


def _digest_loop():
    # Same daily summary, with a cancellable wait owned by the scheduler.
    from . import auth
    while not _stop_event.wait(60):
        for uid in auth.user_ids():
            if _stop_event.is_set() or not lifecycle.accepting():
                return
            try:
                with ctx.as_user(uid):
                    settings = accounts.settings()
                    today = time.strftime("%Y-%m-%d")
                    if alerts.configured() and time.localtime().tm_hour == settings["digest_hour"] and settings["last_digest"] != today:
                        accounts.save_settings({"last_digest": today})
                        alerts.send(digest_text())
            except Exception:
                pass


def _keep_awake_loop():
    import os
    if os.name != "nt":
        return
    import ctypes
    continuous, system = 0x80000000, 0x00000001
    try:
        while not _stop_event.is_set():
            busy = bool(live.active()) or any(p["status"] in OPEN for p in list(_posts))
            busy = busy or any(j.get("status") in ("queued", "running") or
                               any(c.get("status") in ("queued", "rendering") for c in list(j.get("clips", [])))
                               for j in list(jobs._jobs.values()))
            ctypes.windll.kernel32.SetThreadExecutionState(continuous | (system if busy else 0))
            _stop_event.wait(30)
    finally:
        ctypes.windll.kernel32.SetThreadExecutionState(continuous)


def start():
    global _started
    with _start_lock:
        if _started or _stop_event.is_set():
            return False
        _started = True
        with _lock:
            for p in _posts:
                if p["status"] == "posting":  # interrupted mid-upload last time
                    p.update(status="failed", error="The studio closed during this upload. Check the account, then retry.")
            _save()
        if on_clip_ready not in jobs.on_clip_ready:
            jobs.on_clip_ready.append(on_clip_ready)
        for fn in (_run, _stats, _digest_loop, _keep_awake_loop):
            thread = threading.Thread(target=fn, daemon=True, name="posting-" + fn.__name__)
            _threads.append(thread)
            thread.start()
        return True


def stop(timeout=0):
    _stop_event.set()
    deadline = time.monotonic() + max(0, timeout)
    for thread in list(_threads):
        if thread is not threading.current_thread():
            thread.join(max(0, deadline - time.monotonic()))


def quiescent():
    return not any(thread.is_alive() for thread in list(_threads))
