"""An opt-in public Instagram gateway. The studio and its API are never proxied."""
import hashlib
import hmac
import json
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from urllib.parse import parse_qs

import httpx
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse

from . import accounts, config, ctx, lifecycle

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
_lock = threading.RLock()
_process = _server = _socket = None
_generation = 0
_status = {"status": "stopped", "public_url": "", "message": "Start the secure link before connecting Instagram."}
_proof_path, _proof = secrets.token_urlsafe(24), secrets.token_urlsafe(32)
_confirmations = {}
CLOUDFLARED_SHA256 = "341deda3db5ec498a0482254d6c38c0b7cf01a30c37bb5dd95d2216d08955e35"


def _file():
    return config.DATA_DIR / "instagram-link.json"


def _settings():
    try:
        value = json.loads(_file().read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(settings):
    tmp = _file().with_suffix(".tmp")
    tmp.write_text(json.dumps(settings), encoding="utf-8")
    try:
        tmp.chmod(0o600)
    except OSError:
        pass
    tmp.replace(_file())


def status():
    with _lock:
        out = dict(_status)
    base = out["public_url"]
    out["urls"] = {k: base + v if base else "" for k, v in {
        "redirect": "/oauth/instagram/callback", "webhook": "/instagram/webhook",
        "deauthorization": "/instagram/deauthorize", "deletion": "/instagram/delete",
        "privacy": "/instagram/privacy"}.items()}
    out["auto_start"] = bool(_settings().get("enabled"))
    return out


def verify_token():
    with _lock:
        settings = _settings()
        if not settings.get("verify_token"):
            settings["verify_token"] = secrets.token_urlsafe(32)
            _save(settings)
        return settings["verify_token"]


def public_base():
    out = status()
    if out["status"] != "ready" or not out["public_url"]:
        raise ValueError("Open Instagram setup and start the secure HTTPS link first.")
    return out["public_url"]


def binary():
    root = Path(getattr(sys, "_MEIPASS", config.ROOT))
    path = root / "bin" / "cloudflared.exe" if getattr(sys, "frozen", False) else root / ".tools" / "cloudflared-2026.11.1" / "cloudflared.exe"
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != CLOUDFLARED_SHA256:
        raise ValueError("The bundled secure-link tool is missing or damaged. Download a fresh Momentra release.")
    return path


def start():
    global _server, _socket, _process, _generation
    lifecycle.require_accepting()
    with _lock:
        if _status["status"] in ("starting", "ready"):
            return status()
        stop(disable=False)
        tool = binary()
        settings = _settings()
        settings.update(enabled=True, owner=ctx.uid())
        settings.setdefault("verify_token", secrets.token_urlsafe(32))
        _save(settings)
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, access_log=False, log_level="critical"))
        _socket, _server = sock, server
        def serve():
            try:
                server.run(sockets=[sock])
            finally:
                sock.close()
        threading.Thread(target=serve, name="instagram-gateway", daemon=True).start()
        try:
            process = lifecycle.popen([str(tool), "tunnel", "--url", f"http://127.0.0.1:{port}", "--no-autoupdate",
                                       "--protocol", "http2"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                      creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except OSError:
            stop(disable=False)
            raise ValueError("Could not start the secure link. Check that your security software allows cloudflared.") from None
        _process = process
        _generation += 1
        generation = _generation
        _status.update(status="starting", public_url="", message="Requesting a temporary HTTPS address…")
        threading.Thread(target=_monitor, args=(process, generation), name="instagram-tunnel", daemon=True).start()
        threading.Thread(target=_timeout, args=(process, generation), name="instagram-tunnel-timeout", daemon=True).start()
        return status()


def _timeout(process, generation):
    # No request waits for this background deadline.
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        with _lock:
            if generation != _generation or _status["status"] != "starting":
                return
        time.sleep(.5)
    with _lock:
        if generation == _generation:
            _status.update(status="error", public_url="", message="The secure link could not connect. Check your internet connection and press Start again.")
            if process.poll() is None:
                process.terminate()


def _monitor(process, generation):
    # Never retain tunnel logs: callback query strings may contain OAuth codes.
    try:
        for raw in process.stdout:
            match = re.search(rb"https://[a-z0-9-]+\.trycloudflare\.com", raw[:8192])
            if not match:
                continue
            base = match.group().decode("ascii")
            for _ in range(15):
                with _lock:
                    if generation != _generation:
                        return
                try:
                    response = httpx.get(base + "/link-check/" + _proof_path, timeout=5, follow_redirects=False)
                    if response.status_code == 200 and hmac.compare_digest(response.text, _proof):
                        with _lock:
                            if generation == _generation and _status["status"] == "starting":
                                _status.update(status="ready", public_url=base, message="Secure link ready. Keep Momentra open while connecting or posting.")
                        break
                except httpx.HTTPError:
                    pass
                time.sleep(1)
        process.wait()
    finally:
        lifecycle.forget_process(process)
        with _lock:
            if generation == _generation and _status["status"] != "error":
                _status.update(status="error", public_url="", message="The secure link stopped. Start it again before posting to Instagram.")


def stop(disable=True, timeout=2):
    global _process, _server, _socket, _generation
    with _lock:
        _generation += 1
        process, server, sock = _process, _server, _socket
        _process = _server = _socket = None
        _status.update(status="stopped", public_url="", message="The secure link is stopped.")
        if disable:
            settings = _settings()
            settings["enabled"] = False
            _save(settings)
        if server:
            server.should_exit = True
        if process and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=max(0, timeout))
            except subprocess.TimeoutExpired:
                if timeout > 0:
                    process.kill()
        if process and process.poll() is not None:
            lifecycle.forget_process(process)
        if sock and not server:
            sock.close()
    return status()


def start_if_enabled():
    settings = _settings()
    if settings.get("enabled") and settings.get("owner"):
        def run():
            with ctx.as_user(settings["owner"]):
                try:
                    start()
                except (OSError, ValueError):
                    _status.update(status="error", public_url="", message="The secure link did not start. Open Instagram setup and try again.")
        threading.Thread(target=run, name="instagram-link-start", daemon=True).start()


@app.middleware("http")
async def headers(request, call_next):
    if len(request.url.query) > 20000:
        return PlainTextResponse("Request too large", status_code=413)
    response = await call_next(request)
    response.headers.update({"Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "X-Content-Type-Options": "nosniff",
                             "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'"})
    return response


@app.get("/link-check/{nonce}")
def check(nonce: str):
    if not hmac.compare_digest(nonce.encode(), _proof_path.encode()):
        raise HTTPException(404)
    return PlainTextResponse(_proof)


@app.get("/oauth/instagram/callback")
def callback(state: str = "", code: str = "", error: str = ""):
    from . import instagram
    owner = instagram.state_owner(state)
    if not owner:
        raise HTTPException(400, "Sign-in expired. Return to Momentra and connect again.")
    with ctx.as_user(owner):
        try:
            if error or not code:
                accounts._take_state(state, "instagram")
                raise ValueError("Instagram sign-in was cancelled. Press Connect again when ready.")
            instagram.finish(code, state)
        except Exception as exc:
            # Only our sanitized errors may be shown; no network exception/URL can escape.
            message = str(exc) if isinstance(exc, (ValueError, RuntimeError)) and not isinstance(exc, httpx.HTTPError) else "Instagram sign-in failed. Check your Meta configuration and try again."
            accounts.finish_connection(state, "instagram", status="error", message=message[:300])
            instagram.cancel(state)
    return HTMLResponse("<!doctype html><title>Momentra</title><h1>Return to Momentra</h1><p>Check the connection dialog to finish choosing your Instagram account or review the sign-in result. You can close this tab.</p>")


@app.api_route("/pub/{token}.mp4", methods=["GET", "HEAD"])
def video(token: str):
    from . import posting
    got = accounts.read_clip_link(token) if len(token) < 2048 else None
    path = posting.public_artifact(*got) if got else None
    if not path:
        raise HTTPException(404)
    return FileResponse(path, media_type="video/mp4")


@app.get("/instagram/webhook")
def challenge(request: Request):
    q = request.query_params
    expected = _settings().get("verify_token", "")
    if q.get("hub.mode") != "subscribe" or not expected or not hmac.compare_digest(q.get("hub.verify_token", "").encode(), expected.encode()):
        raise HTTPException(403)
    return PlainTextResponse(q.get("hub.challenge", "")[:1024])


async def _body(request):
    data = bytearray()
    async for part in request.stream():
        if len(data) + len(part) > 262144:
            raise HTTPException(413)
        data.extend(part)
    return bytes(data)


@app.post("/instagram/webhook")
async def webhook(request: Request):
    from . import instagram
    data = await _body(request)
    secret = instagram.credentials().get("secret", "")
    expected = "sha256=" + hmac.new(secret.encode(), data, hashlib.sha256).hexdigest()
    if not secret or not hmac.compare_digest(request.headers.get("x-hub-signature-256", "").encode(), expected.encode()):
        raise HTTPException(403)
    # Publishing needs no chat subscriptions. Verify and acknowledge without retaining messages.
    return {"ok": True}


@app.post("/instagram/deauthorize")
@app.post("/instagram/delete")
async def deletion(request: Request):
    from . import instagram
    data = await _body(request)
    try:
        signed = parse_qs(data.decode("utf-8")).get("signed_request", [""])[0]
    except UnicodeError:
        raise HTTPException(400)
    payload = instagram.signed_request(signed)
    if not payload:
        raise HTTPException(403)
    instagram.revoke_user(payload["user_id"])
    code = secrets.token_urlsafe(24)
    with _lock:
        for key, expires in list(_confirmations.items()):
            if expires < time.time():
                _confirmations.pop(key, None)
        if len(_confirmations) >= 1000:
            _confirmations.pop(next(iter(_confirmations)))
        _confirmations[code] = time.time() + 86400
    return {"url": public_base() + "/instagram/deletion-status/" + code, "confirmation_code": code}


@app.get("/instagram/deletion-status/{code}")
def deletion_status(code: str):
    if _confirmations.get(code, 0) < time.time():
        raise HTTPException(404)
    return PlainTextResponse("The matching Instagram connection credentials were removed from this Momentra installation. Local source videos and clips were retained.")


@app.get("/instagram/privacy")
def privacy():
    return PlainTextResponse("Momentra runs on its owner's computer. Instagram tokens are saved locally and used to publish approved Reels and read post results. This gateway exposes only sign-in callbacks, verified Meta callbacks and temporary signed links to approved posting copies. It does not expose the studio or AI settings. Disconnect Instagram in Momentra to remove its saved token. Revoking the app through Meta removes matching local connection credentials when Meta delivers the signed callback while Momentra is online. No Instagram messages are retained by this gateway.")
