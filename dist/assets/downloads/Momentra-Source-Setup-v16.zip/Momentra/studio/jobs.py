"""Job pipeline: get video -> audio -> transcript -> AI picks -> rendered clips. One heavy task at a time."""
import collections
import json
import os
import math
import queue
import shutil
import threading
import time
import traceback
import uuid
from pathlib import Path

from . import lifecycle
from . import brain, candidates, config, creators, ctx, editor, load, media, render, roman, safe, transcribe, usage

class _FairQueue:
    """Whose video is next. Each person has their own line and the lines take turns, so someone who adds ten
    videos does not make everyone else wait behind all ten. Small tasks (re-making one clip) go first."""

    def __init__(self):
        self.cv = threading.Condition()
        self.quick = collections.deque()
        self.lines = {}                       # user -> their waiting videos, oldest first
        self.turn = collections.deque()       # users with something waiting, in the order they will be served
        self.epoch = 0                        # goes up whenever the line moves
        self._pos = (0.0, {})
        self.running = 0                      # videos being worked on right now
        self.last_start = 0.0
        self.held = False                     # videos are waiting only because the machine is near full
        self.stopped = False

    def _room(self) -> bool:
        """May one more video start? One always may. More only while the machine has room, and a few seconds
        after the last one started, so its weight is already showing in the measurements."""
        if self.running == 0:
            return True
        return self.running < config.JOB_WORKERS and time.time() - self.last_start > 6 and not load.busy()

    def done(self):
        with self.cv:
            self.running = max(0, self.running - 1)
            self.cv.notify_all()

    def put(self, item, user=None):
        with self.cv:
            if user is None:
                self.quick.append(item)
            else:
                if user not in self.lines:
                    self.lines[user] = collections.deque()
                    self.turn.append(user)
                self.lines[user].append(item)
            self.epoch += 1
            self.cv.notify()

    def get(self, quick_only=False):
        with self.cv:
            while True:
                if self.quick:
                    self.epoch += 1
                    return self.quick.popleft()
                if self.stopped:
                    return None
                if not quick_only and self.turn:
                    if self._room():
                        break
                    if not self.held:
                        self.held = True
                        self.epoch += 1
                elif self.held:
                    self.held = False
                    self.epoch += 1
                self.cv.wait(1.0)             # looked at again every second: the line moves the moment there is room
            self.epoch += 1
            self.held = False
            self.running += 1
            self.last_start = time.time()
            user = self.turn.popleft()
            item = self.lines[user].popleft()
            if self.lines[user]:
                self.turn.append(user)
            else:
                del self.lines[user]
            return item

    def ahead(self) -> dict:
        """job id -> how many videos will start before it. Worked out at most once a second."""
        with self.cv:
            if time.time() - self._pos[0] < 1:
                return self._pos[1]
            out, lines, order, n = {}, {u: list(q) for u, q in self.lines.items()}, list(self.turn), 0
            depth = 0
            while order:
                nxt = []
                for u in order:
                    if depth < len(lines[u]):
                        out[lines[u][depth][1]] = n
                        n += 1
                        if depth + 1 < len(lines[u]):
                            nxt.append(u)
                order, depth = nxt, depth + 1
            self._pos = (time.time(), out)
            return out


_q = _FairQueue()
_live_q: "queue.Queue" = queue.Queue()   # live clips never wait behind a long video
_jobs: dict = {}
_by_user: dict = {}                       # user -> {job id: job}: listing one person's videos never scans everyone's
_lock = threading.RLock()
_start_lock = threading.Lock()
_started = False
_stop_event = threading.Event()
_threads = []
_active_tasks = 0
on_clip_ready: list = []   # callbacks (job, clip), run once when a clip first finishes

DEFAULTS = {"max_clips": 6, "min_len": 15, "max_len": 60, "style": "bounce", "layout": "blur", "quality": 720,
            "range_start": None, "range_end": None, **render.clean_split({}), **render.clean_caption({})}


LIMITS = {"max_clips": (1, 20), "min_len": (5, 120), "max_len": (10, 180), "quality": (360, 1080)}


def clean_options(options) -> dict:
    """Only known settings, each inside its allowed range. Raises ValueError on nonsense."""
    out = {}
    for k, v in (options if isinstance(options, dict) else {}).items():
        if k not in DEFAULTS:
            continue
        if k in render.clean_caption({}):
            out[k] = render.clean_caption({k: v})[k]
            continue
        if v in ("", None):
            continue
        if k in LIMITS:
            lo, hi = LIMITS[k]
            v = max(lo, min(hi, int(float(v))))
        elif k == "style":
            v = v if v in render.STYLES else DEFAULTS["style"]
        elif k == "layout":
            v = v if v in render.LAYOUTS else DEFAULTS["layout"]
        elif k in render.clean_split({}):
            v = float(v)
            if not math.isfinite(v):
                raise ValueError("Crop values must be finite numbers.")
        else:                                    # range_start, range_end: seconds into the video
            v = float(v)
            if not math.isfinite(v) or v < 0:
                raise ValueError("That part of the video isn't valid.")
        out[k] = v
    if any(k in out for k in render.clean_split({})):
        out.update(render.clean_split({**DEFAULTS, **out}))
    if out.get("range_end") is not None and out["range_end"] <= out.get("range_start", 0):
        raise ValueError("The end of the chosen part must be after its start.")
    return out


def job_dir(jid) -> Path:
    return Path(_jobs[jid]["dir"])


HIDDEN = ("dir", "user", "source_path", "recover", "_candidate_cache", "pipeline")


def public(job) -> dict:
    """What the browser may see: no server paths, no owner id."""
    out = {k: v for k, v in job.items() if k not in HIDDEN}
    out["source"] = {k: v for k, v in job["source"].items() if k != "path"}
    out["clips"] = [{**{k: v for k, v in c.items() if k not in ("src", "fixed_words", "fixed_for", *editor.PRIVATE_FIELDS)},
                     "editor_revision": editor.revision(c), "editor_rendered_revision": c.get("editor_rendered_revision", 0)} for c in job["clips"]]
    ai = job.get("ai") or {}
    out["ai"] = {"tokens": ai.get("tokens", 0), "note": ai.get("note", ""), "used": bool(ai.get("model"))}   # never the model, never raw errors
    if job.get("kind") == "live" and job.get("user") == ctx.uid_or_none():
        from . import live
        session = live.SESSIONS.get(job["id"])
        if session and hasattr(session, "chat_hub"):
            out["live"] = {**(out.get("live") or {}), "multi_chat": session.chat_hub.snapshot()}
    if job.get("status") == "queued":
        n = _q.ahead().get(job["id"])
        if n:
            out["stage"] = (f"High demand right now: {n} video{'s' if n != 1 else ''} ahead of yours" if _q.held else
                            f"Waiting in line: {n} video{'s' if n != 1 else ''} ahead of yours")
        elif n == 0 and _q.held:
            out["stage"] = "High demand right now: yours is next"
    return out


def save(job):
    ctx.bump(job.get("user"))
    with _lock:
        d = Path(job["dir"])
        for _ in range(5):
            try:
                text = json.dumps({k: v for k, v in job.items() if k != "_candidate_cache"}, indent=1)
                break
            except RuntimeError:  # changed mid-dump by another thread
                time.sleep(0.05)
        else:
            return
        tmp = d / "job.json.tmp"
        tmp.write_text(text, encoding="utf-8")
        tmp.replace(d / "job.json")


def _set(job, **kw):
    with _lock:
        job.update(kw)
    save(job)


def _remap(path, folder: Path):
    """Paths saved before data moved into per-user folders (or on another machine): find the file by name."""
    if path and not Path(path).exists():
        cand = folder / Path(str(path).replace("\\", "/")).name
        if cand.exists():
            return str(cand)
    return path


def _load_file(f: Path, uid: str):
    try:
        job = json.loads(f.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return
    job.update(dir=str(f.parent), user=uid)
    job.setdefault("kind", "video")
    job.setdefault("creator", None)
    if job.get("source_path"):
        job["source_path"] = _remap(job["source_path"], f.parent)
    if job.get("source", {}).get("path"):
        job["source"]["path"] = _remap(job["source"]["path"], f.parent)
    if job.get("status") in ("queued", "running") and job.get("kind") != "live":
        # Picked up again as soon as the server is back (jobs.start), from the last finished part of the transcript.
        job.update(status="queued", stage="Picking up where it stopped", error=None, resume=True)
    if job.get("status") == "live":
        job.update(status="done", stage="Recording paused by a server update", was_live=True)
    buffered = job.get("kind") == "live" and any((f.parent / "buffer").glob("*.ts"))
    for c in job.get("clips", []):
        if c.get("src"):
            c["src"] = _remap(c["src"], f.parent / "clips")
        if c.get("timing_repair", {}).get("status") in ("queued", "rendering"):
            # A local repair must never restart through the ordinary caption/AI remake path.
            from . import repair
            repair.interrupted(job, c)
            continue
        if c.get("status") in ("rendering", "queued"):
            if buffered and not c.get("src"):
                c["status"] = "queued"  # the stream is still on disk: live.recover() finishes these
                job["recover"] = True
            elif job.get("resume"):
                c["status"] = "queued"  # the video is being picked up again: this clip is made then
            elif (f.parent / "words.json").is_file() and (job.get("kind") != "live" or (c.get("src") and Path(c["src"]).is_file())):
                c["status"] = "queued"  # a single clip being re-made: jobs.start() makes it again
                job.setdefault("remake", []).append(c["id"])
            else:
                c.update(status="error", error="Interrupted by a restart. Open it and press Save and re-make.")
    _jobs[job["id"]] = job
    _by_user.setdefault(uid, {})[job["id"]] = job


def load_user(uid: str):
    d = config.USERS_DIR / uid
    for f in list((d / "jobs").glob("*/job.json")) + list((d / "creators").glob("*/*/*/job.json")):
        _load_file(f, uid)


def load_all():
    for d in config.USERS_DIR.iterdir():
        if d.is_dir():
            load_user(d.name)


def all_jobs() -> list:
    """Every user's jobs. Only for background work; never send this to a browser."""
    with _lock:
        return list(_jobs.values())


def list_jobs():
    u = ctx.uid()
    with _lock:
        return sorted((dict(j) for j in _by_user.get(u, {}).values()), key=lambda j: -j["created"])


def get(jid):
    """The job, only if it belongs to whoever this code is running for."""
    job = _jobs.get(jid)
    return job if job and job["user"] == ctx.uid() else None


def busy_count() -> int:
    u = ctx.uid()
    return sum(1 for j in list(_by_user.get(u, {}).values()) if j["kind"] == "video" and j["status"] in ("queued", "running"))


def waiting_total() -> int:
    return sum(1 for j in list(_jobs.values()) if j["kind"] == "video" and j["status"] == "queued")


def queue_epoch() -> int:
    return _q.epoch


def running_now() -> int:
    return _q.running


def create(source: dict, options: dict, enqueue=True, creator=None, kind="video") -> dict:
    lifecycle.require_accepting()
    jid = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:10]
    c = creators.get(creator) if creator else None
    if c:
        d = creators.root(c["id"]) / ("live" if kind == "live" else "videos") / jid
        base = {**DEFAULTS, **{k: c.get(k, DEFAULTS[k]) for k in ("max_clips", "min_len", "max_len", "style", "layout", "quality", *render.clean_split({}))}}
    else:
        d, base, creator = config.user_dir(ctx.uid()) / "jobs" / jid, dict(DEFAULTS), None
    d.mkdir(parents=True)
    opts = {**base, **clean_options(options)}
    if opts["min_len"] >= opts["max_len"]:
        opts["min_len"] = max(5, opts["max_len"] - 5)
    job = {"id": jid, "user": ctx.uid(), "kind": kind, "creator": creator, "dir": str(d), "created": time.time(), "source": source,
           "options": opts, "status": "queued", "stage": "Waiting", "progress": 0.0,
           "title": source.get("name", ""), "uploader": "", "duration": 0, "clips": [], "error": None, "ai": {}}
    with _lock:
        _jobs[jid] = job
        _by_user.setdefault(job["user"], {})[jid] = job
    save(job)
    if enqueue:
        _q.put(("job", jid, None), user=job["user"])
    return job


def enqueue(job):
    lifecycle.require_accepting()
    save(job)
    _q.put(("job", job["id"], None), user=job["user"])


def submit(fn):
    """Run any heavy task (a render, a cleanup) on the single worker, in order."""
    lifecycle.require_accepting()
    _q.put(("fn", ctx.bind(fn), None))


def submit_live(fn):
    """Live-stream renders and cleanups: their own worker, so a long video can never hold them up."""
    _live_q.put(ctx.bind(fn))


def _live_worker():
    global _active_tasks
    while True:
        try:
            fn = _live_q.get(timeout=0.2)
        except queue.Empty:
            if _stop_event.is_set():
                return
            continue
        with _lock:
            _active_tasks += 1
        try:
            fn()
        except Exception:  # noqa: BLE001
            traceback.print_exc()
        finally:
            with _lock:
                _active_tasks -= 1
            _live_q.task_done()


def delete(jid):
    with _lock:
        job = _jobs.pop(jid, None)
        if job:
            _by_user.get(job["user"], {}).pop(jid, None)
    if job:
        ctx.bump(job["user"])
        shutil.rmtree(job["dir"], ignore_errors=True)
    return bool(job)


def request_render(jid, cid, changes: dict):
    lifecycle.require_accepting()
    # The same lock protects posting snapshots: nobody may queue a remake between its ready check and copy.
    with _lock:
        job = get(jid)
        if not job:
            raise KeyError(jid)
        clip = next(c for c in job["clips"] if c["id"] == cid)
        if not isinstance(changes, dict):
            raise ValueError("Send clip changes as an object.")
        editor.check_revision(clip, changes)
        if job["status"] in ("queued", "running") or clip.get("status") in ("queued", "rendering"):
            raise editor.Conflict("This clip is still being made. Try again when it has finished.")
        new = dict(clip)
        new["start"], new["end"] = editor.cut(job, clip, changes)
        for k in ("hook", "title", "description", "style", "layout"):
            if k in changes:
                new[k] = str(changes[k])[:{"hook": 60, "title": 100, "description": 2000}.get(k, 20)]
        if new.get("style") not in render.STYLES:
            new["style"] = DEFAULTS["style"]
        if new.get("layout") not in render.LAYOUTS:
            new["layout"] = DEFAULTS["layout"]
        split_changes = {**{k: new.get(k, job.get("options", {}).get(k, v)) for k, v in render.clean_split({}).items()}, **changes}
        for key, value in clean_options(split_changes).items():
            if key in (*render.clean_split({}), *render.clean_caption({})) or key == "quality":
                new[key] = value
        new.update(editor.prepare_captions(job, clip, changes))
        new["editor_revision"] = editor.revision(clip) + 1
        # No clip changes or queue entries happen until the whole request is checked.
        clip.update(new, status="queued", error=None)
        save(job)
        _q.put(("clip", jid, cid))


def request_candidate_promotion(jid, candidate_id):
    """Explicit review action. Only already available media; no AI, upload or remote fetching."""
    lifecycle.require_accepting()
    with _lock:
        job = get(jid)
        if not job:
            raise KeyError(jid)
        state = candidates.load(job)
        candidate = next((c for c in (state or {}).get("items", []) if c["id"] == candidate_id), None)
        if not candidate:
            raise KeyError(candidate_id)
        if not state["ranking_complete"] or candidate["verdict"] == "provisional":
            raise editor.Conflict("Discovery and global ranking must finish before promoting a candidate.")
        if candidate.get("promoted_clip") or candidate["verdict"] not in ("review", "rejected") or any(c.get("candidate_id") == candidate_id for c in job["clips"]):
            raise editor.Conflict("This candidate has already been selected or promoted.")
        if job["status"] in ("queued", "running", "live") or any(c.get("status") in ("queued", "rendering") for c in job["clips"]):
            raise editor.Conflict("Wait until this video's current renders finish before promoting another candidate.")
        source = candidates.available_source(job, candidate)
        if not source:
            raise FileNotFoundError("This candidate's original source is not available locally. Remote parts are not downloaded by promotion.")
        c = {k: candidate[k] for k in ("start", "end", "score", "category", "hook", "title", "description", "hashtags", "highlight_words", "reason")}
        c.update(source)
        c["start"], c["end"] = editor.cut(job, c)
        words_file = Path(job["dir"]) / "words.json"
        words = json.loads(words_file.read_text(encoding="utf-8")) if words_file.is_file() else []
        options = job["options"]
        c.update(id="clip-" + candidate_id[5:], candidate_id=candidate_id, manual_promotion=True,
                 status="queued", version=0, style=options["style"], layout=options["layout"],
                 editor_words=[w for w in words if c["start"] - 1 <= w["s"] <= c["end"] + 1],
                 editor_coverage=[[c["start"] - 1, c["end"] + 1]])
        # A visual-only promotion also skips caption AI; the empty manual entry keeps the branch local.
        if not c["editor_words"]:
            c["manual_words"] = {"__local_only__": ""}
        c.update({k: options[k] for k in (*render.clean_split({}), *render.clean_caption({}), "quality")})
        previous = dict(candidate)
        job["clips"].append(c)
        candidate.update(verdict="promoted", promoted_clip=c["id"], verdict_reason="Explicitly promoted from candidate review.")
        try:
            candidates.save(job, state)
            save(job)
        except Exception:
            job["clips"].remove(c)
            candidate.clear()
            candidate.update(previous)
            raise
        (Path(job["dir"]) / "clips").mkdir(exist_ok=True)
        # Queue captures the local transcript; never calls describe, remote ASR or source fetch.
        submit(lambda: render_one(job, c, words))
        return c


def render_one(job, clip, words):
    # Direct callers, live recovery and executor tasks all render as this job's owner.
    with ctx.as_user(job["user"]):
        return _render_one_owned(job, clip, words)


def _render_one_owned(job, clip, words):
    d = Path(job["dir"])
    with _lock:
        clip["status"] = "rendering"
        rendering_revision = editor.revision(clip)
        save(job)
    try:
        src, off = editor.source(job, clip)
        clip["start"], clip["end"] = editor.cut(job, clip, clamp=True)
        local = {**{k: v for k, v in job.get("options", {}).items() if k in (*render.clean_split({}), *render.clean_caption({})) or k == "quality"},
                 **clip, "start": clip["start"] - off, "end": clip["end"] - off, "hook": roman.to_roman(clip.get("hook") or "")}
        span = [round(clip["start"], 2), round(clip["end"], 2), "en2"]
        near_transcript = [w for w in editor.identify(clip, words) if clip["start"] - 1 <= w["s"] <= clip["end"] + 1]
        covered = any(a <= clip["start"] - 1 and b >= clip["end"] + 1 for a, b in clip.get("editor_coverage", []))
        if clip.get("manual_words") or (covered and clip.get("editor_words")):
            # Once a person corrects captions, only local saved words are used. They never enter an AI prompt.
            raw = editor.apply_manual(clip, editor.base_words(clip, near_transcript))
        elif clip.get("fixed_for") == span and clip.get("fixed_words") and not any(
                roman.needs_roman(w.get("w", "")) for w in clip["fixed_words"]):
            raw = editor.identify(clip, roman.words(clip["fixed_words"]))
        else:
            raw = near_transcript
            try:
                usage.set_context(job.get("creator"), job.get("title") or "")
                raw = brain.english_captions(raw, job.get("lang") or "", job.get("title") or "",
                                             youtube_english=lambda: _english_part(job, clip))
                clip.update(fixed_words=raw, fixed_for=span)
            except Exception:  # noqa: BLE001 - captions still render with the words as heard
                pass
            raw = editor.identify(clip, roman.words(raw))
        raw = [w for w in raw if clip["start"] - 1 <= w["s"] <= clip["end"] + 1]
        if not clip.get("manual_words"):
            retained = [w for w in clip.get("editor_words", []) if not clip["start"] - 1 <= w["s"] <= clip["end"] + 1]
            clip["editor_words"] = retained + raw
            clip.setdefault("editor_coverage", []).append([clip["start"] - 1, clip["end"] + 1])
        near = [dict(w, s=w["s"] - off, e=w["e"] - off) for w in raw]
        out = render.render_clip(src, d / "clips", clip["id"], local, near, job["width"], job["height"])
        post = {k: clip[k] for k in ("title", "description", "hashtags", "hook", "start", "end", "score")}
        (d / "clips" / f"{clip['id']}.json").write_text(json.dumps(post, indent=1), encoding="utf-8")
        with _lock:
            clip.update(out, status="done", version=clip.get("version", 0) + 1, error=None,
                        rendered_words=raw, rendered_cut={"start": clip["start"], "end": clip["end"]},
                        editor_rendered_revision=rendering_revision)
        if clip["version"] == 1:
            clip.setdefault("made_at", time.time())
            creators.log(job["creator"], f"Clip ready (score {clip['score']}): {clip['title'] or clip['hook']}")
            save(job)
            for fn in on_clip_ready:
                try:
                    fn(job, clip)
                except Exception:  # noqa: BLE001
                    traceback.print_exc()
    except Exception as e:  # noqa: BLE001
        clip.update(status="error", error=safe.friendly(e, 400))
        creators.log(job["creator"], f"Clip failed: {safe.friendly(e, 200)}")
    save(job)


CLIP_MINUTES = float(config.env("PEAKCUT_CLIP_MINUTES", "15"))     # the longest one clip may take to make


def _wait_for_clips(job, futures, began, workers):
    """Wait for a video's clips, but not for ever. A clip that hangs (a download that stalls, an encoder that
    freezes) used to keep the whole video "in progress", and no other clip could be re-made. Now it is marked as
    failed after CLIP_MINUTES and the video finishes with the clips that did work."""
    left, given_up = list(futures), 0
    late = "This clip took too long and was stopped. Open it and press Save and re-make to try again."
    while left:
        still = []
        for f, clip in left:
            if f.done():
                f.result()
                continue
            t = began.get(clip["id"])
            if (t and time.time() - t > CLIP_MINUTES * 60) or (not t and given_up >= workers):
                given_up += 1
                clip.update(status="error", error=late)
                creators.log(job["creator"], f"Clip stopped after {CLIP_MINUTES:g} minutes: {clip.get('title') or clip.get('hook') or clip['id']}")
                save(job)
                continue
            still.append((f, clip))
        left = still
        if left:
            time.sleep(1)


def _english_part(job, clip):
    """YouTube's English captions for just this clip, for a video in another language. Fetched once per video."""
    if (job.get("source") or {}).get("type") != "url":
        return None
    f = Path(job["dir"]) / "words_en.json"
    if f.is_file():
        en = json.loads(f.read_text(encoding="utf-8"))
    else:
        try:
            en = media.youtube_english_words(job["source"]["url"]) or []
        except Exception:  # noqa: BLE001 - YouTube often refuses its translations: the AI translates instead
            en = []
        f.write_text(json.dumps(en), encoding="utf-8")       # asked once per video, refused or not
    return [w for w in en if clip["start"] - 0.5 <= w["s"] <= clip["end"] + 0.5]


LONG_VIDEO = 40 * 60   # above this, fetch only the pieces that become clips
PAD = 8                # seconds kept either side of a fetched piece, so clips can be re-trimmed


def _fetch_piece(job, clip, full_audio):
    """Long videos: download just this clip's stretch and pin down exactly where it starts."""
    d = Path(job["dir"])
    o = job["options"]
    try:
        want = max(0.0, clip["start"] - PAD)
        piece = media.download_section(job["source"]["url"], d / "clips", f"{clip['id']}.src", want,
                                       min(job["duration"], clip["end"] + PAD), int(o["quality"]))
        wav = d / "clips" / f"{clip['id']}.wav"
        media.extract_audio(piece, wav)
        part = media.load_audio(wav)
        wav.unlink(missing_ok=True)
        meta = media.probe(piece)
        off = media.find_offset(full_audio, part, want)
        clip.update(src=str(piece), src_offset=round(off, 2), src_end=round(off + meta["duration"], 2))
        clip["start"], clip["end"] = max(clip["start"], clip["src_offset"]), min(clip["end"], clip["src_end"])
        job.setdefault("width", meta["width"])
        job.setdefault("height", meta["height"])
    except Exception as e:  # noqa: BLE001
        clip.update(status="error", error=f"Could not fetch this part of the video: {safe.friendly(e, 250)}")


BLOCK = 10 * 60         # efficient transcription checkpoints, never final clip quotas
PIPELINE_VERSION = 10
PROGRESSIVE_FROM = 20 * 60


def _covers(words: list, start: float, end: float) -> bool:
    """Is a borrowed transcript good enough to find clips with? It has to reach the end of the part being clipped
    and have a normal amount of talking in it; otherwise our own model writes the transcript."""
    inside = [w for w in words if start <= w["s"] <= end]
    minutes = max(0.5, (end - start) / 60)
    return len(inside) >= 25 * minutes and inside[-1]["s"] >= start + 0.85 * (end - start)


def _run_job(job):
    import math
    from concurrent.futures import ThreadPoolExecutor
    d = Path(job["dir"])
    o = job["options"]
    src = job["source"]
    t0 = time.time()
    notes = []
    usage.set_context(job["creator"], job["title"] or src.get("name"))
    resuming = bool(job.pop("resume", False)) and (d / "words.json").is_file()
    if resuming:   # legacy clips remain intact; done_blocks only describes transcription, never global ranking
        _set(job, status="running", stage="Picking up where it stopped", error=None)
    else:
        job.pop("_candidate_cache", None)
        (d / "candidates.json").unlink(missing_ok=True)
        _set(job, status="running", stage="Getting the audio", progress=0.03, error=None, clips=[], ai={}, done_blocks=0)
    pipeline = job.get("pipeline") or {}
    if pipeline.get("version") != PIPELINE_VERSION:
        pipeline = {"version": PIPELINE_VERSION, "phase": "transcription", "transcript_blocks": int(job.get("done_blocks", 0)) if resuming else 0,
                    "ranking_complete": False}
        job["pipeline"] = pipeline
    if not transcribe.model_ready() and not transcribe.REMOTE:
        from . import fetch_model
        _set(job, stage="Getting the speech model (one time, about 480 MB)")
        fetch_model.ensure()
        _set(job, stage="Getting the audio")
    fetch = ThreadPoolExecutor(1)
    video = None
    if src["type"] == "url":
        meta = media.info(src["url"])
        if meta["kind"] != "video":
            raise RuntimeError("That link is a channel or playlist, not a single video. Paste the link of one video.")
        if ((o["range_end"] or meta["duration"]) - (o["range_start"] or 0)) > config.MAX_VIDEO_HOURS * 3600:
            raise RuntimeError(f"That is longer than {config.MAX_VIDEO_HOURS:g} hours. Choose a shorter part of it under Options.")
        if meta["is_live"]:
            raise RuntimeError("This link is a live stream, so it would never finish downloading. Open the creator, "
                               "put this link under Setup, and press Start recording instead.")
        _set(job, title=meta["title"], uploader=meta["uploader"], duration=meta["duration"])
        if not job.get("thumb") and media.save_thumb(d, url=src["url"]):
            _set(job, thumb=True)
        usage.set_context(job["creator"], meta["title"])
        span = (o["range_end"] or meta["duration"]) - (o["range_start"] or 0)
        pieces = span > LONG_VIDEO or meta["duration"] <= 0
        if not pieces:  # shorter video: fetch all of it in the background while the audio is worked on
            video = fetch.submit(media.download, src["url"], d, int(o["quality"]))
        audio_file = media.download_audio(src["url"], d, lambda p: _set(job, progress=0.03 + 0.1 * p))
    else:
        pieces, audio_file = False, Path(src["path"])
        info = media.probe(audio_file)
        if info["duration"] > config.MAX_VIDEO_HOURS * 3600:
            raise RuntimeError(f"That video is longer than {config.MAX_VIDEO_HOURS:g} hours, which is the limit.")
        _set(job, source_path=str(audio_file), width=info["width"], height=info["height"], duration=info["duration"])
        if not job.get("thumb") and media.save_thumb(d, video=audio_file):
            _set(job, thumb=True)
    wav = d / "audio.wav"
    media.extract_audio(audio_file, wav)
    audio = media.load_audio(wav)
    wav.unlink(missing_ok=True)
    if src["type"] == "url":
        audio_file.unlink(missing_ok=True)
    if not job["duration"]:
        job["duration"] = len(audio) / 16000
    lo = int((o["range_start"] or 0) * 16000)
    hi = min(len(audio), int(o["range_end"] * 16000)) if o["range_end"] else len(audio)
    span = (hi - lo) / 16000
    db = media.loudness_per_second(audio[lo:hi])

    vlock, vstate = threading.Lock(), {}

    def whole_video():
        """Wait for the background download once; retry it, or give up and use pieces."""
        with vlock:
            if "path" not in vstate:
                path = None
                try:
                    path = video.result()
                except Exception as e:  # noqa: BLE001 - sites sometimes refuse a download
                    notes.append(f"Video download refused once ({str(e)[-80:]}), retrying")
                    try:
                        path = media.download(src["url"], d, int(o["quality"]))
                    except Exception as e2:  # noqa: BLE001
                        notes.append(f"Whole-video download failed ({str(e2)[-80:]}), fetching clip parts instead")
                if path:
                    info = media.probe(path)
                    job.update(source_path=str(path), width=info["width"], height=info["height"])
                vstate["path"] = path
            return vstate["path"]

    exact = {}      # clip id -> (from, to, words): our own model's words for just that clip

    began = {}      # clip id -> when work on it started

    def make(clip, words_now):
        began[clip["id"]] = time.time()
        if src["type"] == "url" and (pieces or not whole_video()):
            _fetch_piece(job, clip, audio)
        if clip["status"] != "error" and yt and yt[1].lower().startswith("en"):
            # The clip was found with YouTube's transcript. What is shown on screen comes from our own model,
            # run on just this clip: full punctuation, nothing blanked out, timings to the word.
            a0, b0 = max(lo, int((clip["start"] - 1.5) * 16000)), min(hi, int((clip["end"] + 1.5) * 16000))
            try:
                tw = [dict(w, s=round(w["s"] + a0 / 16000, 2), e=round(w["e"] + a0 / 16000, 2)) for w in transcribe.transcribe(audio[a0:b0])]
            except Exception:  # noqa: BLE001 - the clip is still made, with YouTube's words
                tw = []
            if len(tw) >= 3:
                exact[clip["id"]] = (a0 / 16000, b0 / 16000, tw)
                words_now = tw
        if clip["status"] != "error":
            render_one(job, clip, words_now)

    cpus = os.cpu_count() or 4
    renders = ThreadPoolExecutor(2 if cpus < 8 else min(6, cpus // 6))  # more clips made at once on a bigger machine
    futures = []
    step = BLOCK * 16000 if span > PROGRESSIVE_FROM else hi - lo
    blocks = [(x, min(hi, x + step)) for x in range(lo, hi, step)] or [(lo, hi)]
    words, tokens, model = [], 0, None
    done_blocks = 0
    yt = None
    if src["type"] == "url" and config.YT_TRANSCRIPT and media.is_youtube(src["url"]):
        try:
            yt = media.youtube_words(src["url"])
        except Exception:  # noqa: BLE001 - no transcript to borrow: ours is written as usual
            yt = None
        if yt and not _covers(yt[0], lo / 16000, hi / 16000):
            yt = None
        job["transcript_from"] = "youtube" if yt else "own"
        job["lang"] = yt[1] if yt else ""          # the language spoken, when YouTube says (decides the captions)
    if resuming:
        try:
            words = json.loads((d / "words.json").read_text(encoding="utf-8"))
        except ValueError:
            words = []
        done_blocks = min(int(pipeline.get("transcript_blocks", 0)), len(blocks)) if words else 0
        tokens, model = int((job.get("ai") or {}).get("tokens", 0)), (job.get("ai") or {}).get("model")
        if done_blocks < len(blocks):     # words past the last finished part are transcribed again
            cut = blocks[done_blocks][0] / 16000
            words = [w for w in words if w["s"] < cut]
        # Even interrupted legacy/selected renders wait until this job's discovery and ranking complete.
        save(job)
    # The transcript of the next part is written while the AI is still reading this one (the AI is a wait on the
    # network, the transcript is work on this machine), so neither waits for the other.
    ahead = ThreadPoolExecutor(2, thread_name_prefix="ahead")
    heard, now_on = {}, [done_blocks]

    def hear(i):
        if i < len(blocks) and i >= done_blocks and i not in heard:
            a_, b_ = blocks[i]
            last = [0.0]

            def tp(p, i=i, a_=a_, b_=b_):
                if now_on[0] == i and p - last[0] > 0.05:      # only the part being shown moves the bar
                    last[0] = p
                    _set(job, progress=max(job["progress"], 0.14 + 0.78 * ((a_ - lo) + p * (b_ - a_)) / max(1, hi - lo)))
            heard[i] = ahead.submit(ctx.bind(transcribe.transcribe), audio[a_:b_], tp)

    for bi, (a, b) in enumerate(blocks):
        if bi < done_blocks:
            continue                      # transcribed and checked by the AI before the restart
        shift = a / 16000
        where = f" (minute {round((a - lo) / 16000 / 60)} of {round(span / 60)})" if len(blocks) > 1 else ""
        if yt:
            _set(job, stage="Reading the transcript" + where)
            bw = [dict(w, s=round(w["s"] - shift, 2), e=round(w["e"] - shift, 2)) for w in yt[0] if a / 16000 <= w["s"] < b / 16000]
        else:
            _set(job, stage="Writing the transcript" + where)
            now_on[0] = bi
            hear(bi)
            hear(bi + 1)
            bw = heard.pop(bi).result()
        _set(job, progress=max(job["progress"], 0.14 + 0.78 * (b - lo) / max(1, hi - lo)))
        words += [dict(w, s=round(w["s"] + shift, 2), e=round(w["e"] + shift, 2)) for w in bw]
        (d / "words.json").write_text(json.dumps(words), encoding="utf-8")
        job["done_blocks"] = bi + 1
        pipeline["transcript_blocks"] = bi + 1
        _set(job, stage="Transcript checkpoint saved" + where, word_count=len(words))
    pipeline["phase"] = "discovery"
    _set(job, stage="Scouting moments across the whole selected video", progress=max(job["progress"], .92))
    selected, discovery = brain.global_discover(job, words, db, lo / 16000, hi / 16000,
                                               lambda: save(job), notes.append)
    # No candidate is a clip, and no new render/post callback can run until this durable global decision.
    pipeline.update(phase="rendering", ranking_complete=True)
    tokens, model = discovery["tokens"], discovery["model"]
    job["ai"] = {"model": model, "tokens": tokens, "note": discovery["note"], "log": notes[-5:]}
    for candidate in selected:
        if any(c.get("candidate_id") == candidate["id"] for c in job["clips"]):
            continue
        c = {k: candidate[k] for k in ("start", "end", "score", "category", "hook", "title", "description", "hashtags", "highlight_words", "reason")}
        c.update(id="clip-" + candidate["id"][5:], candidate_id=candidate["id"],
                 style=o["style"], layout=o["layout"], status="queued", version=0)
        c.update({k: o[k] for k in (*render.clean_split({}), *render.clean_caption({}), "quality")})
        job["clips"].append(c)
    save(job)
    for c in job["clips"]:
        if c.get("status") not in ("done", "error"):
            c["status"] = "queued"
            futures.append((renders.submit(ctx.bind(make), c, list(words)), c))
    if not words and src["type"] == "file":
        # Optional local-only scene/motion suggestions. Never fetch remote video merely to inspect visuals.
        try:
            from . import framing
            for raw in framing.visual_candidates(Path(src["path"]), lo / 16000, hi / 16000,
                                                  o["min_len"], o["max_len"], 8):
                candidate = candidates.make(job, raw, [], [], lo / 16000, hi / 16000,
                                            [lo / 16000, hi / 16000], kind=raw.get("kind", "motion"))
                candidate["provenance"] = {"method": "local_visual", "ai": False}
                candidates.reject(candidate, "budgetfallback", "Local visual change only; no speech or payoff was verified. Review before promoting.", review=True)
                candidates.add(discovery, candidate)
            candidates.save(job, discovery)
        except Exception:
            pass
    if futures:
        _set(job, stage="Finishing the clips", progress=max(job["progress"], 0.92))
    _wait_for_clips(job, futures, began, renders._max_workers)
    if exact:           # keep our own words for the clips in the saved transcript, so editing a clip later uses them
        for a_s, b_s, tw in exact.values():
            words = [w for w in words if not a_s <= w["s"] < b_s] + tw
        words.sort(key=lambda w: w["s"])
        (d / "words.json").write_text(json.dumps(words), encoding="utf-8")
    renders.shutdown(wait=False)
    ahead.shutdown(wait=False)
    fetch.shutdown(wait=False)
    del audio
    clips = job["clips"]
    pipeline["phase"] = "complete"
    job["ai"] = {"model": model, "tokens": tokens, "log": notes[-5:], "note": discovery["note"]}
    stage = "Done" if clips else "Done, but nothing clip-worthy was found"
    _set(job, status="done", stage=stage, progress=1.0, took=round(time.time() - t0))
    try:
        from . import notices
        name = job.get("title") or job["source"].get("name") or "your video"
        notices.add(job.get("user"), "clips", f"{len(clips)} clip{'s' if len(clips) != 1 else ''} ready" if clips else "Nothing clip-worthy found",
                    name, f"/app/creators/{job['creator']}" if job.get("creator") else "/app/videos")
    except Exception:  # noqa: BLE001
        pass
    creators.log(job["creator"], f"Video finished with {len(clips)} clips in {round(time.time() - t0)}s: {job['title']}")


def _worker(quick_only=False):
    global _active_tasks
    while True:
        item = _q.get(quick_only)
        if item is None:
            return
        kind, a, cid = item
        if kind == "fn":
            with _lock:
                _active_tasks += 1
            try:
                a()
            except Exception:  # noqa: BLE001
                traceback.print_exc()
            finally:
                with _lock:
                    _active_tasks -= 1
            continue
        job = _jobs.get(a)
        if not job:
            if kind == "job":
                _q.done()
            continue
        with _lock:
            _active_tasks += 1
        token = ctx._uid.set(job["user"])  # everything this job does runs as its owner
        try:
            if kind == "job":
                _run_job(job)
            else:
                words = json.loads((Path(job["dir"]) / "words.json").read_text(encoding="utf-8"))
                clip = next(c for c in job["clips"] if c["id"] == cid)
                render_one(job, clip, words)
        except Exception as e:  # noqa: BLE001
            (Path(job["dir"]) / "error.log").write_text(traceback.format_exc(), encoding="utf-8")
            if kind == "job":
                for c in job["clips"]:
                    if c.get("status") in ("queued", "rendering"):
                        c.update(status="error", error="The video stopped before this clip was made.")
                _set(job, status="error", error=safe.friendly(e), stage="Stopped")
                creators.log(job["creator"], f"Video failed: {safe.friendly(e)[:200]}")
            elif kind == "clip":
                clip = next((c for c in job["clips"] if c["id"] == cid), None)
                if clip:
                    clip.update(status="error", error="The clip could not be resumed. Open it and press Save and re-make.")
                    save(job)
        finally:
            ctx._uid.reset(token)
            with _lock:
                _active_tasks -= 1
            if kind == "job":
                _q.done()


def _pick_up_after_restart():
    """Videos and single clips that were being made when the server stopped: queued again, oldest first."""
    waiting = sorted((j for j in all_jobs() if j.get("status") == "queued" and j.get("resume")), key=lambda j: j["created"])
    for j in waiting:
        _q.put(("job", j["id"], None), user=j["user"])
    for j in all_jobs():
        for cid in j.pop("remake", []):
            _q.put(("clip", j["id"], cid))
        if j.get("status") == "done":
            save(j)


def start():
    global _started
    with _start_lock:
        if _started or _stop_event.is_set():
            return False
        _started = True
        load.start()
        load_all()
        _pick_up_after_restart()
        specs = [(_worker, ()) for _ in range(max(1, config.JOB_WORKERS))]
        specs += [(_worker, (True,)), (_live_worker, ())]
        for fn, args in specs:
            thread = threading.Thread(target=fn, args=args, daemon=True, name="jobs-" + fn.__name__)
            _threads.append(thread)
            thread.start()
        return True


def stop(timeout=0):
    """Do not start another whole video; finish already queued clip/remake/wrap-up work."""
    _stop_event.set()
    with _q.cv:
        _q.stopped = True
        _q.cv.notify_all()
    deadline = time.monotonic() + max(0, timeout)
    for thread in list(_threads):
        if thread is not threading.current_thread():
            thread.join(max(0, deadline - time.monotonic()))


def quiescent():
    with _lock, _q.cv:
        return _active_tasks == 0 and not _q.quick and _q.running == 0 and _live_q.unfinished_tasks == 0
