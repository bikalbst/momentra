"""Local engine lifetime. No network checks, process-name searches or user-process cleanup."""
import contextlib
import subprocess
import sys
import threading
import time

_lock = threading.RLock()
_started = False
_stopping = threading.Event()
_finished = threading.Event()
_process_closed = False
_shutdown_lock = threading.Lock()
_processes = set()
_report = None


def start():
    """One engine lifetime per process; repeated startup hooks do not reopen a stopped engine."""
    global _started
    with _lock:
        if _started:
            return False
        _started = True
        return True


def accepting():
    return not _stopping.is_set()


def require_accepting():
    if not accepting():
        raise ValueError("The studio is stopping. Open it again before starting new work.")


def begin_shutdown():
    """Close admissions immediately, before waiting on any background work."""
    _stopping.set()


def register_process(process):
    """Only a subprocess launched by this engine may be registered."""
    with _lock:
        if _process_closed:
            _terminate(process)
            raise RuntimeError("The studio has stopped.")
        _processes.add(process)
    return process


def forget_process(process):
    with _lock:
        _processes.discard(process)


def popen(*args, **kwargs):
    with _lock:
        if _process_closed:
            raise RuntimeError("The studio has stopped.")
        return register_process(subprocess.Popen(*args, **kwargs))


def _terminate(process):
    try:
        if process.poll() is None:
            process.terminate()
    except (OSError, ProcessLookupError):
        pass


def cleanup_processes(timeout=2):
    """Terminate, then kill only our still-running Popen handles, with one total deadline."""
    with _lock:
        owned = list(_processes)
    deadline = time.monotonic() + max(0, timeout)
    for process in owned:
        _terminate(process)
    for process in owned:
        try:
            process.wait(timeout=max(0, deadline - time.monotonic()))
        except subprocess.TimeoutExpired:
            try:
                process.kill()
                process.wait(timeout=max(0, deadline - time.monotonic()))
            except (OSError, subprocess.TimeoutExpired):
                pass
        except OSError:
            pass
        if process.poll() is not None:
            forget_process(process)
    with _lock:
        return len(_processes)


def run_process(cmd, *, timeout=None, capture_output=False, input=None, check=False, **kwargs):
    """The subprocess.run contract used by media/render, with explicit engine ownership."""
    if capture_output:
        if "stdout" in kwargs or "stderr" in kwargs:
            raise ValueError("stdout and stderr cannot be used with capture_output")
        kwargs.update(stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if input is not None:
        kwargs["stdin"] = subprocess.PIPE
    process = popen(cmd, **kwargs)
    try:
        try:
            out, err = process.communicate(input=input, timeout=timeout)
        except BaseException:
            _terminate(process)
            try:
                process.communicate(timeout=1)
            except subprocess.TimeoutExpired:
                process.kill()
                process.communicate()
            raise
        result = subprocess.CompletedProcess(cmd, process.returncode, out, err)
        if check:
            result.check_returncode()
        return result
    finally:
        if process.poll() is not None:
            forget_process(process)


def snapshot():
    """Fresh local-only counts, including remakes on finished jobs and live wrap-up."""
    from . import creators, ctx, jobs, live, posting
    uid = ctx.uid()
    rows = [j for j in jobs.all_jobs() if j.get("user") == uid]
    with posting._lock:
        posts = [dict(p) for p in posting._posts if p.get("user") == uid]
    sessions = [s for s in list(live.SESSIONS.values()) if s.job.get("user") == uid and not s.finished]
    cs = creators.all_creators()
    counts = {
        "videos": sum(j.get("kind") != "live" and j.get("status") in ("queued", "running") for j in rows),
        "clips": sum(c.get("status") in ("queued", "rendering") for j in rows for c in list(j.get("clips", []))),
        "recordings": sum(not s.user_stopped and not s.ended for s in sessions),
        "wrapping": sum(s.user_stopped or s.ended for s in sessions),
        "uploads": sum(p.get("status") == "posting" for p in posts),
        "scheduled": sum(p.get("status") == "scheduled" for p in posts),
        "watching": sum(bool(c.get("auto_watch") and c.get("channel")) for c in cs),
    }
    counts["stopping"] = not accepting()
    return counts


def describe(counts):
    labels = {"videos": "videos waiting or running", "clips": "clips being made or re-made",
              "recordings": "live recordings", "wrapping": "recordings wrapping up",
              "uploads": "uploads in progress", "scheduled": "scheduled posts", "watching": "creator watches"}
    return "\n".join(f"{counts.get(key, 0)} {label}" for key, label in labels.items() if counts.get(key)) or "No background work is waiting or running."


def shutdown(timeout=12):
    """Stop producers, allow a bounded wrap-up/save, then clean owned processes before HTTP stops."""
    global _report, _process_closed
    begin_shutdown()
    if _finished.is_set():
        return _report
    if not _shutdown_lock.acquire(blocking=False):
        _finished.wait(max(0, timeout))
        return _report or {"timed_out": True, "errors": ["Shutdown is still in progress."]}
    errors = []
    deadline = time.monotonic() + max(0, timeout)
    from . import jobs, live, posting

    def call(fn, *args):
        try:
            return fn(*args)
        except Exception as exc:
            errors.append(str(exc))

    try:
        gateway = sys.modules.get("studio.instagram_gateway")
        if gateway:
            call(lambda: gateway.stop(disable=False, timeout=min(.5, max(0, deadline - time.monotonic()))))
        call(posting.stop, 0)
        call(live.stop, 0)
        call(jobs.stop, 0)
        # Drain and save on a daemon too: a held job/post lock or stuck disk must not defeat the deadline.
        saved = threading.Event()
        drained = [False]
        def save():
            try:
                while time.monotonic() < deadline - 2:
                    if jobs.quiescent() and live.quiescent() and posting.quiescent():
                        drained[0] = True
                        break
                    time.sleep(0.05)
                for job in jobs.all_jobs():
                    call(jobs.save, job)
                call(posting._save)
            finally:
                saved.set()
        saver = threading.Thread(target=save, name="shutdown-save", daemon=True)
        saver.start()
        saved.wait(max(0, deadline - time.monotonic() - 2))
        # No new child may appear between the final ownership sweep and its completion.
        with _lock:
            _process_closed = True
        remaining = cleanup_processes(max(0, deadline - time.monotonic()))
        timed_out = not (saved.is_set() and drained[0])
        _report = {"timed_out": timed_out, "remaining_processes": remaining, "errors": errors}
        return _report
    finally:
        _finished.set()
        _shutdown_lock.release()
