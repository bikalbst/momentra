"""Private, bounded moment discovery and review. Candidates are not playable/postable clips."""
import copy
import difflib
import hashlib
import json
import math
import re
import threading
from pathlib import Path

from . import ai, brain, ctx

VERSION = 1
POOL_LIMIT = 256
RANK_LIMIT = 96
REVIEW_LIMIT = 50
MIN_SCORE = 60
_lock = threading.RLock()


class BudgetExceeded(RuntimeError):
    pass


class Budget:
    """Count attempts before transport, including retries; save before a request can leave."""
    def __init__(self, state, persist=lambda: None, reserve=0):
        self.state, self.persist, self.reserve = state, persist, reserve

    def take(self):
        budget = self.state["budget"]
        if budget["attempts"] >= budget["limit"] - self.reserve:
            raise BudgetExceeded("The discovery request budget is exhausted.")
        budget["attempts"] += 1
        self.persist()


def identity(job_id, start, end, kind="speech"):
    value = f"{job_id}:{kind}:{start:.2f}:{end:.2f}"
    return "cand-" + hashlib.sha256(value.encode()).hexdigest()[:20]


def windows(start, end, max_len=60):
    overlap = max(brain.OVERLAP_SEC, max_len + 15)
    size = max(brain.WINDOW_SEC, overlap * 2)
    out, cursor = [], start
    while cursor < end:
        out.append([round(cursor, 2), round(min(end, cursor + size), 2)])
        if cursor + size >= end:
            break
        cursor += size - overlap
    return out


def fresh(job, start, end):
    spans = windows(start, end, job["options"]["max_len"])
    return {"version": VERSION, "range": [start, end], "phase": "discovery", "windows": spans,
            "done_windows": [], "items": [], "selected": [], "ranking_complete": False,
            "budget": {"limit": min(120, max(12, len(spans) * 3 + 6)), "attempts": 0},
            "model": None, "tokens": 0, "note": "", "dropped": 0}


def load(job):
    with _lock:
        cached = job.get("_candidate_cache")
        if cached is not None:
            return cached
        try:
            state = json.loads((Path(job["dir"]) / "candidates.json").read_text(encoding="utf-8"))
            if state.get("version") != VERSION or not isinstance(state.get("items"), list):
                return None
        except (OSError, ValueError, AttributeError):
            return None
        job["_candidate_cache"] = state
        return state


def summary(state):
    return {"version": VERSION, "phase": state["phase"], "total": len(state["items"]),
            "selected": len(state["selected"]), "review": sum(c["verdict"] == "review" for c in state["items"]),
            "rejected": sum(c["verdict"] == "rejected" for c in state["items"]),
            "windows_done": len(state["done_windows"]), "windows_total": len(state["windows"]),
            "attempts": state["budget"]["attempts"], "budget": state["budget"]["limit"],
            "ranking_complete": state["ranking_complete"], "dropped": state["dropped"], "note": state["note"]}


def save(job, state):
    with _lock:
        job["_candidate_cache"] = state
        job["candidate_summary"] = summary(state)
        target = Path(job["dir"]) / "candidates.json"
        temp = target.with_suffix(".json.tmp")
        temp.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
        temp.replace(target)
    ctx.bump(job.get("user"))


def evidence(words, start, end):
    near = [w for w in words if start <= w["s"] < end]
    return brain._text(" ".join(w["w"] for w in near), 1600)


def reject(candidate, code, reason, related=None, review=False):
    candidate.update(verdict="review" if review else "rejected", reject_code=code,
                     verdict_reason=brain._text(reason, 250), related_id=related)


def add(state, candidate):
    prior = next((c for c in state["items"] if c["id"] == candidate["id"]), None)
    if prior:
        for window in candidate.get("windows", []):
            if window not in prior["windows"]:
                prior["windows"].append(window)
        return
    state["items"].append(candidate)
    if len(state["items"]) > POOL_LIMIT:
        # A bounded reservoir, not first-come-first-served. A late stronger candidate replaces an early weak one.
        weakest = min(state["items"], key=lambda c: (c["verdict"] != "rejected", c["score"], -c["start"]))
        state["items"].remove(weakest)
        state["dropped"] += 1


def make(job, raw, words, lines, start, end, window, model=None, kind="speech"):
    minimum, maximum = job["options"]["min_len"], job["options"]["max_len"]
    rs, re_ = brain._num(raw.get("start"), -1), brain._num(raw.get("end"), -1)
    valid = start <= rs < re_ <= end and window[0] - 4 <= rs < window[1]
    s, e = brain._snap(raw, lines, words, minimum, maximum, end) if valid else (max(start, rs), max(start, re_))
    s, e = round(max(start, s), 2), round(min(end, e), 2)
    candidate = brain._tidy(raw, s, e)
    candidate.update(id=identity(job["id"], s, e, kind), kind=kind, windows=[window],
                     provenance={"method": "ai_scout" if model else "local_loudness", "ai": bool(model)},
                     evidence=evidence(words, s, e), verdict="provisional", reject_code=None,
                     verdict_reason="Waiting for discovery and global ranking.", related_id=None,
                     promoted_clip=None, rank=None)
    if not valid or e - s < minimum - 1 or e - s > maximum + .5:
        reject(candidate, "invalidcut", "The suggested cut is outside the selected source or cannot finish cleanly.")
    elif kind != "speech":
        reject(candidate, "budgetfallback", "Local visual suggestion, not a verified highlight. Review before promoting.", review=True)
    elif not model:
        candidate.update(selection_fallback="budgetfallback", verdict_reason="Local loudness fallback with speech, not AI highlight selection.")
    return candidate


def semantic_duplicate(a, b):
    def key(c):
        return re.findall(r"[\w']+", c.get("evidence", "").lower())
    x, y = key(a), key(b)
    if min(len(x), len(y)) < 8:
        return False
    if difflib.SequenceMatcher(None, x, y, autojunk=False).ratio() >= .88:
        return True
    tx = {tuple(x[i:i + 3]) for i in range(len(x) - 2)}
    ty = {tuple(y[i:i + 3]) for i in range(len(y) - 2)}
    return bool(tx and ty and len(tx & ty) / max(len(tx), len(ty)) >= .8)


def select(state, maximum, ranked=None, existing=()):
    """One global quota. Rejections retain source evidence and the winning candidate's id."""
    judgments = {r["id"]: r for r in ranked or [] if isinstance(r, dict) and isinstance(r.get("id"), str)}
    eligible = [c for c in state["items"] if c["verdict"] == "provisional"]
    for c in eligible:
        r = judgments.get(c["id"])
        if ranked is not None and not r:
            reject(c, "belowselection", "Not retained by the bounded global ranking.")
        elif r:
            c["score"] = max(0, min(100, int(brain._num(r.get("score")))))
            c["global_evidence"] = {"setup": r.get("has_setup") is True, "payoff": r.get("has_payoff") is True,
                                    "reason": brain._text(r.get("reason"), 250)}
            if r.get("has_setup") is not True or r.get("has_payoff") is not True:
                reject(c, "weakpayoff", "The global judge did not verify a standalone setup and completed payoff.")
            elif r.get("duplicate_of") in judgments and r["duplicate_of"] != c["id"]:
                reject(c, "semanticduplicate", "The global judge found a repeated moment.", r["duplicate_of"])
        elif c["score"] >= MIN_SCORE:
            c["selection_fallback"] = "budgetfallback"
    kept = []
    for c in sorted(eligible, key=lambda c: (-c["score"], c["start"], c["id"])):
        if c["verdict"] != "provisional":
            continue
        local_fallback = c["provenance"]["method"] == "local_loudness"
        if c["score"] < MIN_SCORE and not local_fallback:
            reject(c, "weakpayoff", "The moment's score is below the strong-moment threshold; quotas are not filled with weak clips.")
            continue
        competitors = list(existing) + kept
        overlap = next((k for k in competitors if brain._overlaps(c["start"], c["end"], [k]) or
                        brain._overlaps(k["start"], k["end"], [c])), None)
        duplicate = next((k for k in kept if semantic_duplicate(c, k)), None)
        if overlap:
            reject(c, "overlap", "Overlaps a higher-ranked or already retained clip.", overlap.get("candidate_id") or overlap["id"])
        elif duplicate:
            reject(c, "semanticduplicate", "Repeats the spoken setup/payoff of a stronger moment.", duplicate["id"])
        elif len(kept) >= max(0, maximum - len(existing)):
            reject(c, "belowselection", "Other moments ranked higher across the entire selected video.")
        else:
            c.update(verdict="selected", verdict_reason="Local loudness fallback, not AI highlight selection." if local_fallback else
                     "Selected after discovery across the entire source range.", rank=len(kept) + 1)
            kept.append(c)
    state.update(selected=[c["id"] for c in kept], ranking_complete=True, phase="complete")
    return kept


def discover(job, words, db, start, end, persist_job=lambda: None, log=lambda message: None):
    state = load(job)
    if state is None or state["range"] != [start, end]:
        state = fresh(job, start, end)
    def persist():
        save(job, state)
        persist_job()
    if state["ranking_complete"]:
        return [c for c in state["items"] if c["id"] in state["selected"]], state
    budget = Budget(state, persist, reserve=3)
    lines = brain.make_lines(words, brain.loud_zscore(db)) if start == 0 else brain.make_lines(words)
    with ai.using_snapshot(), ai.request_attempts(budget.take):
        for index, window in enumerate(state["windows"]):
            if index in state["done_windows"]:
                continue
            chunk = [l for l in lines if window[0] <= l["s"] < window[1]]
            if len(chunk) >= 3 and state["budget"]["attempts"] < state["budget"]["limit"] - 3:
                try:
                    out, model, spent = brain.scout_candidates(chunk, job["title"], job["uploader"],
                                                              job["options"]["min_len"], job["options"]["max_len"])
                    state["model"], state["tokens"] = model, state["tokens"] + spent
                    for raw in out[:8] if isinstance(out, list) else []:
                        if isinstance(raw, dict):
                            add(state, make(job, raw, words, lines, start, end, window, model))
                except Exception:
                    state["note"] = "Some scouting requests failed or reached their budget. No weak quota fillers were added."
                    log(state["note"])
            state["done_windows"].append(index)
            persist()
        if not state["model"]:
            local_words = [dict(w, s=w["s"] - start, e=w["e"] - start) for w in words]
            suggestions = brain.fallback_by_loudness(db, local_words, min(8, job["options"]["max_clips"]),
                                                    job["options"]["max_len"], end - start)
            for raw in suggestions:
                raw.update(start=raw["start"] + start, end=raw["end"] + start, hook="", title="Local loudness suggestion")
                add(state, make(job, raw, words, lines, start, end, [start, end]))
            state["note"] = "The AI was unavailable, so clips were picked by loudness with speech only, not AI highlight selection."
        state["phase"] = "ranking"
        persist()
        ranked = None
        eligible = sorted((c for c in state["items"] if c["verdict"] == "provisional"), key=lambda c: (-c["score"], c["start"]))
        budget.reserve = 0
        if eligible and state["model"]:
            try:
                ranked, model, spent = brain.rank_candidates(eligible[:RANK_LIMIT], job["title"], job["options"]["max_clips"])
                if not isinstance(ranked, list) or not any(isinstance(r, dict) and r.get("id") in {c["id"] for c in eligible} for r in ranked):
                    raise ValueError("The global ranking did not identify any candidates.")
                state["model"], state["tokens"] = model, state["tokens"] + spent
            except Exception:
                state["note"] = "Global AI ranking failed or reached its request budget. Strong scouting scores were compared globally; selection used a deterministic budget fallback."
        kept = select(state, job["options"]["max_clips"], ranked, job.get("clips", []))
        persist()
    return kept, state


def available_source(job, candidate):
    path = job.get("source_path") or (job.get("source") or {}).get("path")
    if path and Path(path).is_file():
        return {"src": str(path), "src_offset": 0.0, "src_end": job["duration"]}
    for clip in job.get("clips", []):
        if clip.get("src") and Path(clip["src"]).is_file() and clip.get("src_offset", 0) <= candidate["start"] and clip.get("src_end", 0) >= candidate["end"]:
            return {k: clip[k] for k in ("src", "src_offset", "src_end")}
    return None


def page(job, offset=0, limit=25, verdict=""):
    state = load(job)
    if not state:
        return {"summary": None, "items": [], "total": 0, "offset": offset, "next_offset": None}
    if verdict and verdict not in ("provisional", "selected", "review", "rejected", "promoted"):
        raise ValueError("Choose a valid candidate verdict.")
    offset, limit = max(0, offset), max(1, min(REVIEW_LIMIT, limit))
    with _lock:
        rows = [c for c in state["items"] if not verdict or c["verdict"] == verdict]
        rows = sorted(rows, key=lambda c: (c.get("rank") or 999, -c["score"], c["start"]))
        items = copy.deepcopy(rows[offset:offset + limit])
        for c in items:
            c["source_available"] = bool(available_source(job, c))
            c["can_promote"] = state["ranking_complete"] and c["verdict"] in ("review", "rejected") and c["source_available"] and job["status"] not in ("running", "queued", "live")
        return {"summary": summary(state), "items": items, "total": len(rows), "offset": offset,
                "next_offset": offset + limit if offset + limit < len(rows) else None}
