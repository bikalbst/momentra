"""Opt-in fallback keys and services, kept separately from existing AI profiles."""
import hashlib
import json
import math
import os
import threading
import time
from contextlib import contextmanager

from . import ai, config, ctx

_lock = threading.RLock()
_cooldowns = {}
_service_until = {}
_last_used = {}


def _file():
    return config.DATA_DIR / "ai-failover.json"


def _read():
    try:
        if _file().stat().st_size > 131072:
            raise ValueError("Settings too large")
        value = json.loads(_file().read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {"enabled": False, "order": [], "keys": {}, "allow_paid": False}
    except (OSError, ValueError):
        raise ValueError("The saved AI failover settings cannot be read. Restore ai-failover.json before changing them.") from None
    if not isinstance(value, dict) or type(value.get("enabled")) is not bool or not isinstance(value.get("order"), list) or not isinstance(value.get("keys"), dict):
        raise ValueError("The saved AI failover settings are damaged.")
    if type(value.get("allow_paid", False)) is not bool or len(value["order"]) > len(ai.PROVIDERS) or any(not isinstance(p, str) or p not in ai.PROVIDERS for p in value["order"]):
        raise ValueError("The saved AI failover options are damaged.")
    if len(set(value["order"])) != len(value["order"]):
        raise ValueError("The saved AI failover order contains repeated services.")
    for p, keys in value["keys"].items():
        if p not in ai.PROVIDERS or not isinstance(keys, list) or len(keys) > 5:
            raise ValueError("The saved backup keys are damaged.")
        if any(not isinstance(k, str) or not k or ai._credential(k) != k for k in keys):
            raise ValueError("The saved backup keys are damaged.")
    return value


def _write(value):
    path = _file()
    temp = path.with_suffix(".tmp")
    with temp.open("w", encoding="utf-8") as out:
        try:
            os.chmod(temp, 0o600)
        except OSError:
            pass
        json.dump(value, out)
        out.flush()
        os.fsync(out.fileno())
    temp.replace(path)
    ctx.bump()


def public():
    with _lock:
        value = _read()
        return {"enabled": value["enabled"], "order": list(value["order"]), "allow_paid": bool(value.get("allow_paid")),
                "key_counts": {p: len(keys) for p, keys in value["keys"].items()}, "last_used": dict(_last_used)}


def save(body):
    enabled, order, allow_paid = body.get("enabled"), body.get("order", []), body.get("allow_paid", False)
    if type(enabled) is not bool or type(allow_paid) is not bool or not isinstance(order, list) or len(order) > len(ai.PROVIDERS):
        raise ValueError("Choose whether to enable failover and select the backup services in order.")
    if any(not isinstance(p, str) or p not in ai.PROVIDERS for p in order) or len(set(order)) != len(order):
        raise ValueError("Choose each backup service at most once.")
    with _lock:
        value = _read()
        value.update(enabled=enabled, order=order, allow_paid=allow_paid)
        _write(value)
        return public()


def add_key(provider, key):
    if provider not in ai.PROVIDERS:
        raise ValueError("Choose an AI service first.")
    key = ai._credential(key)
    if not key:
        raise ValueError("Paste the additional API key.")
    # Compare to the primary outside the routing lock, keeping lock order consistent.
    primary = ai.snapshot(provider)["key"]
    with _lock:
        value = _read()
        keys = value["keys"].setdefault(provider, [])
        if key == primary or key in keys:
            raise ValueError("This key is already saved for this service.")
        if len(keys) >= 5:
            raise ValueError("Up to five backup keys can be saved for each service.")
        keys.append(key)
        _write(value)
        return public()


def remove_key(provider, slot):
    with _lock:
        value = _read()
        keys = value["keys"].get(provider, [])
        if type(slot) is not int or not 0 <= slot < len(keys):
            raise ValueError("This backup key is no longer available. Refresh Settings.")
        keys.pop(slot)
        _write(value)
        return public()


def plan(primary):
    # Capture each complete key/address/model tuple once for the logical request.
    with ai._lock:
        with _lock:
            settings = _read()
            enabled, allow_paid = settings["enabled"], bool(settings.get("allow_paid"))
            order = [primary["provider"]] + [p for p in settings["order"] if p != primary["provider"]]
            keys = {p: list(items) for p, items in settings["keys"].items()}
        if not enabled:
            return False, [primary]
        result = []
        for p in order:
            row = dict(primary) if p == primary["provider"] else ai.snapshot(p)
            if not ai._ready(row):
                continue
            models = list(row["models"])
            # A request starting with a :free model cannot silently move to a paid model.
            free_primary = bool(models and p in ("numes", "openrouter") and "free" in models[0].split(":")[1:])
            if not allow_paid and (p != primary["provider"] or free_primary):
                models = models if p == "ollama" else [m for m in models if p in ("numes", "openrouter") and "free" in m.split(":")[1:]]
            if not models:
                continue
            for key in dict.fromkeys([row["key"], *keys.get(p, [])]):
                result.append({**row, "key": key, "models": models})
        return True, result


def _identity(row):
    return hashlib.sha256(json.dumps([row["provider"], ai._base(row), row["key"]], separators=(",", ":")).encode()).hexdigest()


def available(row):
    now = time.time()
    with _lock:
        return _cooldowns.get(_identity(row), 0) <= now and _service_until.get((row["provider"], ai._base(row)), 0) <= now


def failed(row, error):
    status = getattr(error, "status", None)
    delay = 3600 if status in (401, 402, 403) else 60 if status == 429 else 30
    retry = getattr(error, "retry_after", 0)
    if isinstance(retry, (int, float)) and math.isfinite(retry):
        delay = max(delay, min(86400, retry))
    with _lock:
        now = time.time()
        for key, until in list(_cooldowns.items()):
            if until <= now:
                _cooldowns.pop(key, None)
        _cooldowns[_identity(row)] = now + delay
        # A service's rate limit applies to all of its keys, including keys from the same account.
        if status == 429 or (status and status >= 500):
            _service_until[(row["provider"], ai._base(row))] = now + delay


def succeeded(row, model):
    with _lock:
        _last_used.update(provider=row["provider"], label=ai.PROVIDERS[row["provider"]][0], model=model, at=time.time())
    ctx.bump()


def retry_keys():
    """An explicit live Refresh can retry fixed credentials/credits, but never bypass Retry-After."""
    with _lock:
        _cooldowns.clear()


class AttemptLimit(ai.AIError):
    pass


@contextmanager
def bounded_attempts(limit=12):
    previous, count = ai._attempt_hook.get(), 0
    def before():
        nonlocal count
        if count >= limit:
            raise AttemptLimit("AI failover reached its request limit. Try Refresh after checking your saved services.")
        # Existing candidate-scanning budgets still apply to every retry and format negotiation.
        if previous:
            try:
                previous()
            except Exception:
                raise AttemptLimit("The AI request budget is exhausted.") from None
        count += 1
    with ai.request_attempts(before):
        yield


def ask(prompt, schema, purpose, candidates):
    from . import usage
    last, explanation = None, ""
    with bounded_attempts():
        for row in candidates:
            if not available(row):
                continue
            with ai.using_snapshot(row):
                for model in row["models"]:
                    try:
                        out, sent, wrote = ai.call(model, prompt, schema)
                        if str(schema.get("type", "")).lower() == "array" and not isinstance(out, list):
                            raise ai.AIError("The AI returned JSON with the wrong shape.")
                    except AttemptLimit:
                        raise
                    except Exception as exc:
                        last = exc
                        explanation = ai.explain(exc)
                        if getattr(exc, "status", None) in (400, 404, 422) or (isinstance(exc, (ai.AIError, ValueError, KeyError, IndexError, TypeError)) and getattr(exc, "status", None) is None and "connect" not in str(exc).lower()):
                            continue  # invalid output or an unavailable model: try the next configured model
                        failed(row, exc)
                        break
                    usage.record(sent, wrote, purpose)
                    succeeded(row, model)
                    ai.clear_problem()
                    return out, model, sent + wrote
    message = "No saved AI key answered. Check your keys, model access and balances, or wait for rate limits to reset."
    if last:
        message += " " + (explanation or "The selected services did not return a usable answer.")
    ai.problem.update(text=message, at=time.time())
    raise ai.AIError(message)
