"""Small, private video excerpts for framing before a clipping job is started."""
import hashlib
import math
import shutil
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from . import config, ctx, media

_lock = threading.RLock()
_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="video-preview")
_slots = threading.BoundedSemaphore(4)
_entries = {}
SECONDS = 8


def _public(entry):
    return {k: v for k, v in entry.items() if k in ("id", "status", "message", "start", "seconds", "width", "height")}


def _discard(key, entry):
    directory = entry["directory"]
    root = config.user_dir(entry["user"]) / "previews"
    if directory.resolve().is_relative_to(root.resolve()):
        shutil.rmtree(directory, ignore_errors=True)
    _entries.pop(key, None)


def create(url, start=0, retry=False, live_creator=None):
    url = str(url or "").strip()[:500]
    if not media.site_allowed(url):
        raise ValueError("Paste a public YouTube, Twitch or Kick video link.")
    start = float(start)
    if not math.isfinite(start) or not 0 <= start <= 7 * 24 * 3600:
        raise ValueError("Choose a valid preview time in seconds.")
    start = round(start, 1)
    uid = ctx.uid()
    generation = f"live:{live_creator}:{time.time() if retry else int(time.time() // 30)}" if live_creator else "video"
    ident = hashlib.sha256(f"{url}\n{start}\n{generation}".encode()).hexdigest()[:24]
    key = (uid, ident)
    with _lock:
        entry = _entries.get(key)
        if entry and not (retry and entry["status"] == "error"):
            return _public(entry)
        for old_key, old in list(_entries.items()):
            if old["status"] not in ("loading", "queued") and time.time() - old["created"] > 1800:
                _discard(old_key, old)
        active = [e for e in _entries.values() if e["user"] == uid and e["status"] in ("loading", "queued")]
        if len(active) >= 2:
            raise ValueError("Other video previews are loading. Wait for one to finish, then try again.")
        for scope, limit in ((uid, 6), (None, 24)):
            candidates = sorted(((k, e) for k, e in _entries.items() if (scope is None or e["user"] == scope)), key=lambda pair: pair[1]["created"])
            while len(candidates) >= limit:
                old = next(((k, e) for k, e in candidates if e["status"] not in ("loading", "queued") and k != key), None)
                if not old:
                    break
                _discard(*old)
                candidates.remove(old)
        directory = config.user_dir(uid) / "previews" / ident
        directory.mkdir(parents=True, exist_ok=True)
        active_dirs = {e["directory"] for e in _entries.values() if e["status"] in ("loading", "queued")}
        leftovers = sorted((p for p in directory.parent.iterdir() if p.is_dir() and p != directory and p not in active_dirs), key=lambda p: p.stat().st_mtime)
        for old in leftovers[:-5]:
            if old.resolve().is_relative_to(directory.parent.resolve()):
                shutil.rmtree(old, ignore_errors=True)
        if not _slots.acquire(blocking=False):
            raise ValueError("Other video previews are loading. Wait for one to finish, then try again.")
        entry = {"id": ident, "user": uid, "directory": directory, "status": "queued", "start": start,
                 "seconds": SECONDS, "created": time.time(), "message": "Loading an 8-second video excerpt…"}
        _entries[key] = entry
        try:
            if live_creator:
                entry["message"] = "Capturing a short live sample for framing…"
                _pool.submit(ctx.bind(_load_live), entry, url, live_creator)
            else:
                _pool.submit(ctx.bind(_load), entry, url)
        except Exception:
            _slots.release()
            _entries.pop(key, None)
            raise
        return _public(entry)


def _video_info(path):
    import json
    info = json.loads(media.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)], timeout=20))
    stream = next(s for s in info["streams"] if s["codec_type"] == "video")
    return {"width": int(stream["width"]), "height": int(stream["height"]), "duration": float(info["format"].get("duration") or SECONDS)}


def _load_live(entry, url, cid):
    """Prefer a completed recording segment; otherwise capture only a short sample."""
    from . import live
    directory = entry["directory"]
    buffered = directory / "sample.ts"
    partial = directory / "preview-part.mp4"
    try:
        with _lock:
            entry["status"] = "loading"
        session = live.active_for(cid)
        if session and live.normalize(session.job["source"]["url"]) == live.normalize(url):
            session._scan_segments()
            with session.lock:
                segment = next((path for path, _, _ in reversed(session.segments) if path.is_file()), None)
                if segment:
                    shutil.copyfile(segment, buffered)
        if buffered.is_file():
            input_args = ["-i", str(buffered)]
        else:
            resolved = live.resolve(live.normalize(url))
            input_args = ["-rw_timeout", "15000000", "-i", resolved["urls"][0]]
        media.run(["ffmpeg", "-y", "-v", "error", *input_args, "-t", str(SECONDS), "-map", "0:v:0",
                   "-vf", "scale='min(960,iw)':-2", "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "25",
                   "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(partial)], timeout=75)
        info = _video_info(partial)
        partial.replace(directory / "preview.mp4")
        with _lock:
            entry.update(status="ready", width=info["width"], height=info["height"], seconds=min(SECONDS, info["duration"]),
                         message="Captured live sample ready. Refresh it to see a newer moment.")
    except Exception:
        with _lock:
            entry.update(status="error", message="The live sample could not load. The channel may be offline or the platform may block capture. If recording is active, wait for its first buffer segment and try again.")
    finally:
        try:
            buffered.unlink(missing_ok=True)
        except OSError:
            pass
        _slots.release()
        ctx.bump()


def _load(entry, url):
    try:
        with _lock:
            entry["status"] = "loading"
        if media.preview(url).get("is_live"):
            with _lock:
                entry.update(status="error", message="Use a recorded video for this preview. Live streams can be recorded from the creator workspace.")
            return
        directory = entry["directory"]
        raw = media.download_section(url, directory, "excerpt", entry["start"], entry["start"] + SECONDS, 480)
        if raw.stat().st_size > 80 * 1024 * 1024:
            raise ValueError("This preview is too large. Upload the video file to preview it locally.")
        info = media.probe(raw)
        partial = directory / "preview-part.mp4"
        media.run(["ffmpeg", "-y", "-v", "error", "-i", str(raw), "-t", str(SECONDS),
                   "-vf", "scale='min(960,iw)':-2", "-an", "-c:v", "libx264", "-preset", "veryfast",
                   "-crf", "25", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(partial)], timeout=90)
        partial.replace(directory / "preview.mp4")
        with _lock:
            entry.update(status="ready", width=info["width"], height=info["height"], seconds=min(SECONDS, info["duration"]), message="Video excerpt ready")
        for path in directory.glob("excerpt.*"):
            path.unlink(missing_ok=True)
    except Exception:
        with _lock:
            entry.update(status="error", message="The video preview could not load. The site may require sign-in or block downloads. Try another time, or upload the video file.")
    finally:
        _slots.release()
        ctx.bump()


def local_source(path, start, end, offset=0):
    """One private, bounded compatible source excerpt, never an encode on a drag."""
    from pathlib import Path
    from . import lifecycle
    uid = ctx.uid()
    owner = config.user_dir(uid).resolve()
    path = Path(path).resolve()
    if not path.is_relative_to(owner) or not path.is_file():
        raise FileNotFoundError("The original video is no longer available.")
    if not all(math.isfinite(v) for v in (start, end, offset)) or start < offset or not 3 <= end - start <= 240:
        raise ValueError("Preview 3–240 seconds inside the available original video.")
    stat = path.stat()
    ident = hashlib.sha256(f"draft:{path}:{stat.st_size}:{stat.st_mtime_ns}:{start:.2f}:{end:.2f}".encode()).hexdigest()[:24]
    directory = owner / "previews" / ("draft-" + ident)
    out = directory / "preview.mp4"
    with _lock:
        if out.is_file():
            return out
    if not _local_slots.acquire(blocking=False):
        raise ValueError("A local source preview is already being made. Try again in a moment.")
    partial = directory / "preview-part.mp4"
    try:
        directory.mkdir(parents=True, exist_ok=True)
        command = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-ss", str(start - offset), "-i", str(path),
                   "-t", str(end - start), "-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn",
                   "-vf", "scale='min(960,iw)':-2", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "27",
                   "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "96k", "-ac", "2", "-ar", "48000",
                   "-fs", str(128 * 1024 * 1024), "-movflags", "+faststart", str(partial)]
        process = lifecycle.run_process(command, capture_output=True, timeout=120, creationflags=media.NO_WINDOW)
        if process.returncode or not partial.is_file() or not partial.stat().st_size:
            raise ValueError("The compatible source preview could not be made. Saved export is unchanged.")
        with _lock:
            partial.replace(out)
            others = sorted((p for p in directory.parent.glob("draft-*") if p.is_dir() and p != directory), key=lambda p:p.stat().st_mtime)
            for old in others[:-5]:
                if old.resolve().is_relative_to(owner):
                    shutil.rmtree(old, ignore_errors=True)
        return out
    finally:
        partial.unlink(missing_ok=True)
        _local_slots.release()


_local_slots = threading.BoundedSemaphore(1)


def local_video(ident):
    if len(ident) != 24 or any(c not in "0123456789abcdef" for c in ident):
        raise FileNotFoundError("No such source preview.")
    owner = config.user_dir(ctx.uid()).resolve()
    path = owner / "previews" / ("draft-" + ident) / "preview.mp4"
    if not path.resolve().is_relative_to(owner) or not path.is_file():
        raise FileNotFoundError("This source preview has expired.")
    return path


def status(ident):
    with _lock:
        entry = _entries.get((ctx.uid(), ident))
        if not entry:
            raise KeyError("No such preview")
        return _public(entry)


def video(ident):
    with _lock:
        entry = _entries.get((ctx.uid(), ident))
        if not entry or entry["status"] != "ready":
            raise KeyError("Preview not ready")
        path = entry["directory"] / "preview.mp4"
        if not path.is_file():
            raise KeyError("Preview expired")
        return path
