@echo off
setlocal
cd /d "%~dp0"
title Momentra - Local browser studio
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\bootstrap.ps1" %*
set "MOMENTRA_EXIT=%ERRORLEVEL%"
if not "%MOMENTRA_EXIT%"=="0" (
  echo.
  echo Momentra did not finish starting. Read the message above, then try again.
  pause
)
exit /b %MOMENTRA_EXIT%
